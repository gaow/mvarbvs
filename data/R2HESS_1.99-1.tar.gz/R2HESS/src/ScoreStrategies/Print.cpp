#include<cstdio>
#include"Print.h"

void PrintMatrix(float** A, int M, int N)
{
    printf("\n");
    for(int i =0;i < M;i++)
    {
	for(int j = 0;j<N;j++)
	    printf(" %e\t",A[i][j]);
	printf("\n");
    }
}

void PrintMatrix(float* A, int M, int N)
{
    printf("\n");
    for(int i =0;i <M ;i++)
    {	//printf("Row = %d\n",i);
	for(int j = 0;j<N;j++)
	    printf(" %1.3f  ",A[j*M+i]);
	printf("\n");
    }
}

void PrintVector(float* a, int n)
{
    for(int i =0;i < n;i++)
    {
	printf(" %e\t",a[i]);
    }

    printf("\n");
}

void PrintVector(int* a, int n)
{
    for(int i =0;i < n;i++)
    {
	printf(" %d\t",a[i]);
    }

    printf("\n");
}

