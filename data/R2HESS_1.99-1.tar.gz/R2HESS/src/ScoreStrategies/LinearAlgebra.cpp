#include<cstring>
#include"LinearAlgebra.h"
#include"Print.h"
#include<cstdio>
#include"mkl.h"

void MatrixMatrixMultiply(char transa,char transb,int m,int n, int k ,float alpha,float*a,int lda,float*b,int ldb,float beta,float*c ,int ldc)
{
    int i,j,l;
    float temp = 0;
    bool bAlpha = true;
    bool bBeta = true;
    bool bBetaOne = false;
    if(alpha == 1)
	bAlpha = false;
	
    if(beta == 0)
	bBeta = false;
    if(beta == 1)
	bBetaOne = true;
	
    if(transa == 'N' && transb == 'N')
    {
	for(i = 0;i<m;i++)
	{
	    for(j=0;j<n;j++)
	    {
		temp = 0;
		for(l = 0;l<k;l++)
		{
		    if(l == 0)
			temp = a[i*lda + l] * b[l*ldb+j];			
		    else	
			temp += a[i*lda + l] * b[l*ldb+j];				
		}
		if(bAlpha )
		    temp = alpha*temp;
			
		if(bBeta)
		{	
		    if(bBetaOne)
			c[i*ldc + j] = temp + c[i*ldc+j];
		    else
			c[i*ldc + j] = temp + beta*c[i*ldc+j];
		}
		else									
		    c[i*ldc + j] = temp;
	    }
	}
    }
    else if(transa == 'N' && transb == 'Y')
    {
	for(i = 0;i<m;i++)
	{
	    for(j=0;j<n;j++)
	    {
		temp = 0;
		for(l = 0;l<k;l++)
		{
		    if(l == 0)
			temp = a[i*lda + l] * b[j*ldb+l];				
		    else
			temp += a[i*lda + l] * b[j*ldb+l];				
		}
				
		if(bAlpha)
		    temp = alpha*temp;
			
		if(bBeta )
		{
		    if(bBetaOne)
			c[i*ldc + j] = temp + c[i*ldc+j];
		    else
			c[i*ldc + j] = temp + beta*c[i*ldc+j];
		}
		else									
		    c[i*ldc + j] = temp;

		//c[i*ldc + j] = temp + temp1;//beta*c[i*ldc + j]; 		
		//c[i*ldc + j] = alpha *temp + beta*c[i*ldc + j]; 		
	    }
	}
    }
    else if(transa == 'Y' && transb == 'N')
    {
	for(i = 0;i<m;i++)
	{
	    for(j=0;j<n;j++)
	    {
		temp = 0;
		for(l = 0;l<k;l++)
		{
		    if(l == 0)
			temp = a[l*lda + i] * b[l*ldb+j];				
		    else
			temp += a[l*lda + i] * b[l*ldb+j];				
		}
				
		if(bAlpha)
		    temp = alpha*temp;
			
		if(bBeta)
		{
		    if(bBetaOne)
			c[i*ldc + j] = temp + c[i*ldc+j];
		    else
			c[i*ldc + j] = temp + beta*c[i*ldc+j];
		}
		else									
		    c[i*ldc + j] = temp;

		//if(alpha != 1)
		//    temp = alpha*temp;
			
		//if(beta != 0)
		//    temp1 = beta*c[i*ldc+j];
		//else
		//    temp1 = c[i*ldc+j];				
		
		//c[i*ldc + j] = temp + temp1;//beta*c[i*ldc + j]; 		
		//c[i*ldc + j] = alpha *temp + beta*c[i*ldc + j]; 		
	    }
	}
    }
}
