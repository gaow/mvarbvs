#ifndef LinearAlgebra_h
#define LinearAlgebra_h

#include<cmath>

float BLAS_VectorDotProduct(float*x, int incx, float*y, int incy, int len);
float Bisection(float*alphaArray,float* betaArray,int k,float epsilon);

void BLAS_axpy(int len, float alpha , float *x,int incx, float * y, int incy);
float BLAS_nrm2(int len, float* x, int incx);

void CopyMatrix(int nRows, int nCols,float* x,int xStartRow,int xStartCol,int ldx, float*y,int yStartRow,int yStartCol,int ldy);
void CopyMatrixSelectedRows(int nRows, int nCols,float* a,int* aRowIndexSet,int aStartCol,int lda, float*b,int *bRowIndexSet,int bStartCol,int ldb);
void CopyMatrixSelectedRows(int nRows, int nCols,float* a,int* aRowIndexSet,int aStartCol,int lda, float*b,int bStartRow ,int bStartCol,int ldb);
void CopyMatrixSelectedRows(int nRows, int nCols,float* a,int aStartRow,int aStartCol,int lda, float*b,int* bRowIndexSet,int bStartCol,int ldb);
void BLAS_ScaleVector(int len, float a, float*x,int incx);
void BLAS_ScaleVector(int len, float a, float*x,int incx,float*y,int incy);
void BLAS_MatrixMatrixMultiply(char transa,char transb,int m,int n, int k ,float alpha,float*a,int lda,float*b,int ldb,float beta,float*c ,int ldc);
void BLAS_MatrixVectorMultiply(char transa,int m, int n,float alpha,float*a,int lda,float*x,int incx, float beta,float*y,int incy);

float VectorDotProduct(float* x, int incx, float* y, int incy, int len);
void ScaleVector(int len, float a, float*x,int incx,float*y,int incy);
void ScaleVector(int len, float a, float*x,int incx);
void AXPY(int len, float alpha , float *x, int incx, float * y, int incy);
float NRM2(int len, float* x, int incx);
void MatrixVectorMultiply(char transa,int m, int n,float alpha,float*a,int lda,float*x,int incx, float beta,float*y,int incy);
void TransposeMatrix(int m, int n, float*a);
void MatrixMatrixMultiply(char transa,char transb,int m,int n, int k ,float alpha,float*a,int lda,float*b,int ldb,float beta,float*c ,int ldc);

#endif
