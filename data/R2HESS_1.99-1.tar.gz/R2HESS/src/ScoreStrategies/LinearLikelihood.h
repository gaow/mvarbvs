/* This file is part of ESS-OO.
 *      Copyright (c) Marc Chadeau-Hyam (m.chadeau@imperial.ac.uk)
 *                    Leonardo Bottolo (l.bottolo@imperial.ac.uk)
 *                    David Hastie (d.hastie@imperial.ac.uk)
 *      2014
 *
 * Software designed and restructured by Loizos Markides (lm1011@ic.ac.uk)
 * ESS-OO is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ESS-OO is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ESS-OO.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef LINEARLIKELIHOOD_H_
#define LINEARLIKELIHOOD_H_

#include "../MCMC/Score.h"
#include "../MCMC/Definitions.h"
#include "ScoreLikelihoodStrategy.h"
#include "../MCMC/MCMC.h"

#if _CUDA_
#include "timestamp.h"
//CAQR includes
#include "tuning.h"
#include "QR_matrix.h"
#include "cuda_macros.h"
#include <iostream>
#include "assert.h"
//#include "mkl.h"
#include "Print.h"
#endif

//#define DEBUG 1
//#define DEBUG_mat 0

class LinearLikelihood: public ScoreLikelihoodStrategy {
public:
    LinearLikelihood();
    virtual ~LinearLikelihood();
    virtual double calculateScoreLikelihood(double &g,
					    std::vector<unsigned int> &list_vars_in,
					    gsl_matrix* mat_Y,
					    double prior_k);
    virtual double calculateScoreLikelihoodSGamma(double &g,
						  std::vector<unsigned int> &list_vars_in,
						  gsl_matrix* mat_Y,
						  double prior_k,
						  gsl_matrix* sgamma);

    virtual double calculateScoreLikelihood(double &g,
					    std::vector<unsigned int> &list_vars_in,
					    gsl_matrix* mat_Y,
					    double prior_k,
					    gsl_matrix* R2_Mat_GPriors);
#if _CUDA_
    virtual double calculateScoreLikelihood(double &g,
					    std::vector<unsigned int> &list_vars_in,
					    gsl_matrix* mat_Y,
					    double prior_k,
					    float* mat_Y_GPU);
#endif
private:
    gsl_matrix* getSGamma(gsl_matrix *matXGam,
			  gsl_matrix *matY,
			  gsl_matrix *eigenVecs,
			  gsl_vector *eigenVals,
			  unsigned int pXGam,
			  unsigned int nX,
			  unsigned int pY,
			  int inDatabase,
			  std::string gammasVector,
			  double g,
			  gsl_matrix *sgamma);

    double getLogMarg(gsl_matrix *matXGam,
		      gsl_matrix *matSGamma,
		      float* matrixEigenVecs,
		      float* vectorEigenVals,
		      unsigned int pXGam,
		      unsigned int nX,
		      unsigned int pY,
		      double g,
		      double prior_k);

    void Quick_getSGamma_GPriors(gsl_matrix *matSGamma,
				 gsl_matrix * R2_Mat_GPriors,
				 gsl_matrix * matYTY,
				 unsigned int nX,
				 unsigned int pXGam,
				 unsigned int pY,
				 double g);

#if _CUDA_

    void getEigenDecompositionCula(gsl_matrix *matXGam,
				   float* matrixEigenVecs,
				   float* vectorEigenVals,
				   unsigned int pXGam);

    gsl_matrix *getSGammaCula(gsl_matrix *matXGam,
			      gsl_matrix *matY,
			      float *matrixEigenVecs,
			      float *vectorEigenVals,	
			      unsigned int pXGam,
			      unsigned int nX,
			      unsigned int pY, double g);
							 
    gsl_matrix *getSGammaCAQR(gsl_matrix *matXGam,
			      float *matXGam_Y_GPU,
			      float *matY_GPU,
			      gsl_matrix *matY,
			      float *matrixEigenVecs,
			      float *vectorEigenVals,							 
			      unsigned int pXGam,
			      unsigned int nX,
			      unsigned int pY,
			      double g);
#endif

};

#endif /* LINEARLIKELIHOOD_H_ */
