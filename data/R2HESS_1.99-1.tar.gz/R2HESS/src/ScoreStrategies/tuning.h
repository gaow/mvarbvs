/* Tuned settings for float and double */

#define FLOAT
#define real_t_f float
#define BLK_WIDTH_f 16
#define BLK_HEIGHT_f 128
#define NUM_THREADS_f 128
#define BLK_SIZE_f (BLK_WIDTH_f * BLK_HEIGHT_f)
#define BLK_ROWS_f (NUM_THREADS_f / BLK_WIDTH_f)
#define THREAD_STORAGE_f BLK_WIDTH_f
#define TID_L_MASK_f 0xF
#define TID_U_SHIFT_f 4
#define ZERO_INIT_f {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}

#define real_t double
#define BLK_WIDTH 8
#define BLK_HEIGHT 64
#define NUM_THREADS 64
#define BLK_SIZE (BLK_WIDTH * BLK_HEIGHT)
#define BLK_ROWS (NUM_THREADS / BLK_WIDTH)
#define THREAD_STORAGE BLK_WIDTH
#define TID_L_MASK 0x7
#define TID_U_SHIFT 3
#define ZERO_INIT {0,0,0,0,0,0,0,0}

