#include "tuning.h"
#include <vector>
#include <iostream>
#include "cuda_macros.h"
#include <cuda.h>

class level_t {
public:
    int num_blocks;
    int aggregate_blocks;
    int block_offset;
    int lev;
    level_t();
    level_t(int nb, int ab, int bo, int l);
};

/* This defines the main matrix data structure and functions to 
   access and modify it */
class QR_matrix {

public:
    /* Input matrix properties */
    int m;
    int n;
    int lda;
    int ld_panel;
    int ldq;
    int ldq_panel;
    int blks_tall_base;
    int blks_wide_base;
    int internal_matrix_size;
    int total_blocks;
    real_t * mat_base;
    real_t * Q_base;
  
    /* Current information */
    real_t * mat;
    real_t * Q;
    int m_current;
    int n_current;
    int blks_tall;
    int blks_wide;
    vector<level_t*> levels;

    /* Constructors*/
    QR_matrix();
    QR_matrix(const real_t * mat_in, const int m, const int n, const int lda);
    ~QR_matrix();

    /* Set the matrix in its internal form (transpose) and retrieve it back */
    void factor();
    void getq();
    void apply(real_t * target_mat, int lda, int k);
    void calculate_dimensions(const int m, const int n);
    void allocate(const int m, const int n);
    void image_identity();
    void set(const real_t * mat_in, const int m, const int n, const int lda);
    void retrieve(real_t * mat_out, const int m, const int n, const int lda);
    void retrieveQ(real_t * mat_out, const int m, const int n, const int ldq);
    void retrieveR(real_t * mat_out, const int m, const int n, const int lda);
    real_t * blockQ(const int l);
    /* Update the pointer to the next panel */
    void increment(int apply);
    void decrement(int apply);
    int set_levels();
}; 

class level_t_f {
public:
    int num_blocks;
    int aggregate_blocks;
    int block_offset;
    int lev;
    level_t_f();
    level_t_f(int nb, int ab, int bo, int l);
}; 

class QR_matrix_f {

public:
    /* Input matrix properties */
    int m;
    int n;
    int lda;
    int ld_panel;
    int ldq;
    int ldq_panel;
    int blks_tall_base;
    int blks_wide_base;
    int internal_matrix_size;
    int total_blocks;
    real_t_f * mat_base;
    real_t_f * Q_base;
  
    /* Current information */
    real_t_f * mat;
    real_t_f * Q;
    int m_current;
    int n_current;
    int blks_tall;
    int blks_wide;
    vector<level_t_f*> levels;

    /* Constructors*/
    QR_matrix_f();
    QR_matrix_f(const real_t_f * mat_in, const int m, const int n, const int lda);
    ~QR_matrix_f();

    /* Set the matrix in its internal form (transpose) and retrieve it back */
    void factor_f();
    void getq_f();
    void apply_f(real_t_f * target_mat, int lda, int k);
    void calculate_dimensions_f(const int m, const int n);
    void allocate_f(const int m, const int n);
    void image_identity_f();
    void set_f(const real_t_f * mat_in, const int m, const int n, const int lda);
    void retrieve_f(real_t_f * mat_out, const int m, const int n, const int lda);
    void retrieveQ_f(real_t_f * mat_out, const int m, const int n, const int ldq);
    void retrieveR_f(real_t_f * mat_out, const int m, const int n, const int lda);
    real_t_f * blockQ_f(const int l);
    /* Update the pointer to the next panel */
    void increment_f(int apply);
    void decrement_f(int apply);
    int set_levels_f();
}; 
