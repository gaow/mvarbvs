/* This file is part of ESS-OO.
 *      Copyright (c) Marc Chadeau-Hyam (m.chadeau@imperial.ac.uk)
 *                    Leonardo Bottolo (l.bottolo@imperial.ac.uk)
 *                    David Hastie (d.hastie@imperial.ac.uk)
 *      2014
 *
 * Software designed and restructured by Loizos Markides (lm1011@ic.ac.uk)
 * ESS-OO is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ESS-OO is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ESS-OO.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "wmegaBetaBinomialPenalization.h"

wmegaBetaBinomialPenalization::wmegaBetaBinomialPenalization() {
    // TODO Auto-generated constructor stub
}

wmegaBetaBinomialPenalization::~wmegaBetaBinomialPenalization() {
    // TODO Auto-generated destructor stub
}

double wmegaBetaBinomialPenalization::calculateScorePenalization()
{
    return 0.0;
}
