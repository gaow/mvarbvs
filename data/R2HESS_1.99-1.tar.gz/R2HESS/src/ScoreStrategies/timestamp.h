#ifndef timestamp_h
#define timestamp_h

extern double timestamp ();

#endif
