/* This file is part of ESS-OO.
 *      Copyright (c) Marc Chadeau-Hyam (m.chadeau@imperial.ac.uk)
 *                    Leonardo Bottolo (l.bottolo@imperial.ac.uk)
 *                    David Hastie (d.hastie@imperial.ac.uk)
 *      2014
 *
 * Software designed and restructured by Loizos Markides (lm1011@ic.ac.uk)
 * ESS-OO is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ESS-OO is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ESS-OO.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "TemperatureTuning.h"
#include <cmath>
using namespace std;

TemperatureTuning::TemperatureTuning() {
    C=0;
    b_t=0.0;
    a_t_den=0.0;
    nbatch=1;
    M.resize(2);
    delta_n=0.0;
    optimal=0.0;
    c_idx=0;
    log_.history.resize(0);
}

TemperatureTuning::~TemperatureTuning() {
    a_t.clear();
    M.clear();
}

void TemperatureTuning::set(vector<Chain>& chainsVector,
			    vector <unsigned int > &chain_idx,
			    unsigned int nb_chains,
			    unsigned int pX,
			    double b_t_input,
			    double a_t_den_inf_5k,
			    double a_t_den_5_10k,
			    double a_t_den_sup_10k,
			    unsigned int nbatch_input,
			    vector < double > &M_input,
			    unsigned int burn_in,
			    double optimal_input)
{
    // Initializing the temperature-specific variables, coming from the input files
    C=nb_chains;

    if(nb_chains==1)
    {
	c_idx=0;
    }
    else
    {
	b_t=b_t_input;
	if(pX<=5000)
	{
	    a_t_den= a_t_den_inf_5k;
	}
	else if(pX>5000 && pX<=10000)
	{
	    a_t_den=a_t_den_5_10k;
	}
	else
	{
	    a_t_den= a_t_den_sup_10k;
	}

	a_t.resize(nb_chains);

	for(unsigned int chain=0;chain<nb_chains;chain++)
	{
	    a_t[chain]=(double)(chain)/a_t_den;
	    if (!(Settings.resumeRun || Settings.extendRun))
	    {
		if(!Settings.noTemperature)
		{
		    chainsVector[chain_idx[chain]].setCurrentTemperature(pow(b_t,a_t[chain]));
		}
		else
		{
		    chainsVector[chain_idx[chain]].setCurrentTemperature(1.0);
		}
	    }
	}

	nbatch=nbatch_input;
	unsigned int tmp_M_input_size=M_input.size();

	if(tmp_M_input_size==2)
	{
	    for(unsigned int row=0;row<M_input.size();row++)
	    {
		M[row]=M_input[row];
	    }
	}
	else
	{
	    //Error case
	    clog << "Dimension mismatch M_input has " <<  tmp_M_input_size << " --elements, " << 2 << " expected." << endl
		 << "Run stopped." << endl;
	    exit(1);
	}

	double tmp1=fabs(std::log(M[0]/b_t)/std::log(2));
	double tmp2=fabs(std::log(M[1]/b_t)/std::log(2));
	double numer=max(tmp1,tmp2);
	delta_n=numer/((double)(burn_in)/nbatch);
	optimal=optimal_input;
	for(unsigned int chain=0;chain<nb_chains;chain++)
	{
	    if(chainsVector[chain_idx[chain]].getCurrentTemperature()==1.0)
	    {
		c_idx=chain;
	    }
	}
    }

    if (Settings.moveLog)
	log_.history.resize(nb_chains+1);
}


void TemperatureTuning::display()
{
    //clog << endl << "**********************************************************" << endl
    clog << endl << "******************** Temp parameters ********************" << endl
	 << "\tC = " << C << endl;

    if(C>1)
    {
	clog << "\tb_t = " << b_t << endl
	     << "\ta_t_den = " << a_t_den << endl
	     << "\tnbatch = " << nbatch << endl
	     << "\tdelta_n = " << delta_n << endl
	     << "\toptimal = " << optimal << endl
	     << "\tc_idx = " << c_idx << endl
	     << "\ta_t: [";

	for(unsigned int chain=0;chain<C;chain++)
	{
	    clog << a_t[chain] << " ";
	}
	clog << "]" << endl;
    }
    clog << "\tt: [";

    //iterate through the chainsVector
    clog << "]" << endl;

    if(C>1)
    {
	clog << "\tM: [";
	for(unsigned int chain=0;chain<M.size();chain++)
	{
	    clog << M[chain] << " ";
	}
	clog << "]" << endl;
    }

    clog << "**********************************************************" << endl << endl;
    //	 << "**********************************************************" << endl << endl;
}

void TemperatureTuning::execute(DelayedRejection *DR,
				vector<Chain>& chainsVector,
				vector <unsigned int > &chain_idx,
				unsigned int sweep,
				unsigned int n_vars_in_last_chain,
				unsigned int nX)
{
    // Holds the logic for updating the temperature of the chains.

    unsigned int n_chains=chainsVector.size();
    unsigned int DR_n_accept_adj=0;
    unsigned int DR_n_proposed_adj=0;
    double DR_acceptance_rate;
    unsigned int firstChainAccept;

    // Use moves between all adjacent chains
    for(unsigned int row=0;row<DR->mat_moves_accepted.size()-1;row++)
    {
	DR_n_accept_adj+=DR->mat_moves_accepted[row][row+1];
	DR_n_proposed_adj+=DR->mat_moves_proposed[row][row+1];
    }

    firstChainAccept=DR->mat_moves_accepted[0][1];

    if(DR_n_proposed_adj>0)
    {
	DR_acceptance_rate=(double)(DR_n_accept_adj)/(double)(DR_n_proposed_adj);
    }
    else
    {
	DR_acceptance_rate=0.0;
    }

    if (Settings.moveLog)
	log_.history[0].push_back(sweep);

    //Adjusting temperatures
    double temp_new_b_t=b_t;
    double new_b_t=b_t;

    if(DR_n_accept_adj==0||firstChainAccept==0 || n_vars_in_last_chain> 10*nX )
    {
	temp_new_b_t=b_t - (b_t-1.0)/2.0;
	new_b_t=max(M[0],temp_new_b_t);
	//  clog << "No DR move accepted, or too many vars in last chain:" << endl
    }
    else if(DR_n_accept_adj==DR_n_proposed_adj)
    {
	temp_new_b_t=b_t + (b_t-1.0)/2.0;
	new_b_t=min(M[1],temp_new_b_t);
	//  clog << "All DR move accepted:" << endl
    }
    else if(DR_acceptance_rate<optimal)
    {
	double argument=log(b_t)/log(2.0)-delta_n;
	temp_new_b_t=pow(2.0,argument);
	new_b_t=max(M[0],temp_new_b_t);
	//clog << "Acceptance >0 and <1 and <optimal:" << endl
    }
    else if(DR_acceptance_rate>optimal)
    {
	double argument=log(b_t)/log(2.0)+delta_n;
	temp_new_b_t=pow(2.0,argument);
	new_b_t=min(M[1],temp_new_b_t);
	// clog << "Accepetance >0 and <1 and >optimal:" << endl
    }
    b_t=new_b_t;

    for(unsigned int chain=0;chain<n_chains;chain++)
    {
	//Saving the temperatures values
	if (Settings.moveLog)
	    log_.history[chain+1].push_back(chainsVector[chain_idx[chain]].getCurrentTemperature());

	double exponent=a_t[chain];
	if(!Settings.noTemperature)
	{
	    chainsVector[chain_idx[chain]].setCurrentTemperature(pow(new_b_t,exponent));
	}
	else
	{
	    chainsVector[chain_idx[chain]].setCurrentTemperature(1.0);
	}
    }

    DR->nb_calls_adj=0;
    DR->nb_calls=0;

    for(unsigned int row=0;row<DR->mat_moves_accepted.size();row++)
    {
	for(unsigned int col=0;col<DR->mat_moves_accepted[row].size();col++)
	{
	    DR->mat_moves_accepted[row][col]=0;
	    DR->mat_moves_proposed[row][col]=0;
	}
    }
}
