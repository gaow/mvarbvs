/* This file is part of ESS-OO.
 *      Copyright (c) Marc Chadeau-Hyam (m.chadeau@imperial.ac.uk)
 *                    Leonardo Bottolo (l.bottolo@imperial.ac.uk)
 *                    David Hastie (d.hastie@imperial.ac.uk)
 *      2014
 *
 * Software designed and restructured by Loizos Markides (lm1011@ic.ac.uk)
 * ESS-OO is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ESS-OO is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ESS-OO.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "AdaptiveMH.h"
#include <cmath>
using namespace std;

AdaptiveMH::AdaptiveMH() {
    n_batch=0;
    optimal=0.0;
    ls=0.0;
    delta_n=0.0;
    G_tilda_accept=0.0;
    G_tilda_accept_ins=0.0;
    G_tilda_n_sweep=0;
    G_tilda_n_sweep_ins=0;
    M.resize(2);
    
    if (Settings.moveLog) {
	log_.nb_sweep=0;
	log_.nb_accept=0;
	log_.sample_history.resize(4);
	log_.adapt_history.resize(4);
    }
}

AdaptiveMH::~AdaptiveMH() {
    M.clear();
    Ls.clear();
    log_.sample_history.clear();
    log_.adapt_history.clear();
}

void AdaptiveMH::set(unsigned int n_batch_from_read,
		     double g_AdMH_optimal_from_read,
		     double g_AdMH_ls_from_read,
		     unsigned int pX,
		     unsigned int burn_in,
		     double g_M_min_input,
		     double g_M_max_input)
{
    if(Settings.gSampleFlag)
    {
	n_batch= n_batch_from_read;
	optimal=g_AdMH_optimal_from_read;
	ls=g_AdMH_ls_from_read;

	if(fabs(g_M_min_input-0)<1e-10)
	{
	    M[0]=-0.5*std::log(pX);
	}
	else
	{
	    M[0]=g_M_min_input;
	}

	if(fabs(g_M_max_input-0)<1e-10)
	{
	    M[1]=0.5*std::log(pX);
	}
	else
	{
	    M[1]=g_M_max_input;
	}

	double temp1=fabs(M[0]-ls);
	double temp2=fabs(M[1]-ls);
	delta_n=max(temp1,temp2);
	delta_n/=(double)(burn_in)/(double)(n_batch);
    }
}


void AdaptiveMH::display()
{
    //clog << endl << "**********************************************************" << endl
    clog << endl << "******************** g_AdMH parameters ********************" << endl
	 << "\tn_batch = " << n_batch << endl
	 << "\toptimal = " << optimal << endl
	 << "\tls = " << ls << endl
	 << "\tM[0] = " << M[0] << " -- " << "M[1] = " << M[1] << endl
	 << "\tdelta_n = " << delta_n << endl
	 << "\tG_tilda_accept = " << G_tilda_accept << endl
	 << "\tG_tilda_accept_ins = " << G_tilda_accept_ins << endl
	 << "\tG_tilda_n_sweep = " << G_tilda_n_sweep << endl
	 << "\tG_tilda_n_sweep_ins = " << G_tilda_n_sweep_ins << endl
	 << "\tLs = " << endl << "\t";
    for(unsigned int col=0;col<Ls.size();col++)
    {
	clog << Ls[col] << " ";
	clog << "Ls size: " << Ls.size() << endl;
    }
    clog << endl;
    //   << "**********************************************************" << endl
    //	 << "**********************************************************" << endl << endl;
}

void AdaptiveMH::execute(vector<Chain>& chainsVector,
			 gsl_matrix* mat_Y,
			 double &g,
			 double k_prior,
			 unsigned int sweep,
			 vector <unsigned int > &chain_idx,
			 vector <unsigned int > &n_Models_visited,
			 gsl_rng *RandomNumberGenerator)
{

    double norm_mean=log(g);
    double norm_sd=exp(ls);
    double sample_tmp= norm_mean + gsl_ran_gaussian(RandomNumberGenerator,norm_sd);
    double g_prop=exp(sample_tmp);

    unsigned int n_chains=chainsVector.size();

    gsl_vector *prop_log_marg_condPost=gsl_vector_calloc(2);
    vector < double > store_log_marg;
    vector < double > store_log_cond_post;
    double cum_diff=0.0;

    for(unsigned int current_chain=0;current_chain<n_chains;current_chain++)
    {
	unsigned int pos_current_chain=chain_idx[current_chain];
	double current_log_cond_post=chainsVector[pos_current_chain].getLogCondPostForSweep(sweep);

	//Step 1: Getting X_gamma
	chainsVector[pos_current_chain].getProposedScore(prop_log_marg_condPost,
								chainsVector[pos_current_chain].getGammaVector(),
								g_prop,mat_Y,k_prior);

	n_Models_visited[sweep]++;
	// BIG DISCUSSION HERE:

	//Current ESS
	cum_diff+=((prop_log_marg_condPost->data[1]-current_log_cond_post)/
		   chainsVector[pos_current_chain].getCurrentTemperature());
	//Proposed change
	//cum_diff+=(prop_log_marg_condPost->data[0]-current_log_marg)/
	//			chainsVector[pos_current_chain].getCurrentTemperature();

	store_log_marg.push_back(prop_log_marg_condPost->data[0]);
	store_log_cond_post.push_back(prop_log_marg_condPost->data[1]);
    }//end of for chain

    if (Settings.moveLog)
	log_.nb_sweep++;

    // DISCUSSION :
    // Begin Change
    //  double logPG=getPriorG(PR,gSampleFlag,g);
    //  double logPG_Prop=getPriorG(PR,gSampleFlag,g_prop);
    //  cum_diff=cum_diff+logPG_Prop-logPG;
    // End Change

    double alpha_g=min(1.0,exp(cum_diff+log(g_prop)-log(g)));
    if(!std::isnan(alpha_g))
    {
	double rand_test = gsl_rng_uniform(RandomNumberGenerator);
	if(rand_test<alpha_g && g_prop>0.0)
	{
	    if (Settings.moveLog)
		log_.nb_accept++;
	    g=g_prop;
	    for(unsigned int chain=0;chain<n_chains;chain++)
	    {
		unsigned int pos_chain=chain_idx[chain];
		chainsVector[pos_chain].setLogCondPostForSweep(store_log_cond_post[chain],sweep);
		chainsVector[pos_chain].setLogMarginalForSweep(store_log_marg[chain],sweep);
	    }
	    G_tilda_accept++;
	    G_tilda_accept_ins++;
	}
    }
    else
    {
        //"alpha_g is NaN"
    }

    if (Settings.moveLog)
	log_.sample_history.push_back(g);

    G_tilda_n_sweep++;
    G_tilda_n_sweep_ins++;

    store_log_marg.clear();
    store_log_cond_post.clear();
    gsl_vector_free(prop_log_marg_condPost);

    ////////////////////////////////////////////////////
    //  Adaptation: every My_g_AdMH.n_batch sweeps
    ////////////////////////////////////////////////////

    if(sweep%n_batch==0)
    {
	updateLS(sweep);
    }
}

void AdaptiveMH::updateLS(unsigned int sweep)
{
    double local_accept_rate=(double)(G_tilda_accept_ins)/(double)(G_tilda_n_sweep_ins);
    if (Settings.moveLog) {
	log_.adapt_history[0].push_back((double)(sweep));
	log_.adapt_history[1].push_back(local_accept_rate);
	log_.adapt_history[2].push_back(ls);
    }

    double batchNumber = (double)sweep/(double)n_batch;
    double delta = (pow(batchNumber,-0.5)<delta_n ? pow(batchNumber,-0.5) : delta_n );
    if(local_accept_rate<optimal)
    {
	//Updating g_AdMH.ls
	ls-=delta;
	if(ls < M[0])
	{
	    ls = M[0];
	}
    }
    else
    {
	ls+=delta;
	if(ls > M[1])
	{
	    ls = M[1];
	}
    }

    G_tilda_accept_ins=0;
    G_tilda_n_sweep_ins=0;
    if (Settings.moveLog)
	log_.adapt_history[3].push_back(ls);
}

