/* This file is part of ESS-OO.
 *      Copyright (c) Marc Chadeau-Hyam (m.chadeau@imperial.ac.uk)
 *                    Leonardo Bottolo (l.bottolo@imperial.ac.uk)
 *                    David Hastie (d.hastie@imperial.ac.uk)
 *      2014
 *
 * Software designed and restructured by Loizos Markides (lm1011@ic.ac.uk)
 * ESS-OO is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ESS-OO is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ESS-OO.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "DelayedRejection.h"

using std::vector;

DelayedRejection::DelayedRejection() {
    nb_calls_adj=0;
    nb_calls=0;

    if (Settings.moveLog) {
	log_.move_history.resize(3);
	log_.freq.resize(0);
	log_.nb_sweep=0;
	log_.n_accept=0;
    }
}

DelayedRejection::~DelayedRejection() {
    // TODO Auto-generated destructor stub
}

void DelayedRejection::set(unsigned int n_chains)
{
    nb_calls_adj=0;
    nb_calls=0;
    mat_moves_accepted.resize(n_chains);
    for(unsigned int row=0;row<mat_moves_accepted.size();row++)
    {
	mat_moves_accepted[row].resize(n_chains);
    }

    mat_moves_proposed.resize(n_chains);
    for(unsigned int row=0;row<mat_moves_proposed.size();row++)
    {
	mat_moves_proposed[row].resize(n_chains);
    }
    if (Settings.moveLog)
	log_.freq.resize(n_chains);
}

void DelayedRejection::display()
{
    //clog << endl << "**********************************************************" << endl
    clog << endl << "********************** DR parameters *********************" << endl
	 << "\tnb_calls_adj = " << nb_calls_adj << endl
	 << "\tnb_calls = " << nb_calls << endl;
    //clog << endl
    clog << "\tMat_moves_accepted"
	 << " n_rows " << mat_moves_accepted.size()
	 << " -- ncol " << mat_moves_accepted[0].size() << endl;
    for(unsigned int row=0;row<mat_moves_accepted.size();row++)
    {
	clog <<  "\t";
	for(unsigned int col=0;col<mat_moves_accepted[row].size();col++)
	{
	    clog << mat_moves_accepted[row][col] << "\t";
	}
	clog << endl;
    }
    //clog << endl
    clog << "\tMat_moves_proposed"
	 << " n_rows " << mat_moves_proposed.size()
	 << " -- ncol= " << mat_moves_proposed[0].size() << endl;

    for(unsigned int row=0;row<mat_moves_proposed.size();row++)
    {
	clog <<  "\t";
	for(unsigned int col=0;col<mat_moves_proposed[row].size();col++)
	{
	    clog << mat_moves_proposed[row][col] << "\t";
	}
	clog << endl;
    }
    //clog << endl;
    //clog << "**********************************************************" << endl
    //	 << "**********************************************************" << endl << endl;
}

void DelayedRejection::execute(vector<Chain>& chainsVector,
			       vector <unsigned int > &chain_idx,
			       unsigned int sweep,
			       gsl_rng *RandomNumberGenerator)
{
    if (Settings.moveLog)
	log_.nb_sweep++;
    nb_calls++;

    //Step 1: sampling uniformly two different chains:
    unsigned int nb_chains=chain_idx.size();
    unsigned int c_1=0;
    unsigned int c_2=0;
    unsigned int c_1_adj=0;
    unsigned int c_2_adj=0;
    int delta=0;

    unsigned int stop_sampling=0;
    while(stop_sampling==0)
    {
	double rand_test=gsl_rng_uniform(RandomNumberGenerator)*(double)(nb_chains);
	c_1=(unsigned int)(rand_test);
	rand_test=gsl_rng_uniform(RandomNumberGenerator)*(double)(nb_chains);
	c_2=(unsigned int)(rand_test);
	int delta=c_1-c_2;
	if(delta!=0)
	{
	    stop_sampling=1;
	}
    }

    unsigned int pos_c1=chain_idx[c_1];
    unsigned int pos_c2=chain_idx[c_2];

    //Step2: Calculating the move Probability
    double argument=((chainsVector[pos_c2].getLogCondPostForSweep(sweep)-
		      chainsVector[pos_c1].getLogCondPostForSweep(sweep))*
		     (1.0/chainsVector[pos_c1].getCurrentTemperature() -
		      1.0/chainsVector[pos_c2].getCurrentTemperature()));
    double pbty_1=std::min(1.0,exp(argument));

    //Step3: Sampling Acceptance for the first proposed move.
    double rand_accept_1=gsl_rng_uniform(RandomNumberGenerator);
    if(std::isnan(pbty_1)==1 || pbty_1==0.0)
    {
	//pbty_1 is nan or null -- move rejected
    }
    else
    {
	//pbty_1 is numeric and >0.0
	if(rand_accept_1<pbty_1)
	{
	    //Accept c_1 <-> c_2 move
	    //First proposed move ACCEPTED
	    delta=c_1-c_2;
	    if(abs(delta)==1)
	    {
		nb_calls_adj++;
	    }
	    mat_moves_accepted[c_1][c_2]++;
	    mat_moves_accepted[c_2][c_1]++;
	    mat_moves_proposed[c_1][c_2]++;
	    mat_moves_proposed[c_2][c_1]++;

	    if (Settings.moveLog) {
		log_.move_history[0].push_back(sweep);
		log_.move_history[1].push_back(c_1);
		log_.move_history[2].push_back(c_2);
		log_.n_accept++;
		log_.freq[c_1]++;
		log_.freq[c_2]++;
	    }

	    unsigned int pos_c1_i=chain_idx[c_1];
	    unsigned int pos_c2_i=chain_idx[c_2];
	    chain_idx[c_1]=pos_c2_i;
	    chain_idx[c_2]=pos_c1_i;

	    double tempTemperature = chainsVector[pos_c1_i].getCurrentTemperature();
	    chainsVector[pos_c1_i].setCurrentTemperature(chainsVector[pos_c2_i].getCurrentTemperature());
	    chainsVector[pos_c2_i].setCurrentTemperature(tempTemperature);
	}
	else
	{
	    //First proposed move Rejected
	    //Re-sampling tow adjascent chains
	    double rand_test=gsl_rng_uniform(RandomNumberGenerator)*(double)(nb_chains);
	    c_1_adj=(unsigned int)(rand_test);
	    rand_test=gsl_rng_uniform(RandomNumberGenerator)*(double)(nb_chains);
	    c_2_adj=(unsigned int)(rand_test);
	    delta=c_1_adj-c_2_adj;
	    if(abs(delta)!=1)
	    {
		if(c_1_adj==0)
		{
		    //if first chain sampled, the other one is second
		    c_2_adj=1;
		}
		else if(c_1_adj==nb_chains-1)
		{
		    //if last chain sampled, the other one is next to last
		    c_2_adj=c_1_adj-1;
		}
		else
		{
		    //otherwise one takes with probability 50% the one below or above
		    double rand_bin=gsl_rng_uniform(RandomNumberGenerator);
		    if(rand_bin<0.5)
		    {
			c_2_adj=c_1_adj-1;
		    }
		    else
		    {
			c_2_adj=c_1_adj+1;
		    }
		}
	    }
	    nb_calls_adj++;
	    mat_moves_proposed[c_1_adj][c_2_adj]++;
	    mat_moves_proposed[c_2_adj][c_1_adj]++;

	    unsigned int pos_c1_adj=chain_idx[c_1_adj];
	    unsigned int pos_c2_adj=chain_idx[c_2_adj];

	    double arg_adj=((chainsVector[pos_c2_adj].getLogCondPostForSweep(sweep)-
			     chainsVector[pos_c1_adj].getLogCondPostForSweep(sweep))*
			    (1.0/chainsVector[pos_c1_adj].getCurrentTemperature() -
			     1.0/chainsVector[pos_c2_adj].getCurrentTemperature()));

	    //Sampling two other candidates:
	    stop_sampling=0;
	    while(stop_sampling==0)
	    {
		rand_test=gsl_rng_uniform(RandomNumberGenerator)*(double)(nb_chains);

		c_1=(unsigned int)(rand_test);
		rand_test=gsl_rng_uniform(RandomNumberGenerator)*(double)(nb_chains);
		c_2=(unsigned int)(rand_test);
		int delta=c_1-c_2;
		if(delta!=0)
		{
		    stop_sampling=1;
		}
	    }

	    pos_c1=chain_idx[c_1];
	    pos_c2=chain_idx[c_2];

	    double arg_num=((chainsVector[pos_c2].getLogCondPostForSweep(sweep)-
			     chainsVector[pos_c1].getLogCondPostForSweep(sweep))*
			    (1.0/chainsVector[pos_c1].getCurrentTemperature() -
			     1.0/chainsVector[pos_c2].getCurrentTemperature()));

	    double pbty_2=std::min(1.0,(exp(arg_num)/exp(arg_adj)));//alpha_DR_star=alpha_DR_num

	    double tmp_pbty_final= exp(arg_adj)*((1.0-pbty_2)/(1.0-pbty_1));
	    double pbty_final=std::min(1.0,tmp_pbty_final);
	    double rand_accept_2=gsl_rng_uniform(RandomNumberGenerator);

	    if(std::isnan(pbty_final)==1)
	    {
		//Pbty for second DR move is nan: move rejected
	    }
	    else
	    {
		if(rand_accept_2<pbty_final)
		{
		    // Second proposed move ACCEPTED
		    mat_moves_accepted[c_1_adj][c_2_adj]++;
		    mat_moves_accepted[c_2_adj][c_1_adj]++;

		    if (Settings.moveLog) {
			log_.move_history[0].push_back(sweep);
			log_.move_history[1].push_back(c_1_adj);
			log_.move_history[2].push_back(c_2_adj);
			log_.n_accept++;
			log_.freq[c_1_adj]++;
			log_.freq[c_2_adj]++;
		    }

		    unsigned int pos_c1_i=chain_idx[c_1_adj];
		    unsigned int pos_c2_i=chain_idx[c_2_adj];

		    chain_idx[c_1_adj]=pos_c2_i;
		    chain_idx[c_2_adj]=pos_c1_i;
		    double tempTemperature = chainsVector[pos_c1_i].getCurrentTemperature();
		    chainsVector[pos_c1_i].setCurrentTemperature(chainsVector[pos_c2_i].getCurrentTemperature());
		    chainsVector[pos_c2_i].setCurrentTemperature(tempTemperature);
		}
		else
		{
		    //Second proposed move Rejected
		}
	    }
	}//end of else: second move tried;
    }//pbty_1 is >0.0 and numeric
}
