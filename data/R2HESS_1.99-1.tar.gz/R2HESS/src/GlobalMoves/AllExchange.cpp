/* This file is part of ESS-OO.
 *      Copyright (c) Marc Chadeau-Hyam (m.chadeau@imperial.ac.uk)
 *                    Leonardo Bottolo (l.bottolo@imperial.ac.uk)
 *                    David Hastie (d.hastie@imperial.ac.uk)
 *      2014
 *
 * Software designed and restructured by Loizos Markides (lm1011@ic.ac.uk)
 * ESS-OO is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ESS-OO is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ESS-OO.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "AllExchange.h"

AllExchange::AllExchange() {
    description_exchange_move_=NULL;
    if (Settings.moveLog) {
	log_.move_history.resize(3);
	log_.nb_sweep=0;
	log_.n_accept=0;
	
	log_.freq.resize(0);
    }
}

AllExchange::~AllExchange() {
    gsl_matrix_free(description_exchange_move_);
}


void AllExchange::set(unsigned int n_chains)
{
    initialize_description_exch_moves(n_chains);
}


void AllExchange::display()
{

}

void AllExchange::execute(std::vector<Chain>& chainsVector,
			  std::vector <unsigned int > &chain_idx,
			  unsigned int sweep,
			  gsl_rng *RandomNumberGenerator)
{
    //clog << "Description exchange move init" << endl;

    //display_gsl_matrix(description_exchange_move);

    double cum_pbty=1.0;
    unsigned int rank=1;
    unsigned int nb_chains=chain_idx.size();
    unsigned int nb_cols=description_exchange_move_->size2;
    description_exchange_move_->data[2*description_exchange_move_->size2]=1.0;
    if (Settings.moveLog)
	log_.nb_sweep++;

    //Step 1: Calculating the exchange move pbties
    for(unsigned int c1=0;c1<nb_chains-1;c1++)
    {
	for(unsigned int c2=c1+1;c2<nb_chains;c2++)
	{
	    unsigned int pos_c1=chain_idx[c1];
	    unsigned int pos_c2=chain_idx[c2];
	    // WARNING the last log_cond_post is taken into account
	    // i.e. all exchange always after local move
	    double argument=((chainsVector[pos_c2].getLogCondPostForSweep(sweep)-
			      chainsVector[pos_c1].getLogCondPostForSweep(sweep))*
			     (1.0/chainsVector[pos_c1].getCurrentTemperature() -
			      1.0/chainsVector[pos_c2].getCurrentTemperature()));
	    double pbty=exp(argument);
	    if(std::isnan(pbty)==1)
	    {
		pbty=0.0;
	    }
	    description_exchange_move_->data[2*nb_cols+rank]=pbty;
	    cum_pbty+=pbty;

            rank++;
	}
    }

    //Step 2: Standardizing the pbty vector
    for(unsigned int col=0;col<description_exchange_move_->size2;col++)
    {
	description_exchange_move_->data[2*nb_cols+col]/=cum_pbty;
    }

    //Step 3: Sampling the exchange move
    int my_sample=SampleFromDiscrete_All_exchange(description_exchange_move_,
						  RandomNumberGenerator);

    //step 4: Updating chain_idx
    unsigned int c1=description_exchange_move_->data[my_sample];
    unsigned int c2=description_exchange_move_->data[nb_cols+my_sample];

    if (Settings.moveLog) {
	log_.move_history[0].push_back(sweep);
	log_.move_history[1].push_back(c1);
	log_.move_history[2].push_back(c2);
    }

    if(my_sample>0)
    {
	if (Settings.moveLog) {
	    log_.n_accept++;
	    log_.freq[c1]++;
	    log_.freq[c2]++;
	}

	unsigned int pos_c1_i=chain_idx[c1];
	unsigned int pos_c2_i=chain_idx[c2];
	chain_idx[c1]=pos_c2_i;
	chain_idx[c2]=pos_c1_i;
	double tempTemperature = chainsVector[pos_c1_i].getCurrentTemperature();
	chainsVector[pos_c1_i].setCurrentTemperature(chainsVector[pos_c2_i].getCurrentTemperature());
	chainsVector[pos_c2_i].setCurrentTemperature(tempTemperature);
    }
    //clog << "Description exchange move final" << endl;
    //display_gsl_matrix(description_exchange_move);
}

int AllExchange::SampleFromDiscrete_All_exchange(gsl_matrix *description_all_exchange,
						 gsl_rng *RandomNumberGenerator)
{
    unsigned int k = 0;
    std::vector<double> cdf;
    double u = gsl_rng_uniform(RandomNumberGenerator);
    unsigned int ncol=description_all_exchange->size2;

    double pbty=description_all_exchange->data[2*ncol];
    cdf.push_back(pbty);
    for(unsigned int i=1;i<ncol;i++)
    {
	pbty=description_all_exchange->data[2*ncol+i];
	cdf.push_back(cdf[i-1]+pbty);
    }

    while( u > cdf[k] && k < cdf.size())
    {
	k++;
    }
    cdf.clear();
    return k;
}

void AllExchange::initialize_description_exch_moves(unsigned int nb_chains)
{
    //description_exchange_move: each move is presented in columns
    // -line 1: first chain
    // -line 2: second chain
    // -line 3: Pbty of the move

    unsigned int nb_columns=(nb_chains*(nb_chains - 1)/2) + 1;
    description_exchange_move_=gsl_matrix_calloc(3,nb_columns);
    unsigned int rank=1;

    for(unsigned int c1=0;c1<nb_chains-1;c1++)
    {
	for(unsigned int c2=c1+1;c2<nb_chains;c2++)
	{
	    description_exchange_move_->data[rank]=c1;
	    description_exchange_move_->data[nb_columns+rank]=c2;
	    rank++;
	}
    }

    if (Settings.moveLog)
	log_.freq.resize(nb_chains);
}

