/* This file is part of ESS-OO.
 *      Copyright (c) Marc Chadeau-Hyam (m.chadeau@imperial.ac.uk)
 *                    Leonardo Bottolo (l.bottolo@imperial.ac.uk)
 *                    David Hastie (d.hastie@imperial.ac.uk)
 *      2014
 *
 * Software designed and restructured by Loizos Markides (lm1011@ic.ac.uk)
 * ESS-OO is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ESS-OO is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ESS-OO.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef ADAPTIVEMH_H_
#define ADAPTIVEMH_H_
#include <iostream>

#include <fstream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_sort_vector.h>
#include <math.h>
#include <gsl/gsl_statistics_double.h>
#include <vector>
#include <algorithm>
#include "GlobalMove.h"

class AdaptiveMH: public GlobalMove {
public:
    unsigned int n_batch;
    double optimal;
    double ls;
    double delta_n;
    
    unsigned int G_tilda_accept;
    unsigned int G_tilda_accept_ins;
    unsigned int G_tilda_n_sweep;
    unsigned int G_tilda_n_sweep_ins;
    std::vector < double > M;
    std::vector < double > Ls;
    std::vector<double> store_log_marg;
    std::vector<double> store_log_cond_post;

    AdaptiveMHLog log_;

    AdaptiveMH();
    virtual ~AdaptiveMH();
    virtual void set(unsigned int n_batch_from_read,
		     double g_AdMH_optimal_from_read,
		     double g_AdMH_ls_from_read,
		     unsigned int pX,
		     unsigned int burn_in,
		     double g_M_min_input,
		     double g_M_max_input);
    virtual void display();
    virtual void execute(std::vector<Chain>& chainsVector,
			 gsl_matrix* mat_Y,
			 double &g,
			 double k_prior,
			 unsigned int sweep,
			 std::vector <unsigned int > &chain_idx,
			 std::vector <unsigned int > &n_Models_visited,
			 gsl_rng *RandomNumberGenerator);
    void updateLS(unsigned int sweep);
};

#endif /* ADAPTIVEMH_H_ */
