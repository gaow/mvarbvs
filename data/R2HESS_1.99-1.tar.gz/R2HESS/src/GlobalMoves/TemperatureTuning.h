/* This file is part of ESS-OO.
 *      Copyright (c) Marc Chadeau-Hyam (m.chadeau@imperial.ac.uk)
 *                    Leonardo Bottolo (l.bottolo@imperial.ac.uk)
 *                    David Hastie (d.hastie@imperial.ac.uk)
 *      2014
 *
 * Software designed and restructured by Loizos Markides (lm1011@ic.ac.uk)
 * ESS-OO is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ESS-OO is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ESS-OO.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef TEMPERATURETUNING_H_
#define TEMPERATURETUNING_H_
#include "GlobalMove.h"
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_sort_vector.h>
#include <math.h>
#include <gsl/gsl_statistics_double.h>
#include <gsl/gsl_math.h>
#include <vector>
#include "DelayedRejection.h"

class TemperatureTuning:public GlobalMove{
public:
    TemperatureLog log_;
    unsigned int C;
    double b_t;
    double a_t_den;
    std::vector < double > a_t;
    unsigned int nbatch;
    std::vector < double > M;
    double delta_n;
    double optimal;
    unsigned int c_idx;
    
    TemperatureTuning();
    virtual ~TemperatureTuning();
    void set(std::vector<Chain>& chainsVector,
	     std::vector <unsigned int > &chain_idx,
	     unsigned int nb_chains,
	     unsigned int pX,
	     double b_t_input,
	     double a_t_den_inf_5k,
	     double a_t_den_5_10k,
	     double a_t_den_sup_10k,
	     unsigned int nbatch_input,
	     std::vector < double > &M_input,
	     unsigned int burn_in,
	     double optimal_input);
    void display();
    void execute(DelayedRejection *DR,
		 std::vector<Chain>& chainsVector,
		 std::vector <unsigned int > &chain_idx,
		 unsigned int sweep,
		 unsigned int n_vars_in_last_chain,
		 unsigned int nX);
private:
};

#endif /* TEMPERATURETUNING_H_ */
