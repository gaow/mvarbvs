/* This file is part of ESS-OO.
 *      Copyright (c) Marc Chadeau-Hyam (m.chadeau@imperial.ac.uk)
 *                    Leonardo Bottolo (l.bottolo@imperial.ac.uk)
 *                    David Hastie (d.hastie@imperial.ac.uk)
 *      2014
 *
 * Software designed and restructured by Loizos Markides (lm1011@ic.ac.uk)
 * ESS-OO is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ESS-OO is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ESS-OO.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef CROSSOVER_H_
#define CROSSOVER_H_

#include "GlobalMove.h"
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_sort_vector.h>
#include <math.h>
#include <cmath>
#include <vector>
#include "../UtilityClasses/MatrixManipulation.h"

class Crossover: public GlobalMove {
public:
    CrossoverLog log_;
    unsigned int n_max_breakpoint;
    std::vector < unsigned int  > list_CM_moves_enabled;
    std::vector < double > unit_move_pbty_cum;
    unsigned int n_possible_CM_moves;

    Crossover();
    virtual ~Crossover();
    virtual void set(unsigned int k_max,
		     std::vector < unsigned int  > &list_CM_moves_enabled_from_read);
    virtual void display();

    void execute(std::vector<Chain>& chainsVector,
		 gsl_matrix *mat_X,
		 gsl_matrix *mat_Y,
		 std::vector <unsigned int > &chain_idx,
		 unsigned int sweep,
		 std::vector <unsigned int > &n_Models_visited,
		 unsigned int maxPX,
		 double g,
		 double k_prior,
		 gsl_rng *RandomNumberGenerator);

private:
    unsigned int SampleFromDiscrete_new(std::vector<double> &cdf,
					gsl_rng *RandomNumberGenerator);
    unsigned int SampleFromDiscrete_non_cum(std::vector<double> &pbty,
					    gsl_rng *RandomNumberGenerator);
    double computeLogCondPostBoltz(gsl_vector* const logCondPostVec,
				   const double& chosenT,
				   const unsigned int& c1,
				   const unsigned int& c2,
				   const unsigned int& cTrunc);
    void computeAndSampleCondPostBoltz(std::vector<Chain>& chainsVector,
				       std::vector<double>& condPostBoltzProb,
				       std::vector<unsigned int>& sampledChains,
				       const unsigned int& nChains,
				       const unsigned int& cTrunc,
				       const unsigned int& sweep,
				       const std::vector<unsigned int>& chainIdx,
				       double& chosenT,
				       gsl_rng *RandomNumberGenerator);
    void define_haplotype_bkpts(std::vector < unsigned int > &r_idx,
				unsigned int pos_crsv,
				gsl_matrix *mat_X);

    unsigned int recombine_chains(std::vector<Chain>& chainsVector,
				  std::vector < bool > &vect_gam_prop_c1,
				  std::vector < bool > &vect_gam_prop_c2,
				  unsigned int n_vars_tot,
				  std::vector < unsigned int > &sampled_chains,
				  std::vector <unsigned int > &chain_idx,
				  double *pos_bkpts,
				  unsigned int n_bkpts);

    unsigned int recombine_haplotype(std::vector<Chain>& chainsVector,
				     std::vector < bool > &vect_gam_prop_c1,
				     std::vector < bool > &vect_gam_prop_c2,
				     unsigned int n_vars_tot,
				     std::vector < unsigned int > &sampled_chains,
				     std::vector <unsigned int > &chain_idx,
				     std::vector <unsigned int > &r_idx);
};

#endif /* CROSSOVER_H_ */
