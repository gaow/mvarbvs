/* This file is part of ESS-OO.
 *      Copyright (c) Marc Chadeau-Hyam (m.chadeau@imperial.ac.uk)
 *                    Leonardo Bottolo (l.bottolo@imperial.ac.uk)
 *                    David Hastie (d.hastie@imperial.ac.uk)
 *      2014
 *
 * Software designed and restructured by Loizos Markides (lm1011@ic.ac.uk)
 * ESS-OO is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ESS-OO is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ESS-OO.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef DELAYEDREJECTION_H_
#define DELAYEDREJECTION_H_

#include "GlobalMove.h"
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_sort_vector.h>
#include <math.h>
#include <vector>
#include "../UtilityClasses/MatrixManipulation.h"

class DelayedRejection:public GlobalMove{
public:
    DelayedRejectionLog log_;
    unsigned int nb_calls_adj;
    unsigned int nb_calls;
    std::vector < std::vector < unsigned int > > mat_moves_accepted;
    std::vector < std::vector < unsigned int > > mat_moves_proposed;
    
    DelayedRejection();
    virtual ~DelayedRejection();
    virtual void set(unsigned int n_chains);
    virtual void display();
    virtual void execute(std::vector<Chain>& chainsVector,
			 std::vector <unsigned int > &chain_idx,
			 unsigned int sweep,
			 gsl_rng *RandomNumberGenerator);
private:
};

#endif /* DELAYEDREJECTION_H_ */
