/* This file is part of ESS-OO.
 *      Copyright (c) Marc Chadeau-Hyam (m.chadeau@imperial.ac.uk)
 *                    Leonardo Bottolo (l.bottolo@imperial.ac.uk)
 *                    David Hastie (d.hastie@imperial.ac.uk)
 *      2014
 *
 * Software designed and restructured by Loizos Markides (lm1011@ic.ac.uk)
 * ESS-OO is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ESS-OO is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ESS-OO.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "Crossover.h"

using namespace std;

Crossover::Crossover() {
    n_max_breakpoint=0;
    n_possible_CM_moves=0;
    
    if (Settings.moveLog) {
	log_.nb_sweep=0;
	log_.nb_model=0;
	log_.nb_accept=0;
	log_.history.resize(5);
    }
}


Crossover::~Crossover() {
    // TODO Auto-generated constructor stub
}

void Crossover::set(unsigned int k_max_from_read,
		    vector < unsigned int  > &list_CM_moves_enabled_from_read)
{
    unsigned int Is_k_point_CM_in=0;
    n_max_breakpoint=k_max_from_read;

    //Getting the number of possible Crossover moves
    for(unsigned int col=0;col<list_CM_moves_enabled_from_read.size();col++)
    {
	if(list_CM_moves_enabled_from_read[col]==1)
	{
	    Is_k_point_CM_in=1;
	    if(n_max_breakpoint==0)
	    {
		//error clause when n max is 0
		clog << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl
		     << "           WARNING" << endl
		     << "  k-point CM enabled, but" << endl
		     << "    n_max_breakpoint is set to 0" << endl
		     << " ****** Run stopped ****** " << endl
		     << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
		exit(1);
	    }
	}
    }

    //Calculating the probability of each move: col in 0:k-1: k-point CM; k haplotype
    n_possible_CM_moves=Is_k_point_CM_in*(n_max_breakpoint)+(list_CM_moves_enabled_from_read.size()-1);

    unit_move_pbty_cum.resize(n_possible_CM_moves);

    if(unit_move_pbty_cum.size()>1)
    {
	for(unsigned int col=0;col<unit_move_pbty_cum.size();col++)
	{
	    unit_move_pbty_cum[col]=(double)(col+1)/(double)(n_possible_CM_moves);
	}
    }

    if (Settings.moveLog) {
	log_.n_nb_sweep_per_CM_move.resize(n_possible_CM_moves);
	log_.n_nb_accept_per_CM_move.resize(n_possible_CM_moves);
	for(unsigned int col=0;col<log_.n_nb_sweep_per_CM_move.size();col++){
	    log_.n_nb_sweep_per_CM_move[col]=0;
	    log_.n_nb_accept_per_CM_move[col]=0;
	}
    }

}


void Crossover::display()
{
    //clog << endl << "**********************************************************" << endl
    clog << endl << "********************** CM parameters *********************" << endl
	 << "\tn_max_breakpoint = " << n_max_breakpoint << endl
	 << "\tnb_possible_CM_move = " << n_possible_CM_moves << endl
	 << "\tInit CM pbty cum:" << endl
	 << "\t";

    for(unsigned int col=0;col< unit_move_pbty_cum.size();col++)
    {
	clog << unit_move_pbty_cum[col] << " ";
    }
    clog << endl;
    //	 << "**********************************************************" << endl
    //	 << "**********************************************************" << endl << endl;
}

void Crossover::execute(vector<Chain>& chainsVector,
			gsl_matrix *mat_X,
			gsl_matrix *mat_Y,
			vector <unsigned int > &chain_idx,
			unsigned int sweep,
			vector <unsigned int > &n_Models_visited,
			unsigned int maxPX,
			double g,
			double k_prior,
			gsl_rng *RandomNumberGenerator)
{
    unsigned int n_chains=chain_idx.size();
    unsigned int c_trunc=(unsigned int)(max(ceil((double)(n_chains)*Prior::Prob_sel),2.0));
    vector < double > vect_pbty_Boltz;
    vector < unsigned int > sampled_chains;
    vect_pbty_Boltz.resize(n_chains);
    sampled_chains.resize(2);
    unsigned int n_vars_tot=mat_X->size2;
    if (Settings.moveLog) {
	log_.nb_sweep++;
	log_.nb_model+=2;
    }

    unsigned int n_pts_recomb=0;
    unsigned int n_changes=0;

    double chosenT;
    //Step 1: Sampling the two chains
    //Step 1.1: Sampling the two chains and calculating the Boltz Pbty vector.

    computeAndSampleCondPostBoltz(chainsVector,
				  vect_pbty_Boltz,
				  sampled_chains,
				  n_chains,
				  c_trunc,
				  sweep,
				  chain_idx,
				  chosenT,
				  RandomNumberGenerator);

    //Step 2: Sampling the CM type
    unsigned int type_CM_move_sampled=SampleFromDiscrete_new(unit_move_pbty_cum,
							     RandomNumberGenerator);
    if (Settings.moveLog)
	log_.n_nb_sweep_per_CM_move[type_CM_move_sampled]++;

    vector < bool > vect_gam_prop_c1;
    vector < bool > vect_gam_prop_c2;

    vect_gam_prop_c1.resize(n_vars_tot);
    vect_gam_prop_c2.resize(n_vars_tot);

    //Step 3: Sampling the position of the breakpoints
    if(type_CM_move_sampled<n_max_breakpoint)
    {
	unsigned int n_bkpts=type_CM_move_sampled +1;
	n_pts_recomb=n_bkpts;

	double *pos_bkpts = new double[n_bkpts];
	double *full_vars = new double[n_vars_tot-1];
	//we do not sample bkpt at pos=0 or nvars

	for(unsigned current_var=0;current_var<n_vars_tot-1;current_var++)
	{
	    full_vars[current_var]=current_var;
	}
	gsl_ran_choose(RandomNumberGenerator, pos_bkpts, n_bkpts, full_vars, n_vars_tot-1, sizeof(double));
	gsl_sort(pos_bkpts,1,n_bkpts);
	for(unsigned int curr_bkpt=0;curr_bkpt<n_bkpts;curr_bkpt++)
	{
	    pos_bkpts[curr_bkpt]+=1;
	}
	delete [] full_vars;

	//Step 4: Generating the two candidate chains
	n_changes=recombine_chains(chainsVector,
				   vect_gam_prop_c1,
				   vect_gam_prop_c2,
				   n_vars_tot,
				   sampled_chains,
				   chain_idx,
				   pos_bkpts,
				   n_bkpts);


	delete [] pos_bkpts;
    }
    else
    {
	//Haplotype Crossover Move sampled
	//Sampling the position of the crossover
	unsigned int pos_crsv=(unsigned int)(gsl_rng_uniform(RandomNumberGenerator)*(double)(n_vars_tot));
	vector < unsigned int > r_idx;
	define_haplotype_bkpts(r_idx,
			       pos_crsv,
			       mat_X);
	n_pts_recomb=r_idx.size();

	n_changes=recombine_haplotype(chainsVector,
				      vect_gam_prop_c1,
				      vect_gam_prop_c2,
				      n_vars_tot,
				      sampled_chains,
				      chain_idx,
				      r_idx);

	r_idx.clear();
    }

    bool autoReject = false;
    unsigned int nVarsInPropC1=0, nVarsInPropC2=0;
    for(unsigned int j=0;j<n_vars_tot;j++)
    {
	if(vect_gam_prop_c1[j]==1)
	{
	    nVarsInPropC1++;
	}
	if(vect_gam_prop_c2[j]==1)
	{
	    nVarsInPropC2++;
	}
    }

    // Make sure that the move doesn't make one or the chains have more than the
    // maximum allowed
    double alpha_CM=0.0;
    gsl_vector *prop_log_marg_condPost_c1=gsl_vector_calloc(2);
    gsl_vector *prop_log_marg_condPost_c2=gsl_vector_calloc(2);
    unsigned int c1=sampled_chains[0];
    unsigned int c2=sampled_chains[1];
    unsigned int pos_c1=chain_idx[c1];
    unsigned int pos_c2=chain_idx[c2];
    gsl_vector *vect_log_cond_post_init=gsl_vector_calloc(n_chains);
    gsl_vector *vect_log_cond_post_prop=gsl_vector_calloc(n_chains);

    if(nVarsInPropC1>maxPX||nVarsInPropC2>maxPX)
    {
	autoReject = true;
    }
    else
    {	  //Step 5: Calculating logCondPost/logMarg for both candidate chains
	chainsVector[pos_c1].getProposedScore(prop_log_marg_condPost_c1,
						     vect_gam_prop_c1,
						     g,mat_Y,k_prior);

	chainsVector[pos_c2].getProposedScore(prop_log_marg_condPost_c2,
						     vect_gam_prop_c2,
						     g,mat_Y,k_prior);

	if(n_changes>0)
	{
	    n_Models_visited[sweep]+=2;
	}

	for(unsigned int chain=0;chain<n_chains;chain++)
	{
	    unsigned int pos_chain=chain_idx[chain];
	    vect_log_cond_post_init->data[chain]=chainsVector[pos_chain].getLogCondPostForSweep(sweep);
	    if(chain==sampled_chains[0])
	    {
		vect_log_cond_post_prop->data[chain]=prop_log_marg_condPost_c1->data[1];
	    }
	    else if(chain==sampled_chains[1])
	    {
		vect_log_cond_post_prop->data[chain]=prop_log_marg_condPost_c2->data[1];
	    }
	    else
	    {
		vect_log_cond_post_prop->data[chain]=vect_log_cond_post_init->data[chain];
	    }
	}

	//Step 6: Calculating the acceptance pbty

	double log_T_x_y=log(vect_pbty_Boltz[c1])+log(vect_pbty_Boltz[c2])-log(1-vect_pbty_Boltz[c1]);
	double log_T_y_x=computeLogCondPostBoltz(vect_log_cond_post_prop,
						 chosenT,
						 c1,
						 c2,
						 c_trunc);

	double R_CM=((vect_log_cond_post_prop->data[c1]- vect_log_cond_post_init->data[c1]) *
		     (1.0 / chainsVector[pos_c1].getCurrentTemperature())+
		     (vect_log_cond_post_prop->data[c2]- vect_log_cond_post_init->data[c2]) *
		     (1.0 / chainsVector[pos_c2].getCurrentTemperature())+
		     log_T_y_x-log_T_x_y);

	alpha_CM=min(1.0,exp(R_CM));
    }

    double accept_test=gsl_rng_uniform(RandomNumberGenerator);
    //Step 7: Updating X_gam, and log_condPost/log_marg
    if(accept_test< alpha_CM&&!autoReject)
    {
	if (Settings.moveLog) {
	    log_.nb_accept++;
	    log_.n_nb_accept_per_CM_move[type_CM_move_sampled]++;
	    log_.history[0].push_back(sweep);
	    log_.history[1].push_back(type_CM_move_sampled);
	    log_.history[2].push_back(n_pts_recomb);
	    log_.history[3].push_back(c1);
	    log_.history[4].push_back(c2);
	}

	//Move accepted
	//Updating log_cond_post and logmarg

	chainsVector[pos_c1].setLogMarginalForSweep(prop_log_marg_condPost_c1->data[0],sweep);
	chainsVector[pos_c1].setLogCondPostForSweep(prop_log_marg_condPost_c1->data[1],sweep);

	chainsVector[pos_c2].setLogMarginalForSweep(prop_log_marg_condPost_c2->data[0],sweep);
	chainsVector[pos_c2].setLogCondPostForSweep(prop_log_marg_condPost_c2->data[1],sweep);

	//Updating the vect_gam
	chainsVector[pos_c1].updateGammaVector(vect_gam_prop_c1);
	chainsVector[pos_c2].updateGammaVector(vect_gam_prop_c2);
    }
    else
    {
	//Move Rejected"
    }

    gsl_vector_free(prop_log_marg_condPost_c1);
    gsl_vector_free(prop_log_marg_condPost_c2);

    gsl_vector_free(vect_log_cond_post_init);
    gsl_vector_free(vect_log_cond_post_prop);

    vect_gam_prop_c1.clear();
    vect_gam_prop_c2.clear();
    sampled_chains.clear();
    vect_pbty_Boltz.clear();
}

double Crossover::computeLogCondPostBoltz(gsl_vector* const logCondPostVec,
					  const double& chosenT,
					  const unsigned int& c1,
					  const unsigned int& c2,
					  const unsigned int& cTrunc)
{
    // Step 1. Rank the chains according to their logCondPost
    unsigned int nChains=logCondPostVec->size;

    gsl_permutation* logCondPostSortIdx=gsl_permutation_calloc(nChains);
    gsl_sort_vector_index(logCondPostSortIdx,logCondPostVec);
    gsl_vector* IdxVec=gsl_vector_calloc(nChains);
    gsl_permutation_reverse(logCondPostSortIdx);
    for(unsigned int i=0;i<nChains;i++)
    {
	IdxVec->data[i]=logCondPostSortIdx->data[i];
    }

    gsl_permutation* logCondPostSortRank=gsl_permutation_calloc(nChains);
    gsl_sort_vector_index(logCondPostSortRank,IdxVec);

    double maxLogCondPost=logCondPostVec->data[logCondPostSortIdx->data[0]];

    double Z=0.0;
    for(unsigned int i=0;i<nChains;i++)
    {
	Z+=exp((logCondPostVec->data[i]-maxLogCondPost)/chosenT);
    }

    double normConst=0.0;
    for(unsigned int currChain=0;currChain<nChains;currChain++)
    {
	unsigned int currRank = logCondPostSortRank->data[currChain];
	if(currRank<cTrunc)
	{
	    normConst+=1.0e-10+exp((logCondPostVec->data[currChain]-maxLogCondPost)/chosenT)/Z;
	}
	else
	{
	    normConst+=1.0e-10;
	}
    }

    double result=0.0;
    // Contribution from chain c1
    if(logCondPostSortRank->data[c1]<cTrunc)
    {
	result+=log(1.0e-10+exp((logCondPostVec->data[c1]-maxLogCondPost)/chosenT)/Z)-log(normConst);
    }
    else
    {
	result+=log(1.0e-10)-log(normConst);
    }

    // Contribution from chain c2
    double chain1Prob = exp(result);
    if(logCondPostSortRank->data[c2]<cTrunc)
    {
	result+=log(1.0e-10+exp((logCondPostVec->data[c2]-maxLogCondPost)/chosenT)/Z)-log(normConst);
    }
    else
    {
	result+=log(1.0e-10)-log(normConst);
    }

    // Renormalise c2 prob as without replacement
    result-=log(1-chain1Prob);

    gsl_permutation_free(logCondPostSortIdx);
    gsl_permutation_free(logCondPostSortRank);
    gsl_vector_free(IdxVec);
    return(result);
}

void Crossover::computeAndSampleCondPostBoltz(vector<Chain>& chainsVector,
					      vector<double>& condPostBoltzProb,
					      vector<unsigned int>& sampledChains,
					      const unsigned int& nChains,
					      const unsigned int& cTrunc,
					      const unsigned int& sweep,
					      const vector<unsigned int>& chainIdx,
					      double& chosenT,
					      gsl_rng *RandomNumberGenerator)
{
    // Step 1. Sort the log conditional posterior of the chains
    gsl_vector* logCondPostInit=gsl_vector_calloc(nChains);
    double* chainTemps = new double[nChains];

    for(unsigned int currChain=0;currChain<nChains;currChain++)
    {
	unsigned int posChain = chainIdx[currChain];
	logCondPostInit->data[currChain]=chainsVector[posChain].getLogCondPostForSweep(sweep);
	chainTemps[currChain]=chainsVector[posChain].getCurrentTemperature();
    }

    gsl_permutation* logCondPostSortIdx=gsl_permutation_calloc(nChains);
    gsl_sort_vector_index(logCondPostSortIdx,logCondPostInit);
    gsl_vector* IdxVec=gsl_vector_calloc(nChains);
    gsl_permutation_reverse(logCondPostSortIdx);
    for(unsigned int i=0;i<nChains;i++)
    {
	IdxVec->data[i]=logCondPostSortIdx->data[i];
    }

    gsl_permutation* logCondPostSortRank=gsl_permutation_calloc(nChains);
    gsl_sort_vector_index(logCondPostSortRank,IdxVec);

    // Step 2. Get the temperature for the move
    gsl_sort(chainTemps,1,nChains);
    chosenT=gsl_stats_median_from_sorted_data(chainTemps,1,nChains);

    // Step 3. Calculate F_t (the Boltzmann normalising const) and p_t the Bolztmann probs
    double maxLogCondPost = logCondPostInit->data[logCondPostSortIdx->data[0]];
    double Z=0.0;
    for(unsigned int i=0;i<nChains;i++)
    {
	Z+=exp((logCondPostInit->data[i]-maxLogCondPost)/chosenT);
    }

    double normConst=0.0;
    for(unsigned int currChain=0;currChain<nChains;currChain++)
    {
	unsigned int currRank = logCondPostSortRank->data[currChain];
	if(currRank<cTrunc)
	{
	    condPostBoltzProb[currChain]=1.0e-10+exp((logCondPostInit->data[currChain]-maxLogCondPost)/chosenT)/Z;
	}
	else
	{
	    condPostBoltzProb[currChain]=1.0e-10;
	}
	normConst+=condPostBoltzProb[currChain];
    }

    for(unsigned int i=0;i<nChains;i++)
    {
	condPostBoltzProb[i]/=normConst;
    }

    //Sampling first chain
    unsigned int sampledChain1=SampleFromDiscrete_non_cum(condPostBoltzProb,RandomNumberGenerator);

    // Now remove the sampled chain (set it's prob to zero) and renormalise
    vector<double> condPostBoltzProbNew(condPostBoltzProb);
    condPostBoltzProbNew[sampledChain1] = 0.0;

    double normConstNew = 0.0;
    for (unsigned int i = 0; i < nChains; i++) {
	normConstNew += condPostBoltzProbNew[i];
    }

    for (unsigned int i = 0; i < nChains; i++) {
	condPostBoltzProbNew[i] /= normConstNew;
    }
       
    //Sampling second chain
    unsigned int sampledChain2=SampleFromDiscrete_non_cum(condPostBoltzProbNew,RandomNumberGenerator);
    sampledChains[0]=sampledChain1;
    sampledChains[1]=sampledChain2;

    delete [] chainTemps;
    gsl_permutation_free(logCondPostSortRank);
    gsl_permutation_free(logCondPostSortIdx);
    gsl_vector_free(IdxVec);
    gsl_vector_free(logCondPostInit);
}

unsigned int Crossover::SampleFromDiscrete_non_cum(vector<double> &pbty,
						   gsl_rng *RandomNumberGenerator)
{
    unsigned int k = 0;
    vector<double> cdf;
    double u = gsl_rng_uniform(RandomNumberGenerator);

    cdf.push_back(pbty[0]);

    for(unsigned int i=1;i<pbty.size();i++)
    {
	cdf.push_back(cdf[i-1]+pbty[i]);
    }

    while( u > cdf[k] && k < cdf.size())
    {
	k++;
    }
    return k;
}

unsigned int Crossover::SampleFromDiscrete_new( vector<double> &cdf,
						gsl_rng *RandomNumberGenerator)
{
    unsigned int k = 0;
    double u = gsl_rng_uniform(RandomNumberGenerator);
    while( u > cdf[k] && k < cdf.size())
    {
	k++;
    }
    return k;
}

unsigned int Crossover::recombine_chains(vector<Chain>& chainsVector,
					 vector < bool > &vect_gam_prop_c1,
					 vector < bool > &vect_gam_prop_c2,
					 unsigned int n_vars_tot,
					 vector < unsigned int > &sampled_chains,
					 vector <unsigned int > &chain_idx,
					 double *pos_bkpts,
					 unsigned int n_bkpts)
{
    unsigned int c1=sampled_chains[0];
    unsigned int pos_c1=chain_idx[c1];
    unsigned int c2=sampled_chains[1];
    unsigned int pos_c2=chain_idx[c2];
    unsigned int lower_bound=0;
    unsigned int upper_bound=0;
    unsigned int nb_interval=n_bkpts+1;
    unsigned int how_many_changes=0;

    for(unsigned int interval=0;interval<nb_interval;interval++)
    {
	if(interval==0)
	{
	    lower_bound=0;
	    upper_bound=(unsigned int)(pos_bkpts[interval])-1;
	}
	else if(interval==nb_interval-1)
	{
	    lower_bound=(unsigned int)(pos_bkpts[interval-1]);
	    upper_bound=n_vars_tot-1;
	}
	else
	{
	    lower_bound=(unsigned int)(pos_bkpts[interval-1]);
	    upper_bound=(unsigned int)(pos_bkpts[interval])-1;
	}

	if(interval%2!=0)
	{
	    for(unsigned int pos=lower_bound;pos<=upper_bound;pos++)
	    {
		vect_gam_prop_c1[pos]=chainsVector[pos_c2].getGammaForVariable(pos);
		vect_gam_prop_c2[pos]=chainsVector[pos_c1].getGammaForVariable(pos);
		if(vect_gam_prop_c1[pos]!=vect_gam_prop_c2[pos])
		{
		    how_many_changes++;
		}
	    }
	}
	else
	{
	    for(unsigned int pos=lower_bound;pos<=upper_bound;pos++)
	    {
		vect_gam_prop_c1[pos]=chainsVector[pos_c1].getGammaForVariable(pos);
		vect_gam_prop_c2[pos]=chainsVector[pos_c2].getGammaForVariable(pos);
	    }
	}
    }

    return how_many_changes;
}

void Crossover::define_haplotype_bkpts(vector < unsigned int > &r_idx,
				       unsigned int pos_crsv,
				       gsl_matrix *mat_X)
{
    unsigned int n_vars_tot=mat_X->size2;
    unsigned int n_obs=mat_X->size1;

    //Getting the correlation matrix between X[:,crsv] and all columns of X
    vector < double > vect_r;
    vect_r.resize(n_vars_tot);
    unsigned int n_neg_r=0;

    for(unsigned int var=0;var<n_vars_tot;var++)
    {
	double current_r=gsl_stats_correlation(&mat_X->data[pos_crsv],
					       n_vars_tot,
					       &mat_X->data[var],
					       n_vars_tot,
					       n_obs);

	if(current_r<=0.0)
	{
	    n_neg_r++;
	}
	vect_r[var]=current_r;
    }

    //Defining the sign of the correlation
    unsigned int selected_neg_r=0;
    for(unsigned int var=0;var<n_vars_tot;var++)
    {
	if(selected_neg_r==0)
	{//postiive r
	    if(vect_r[var]>=Prior::Prob_crsv_r)
	    {
		r_idx.push_back(var);
	    }
	}
	else
	{//negative r
	    if(vect_r[var]<= -Prior::Prob_crsv_r)
	    {
		r_idx.push_back(var);
	    }
	}
    }
}

unsigned int Crossover::recombine_haplotype(vector<Chain>& chainsVector,
					    vector < bool > &vect_gam_prop_c1,
					    vector < bool > &vect_gam_prop_c2,
					    unsigned int n_vars_tot,
					    vector < unsigned int > &sampled_chains,
					    vector <unsigned int > &chain_idx,
					    vector <unsigned int > &r_idx)
{
    unsigned int c1=sampled_chains[0];
    unsigned int pos_c1=chain_idx[c1];
    unsigned int c2=sampled_chains[1];
    unsigned int pos_c2=chain_idx[c2];
    unsigned int rank_in_r_idx=0;
    unsigned int how_many_changes=0;
    for(unsigned int pos=0;pos<n_vars_tot;pos++)
    {
	if(rank_in_r_idx<r_idx.size())
	{
	    if(r_idx[rank_in_r_idx]==pos)
	    {
		vect_gam_prop_c1[pos]=chainsVector[pos_c2].getGammaForVariable(pos);
		vect_gam_prop_c2[pos]=chainsVector[pos_c1].getGammaForVariable(pos);
		rank_in_r_idx++;
		if(vect_gam_prop_c1[pos]!=vect_gam_prop_c2[pos])
		{
		    how_many_changes++;
		}
	    }
	    else
	    {
		vect_gam_prop_c1[pos]=chainsVector[pos_c1].getGammaForVariable(pos);
		vect_gam_prop_c2[pos]=chainsVector[pos_c2].getGammaForVariable(pos);
	    }
	}
	else
	{
	    vect_gam_prop_c1[pos]=chainsVector[pos_c1].getGammaForVariable(pos);
	    vect_gam_prop_c2[pos]=chainsVector[pos_c2].getGammaForVariable(pos);
	}
    }
    return(how_many_changes);
}

