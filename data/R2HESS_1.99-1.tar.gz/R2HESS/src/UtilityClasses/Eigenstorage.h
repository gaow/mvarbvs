/* This file is part of ESS-OO.
 *      Copyright (c) Marc Chadeau-Hyam (m.chadeau@imperial.ac.uk)
 *                    Leonardo Bottolo (l.bottolo@imperial.ac.uk)
 *                    David Hastie (d.hastie@imperial.ac.uk)
 *      2014
 * Software designed and restructured by Loizos Markides (lm1011@ic.ac.uk)
 * ESS-OO is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ESS-OO is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ESS-OO.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef EIGENSTORAGE_H_
#define EIGENSTORAGE_H_

#include <vector>
#include <map>
#include <string>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_math.h>
#include <gsl/gsl_blas.h>
#include <gsl/gsl_linalg.h>
#include <gsl/gsl_statistics_double.h>
#include <gsl/gsl_sf_gamma.h>
#include <gsl/gsl_fit.h>
#include <gsl/gsl_cdf.h>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_sort.h>
#include <gsl/gsl_sort_vector.h>
#include <gsl/gsl_permutation.h>
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_eigen.h>

class Eigenstorage {
public:
    Eigenstorage();
    virtual ~Eigenstorage();

    static std::map < std::string , unsigned int> keys_;
    static std::vector < gsl_matrix * > eigenvectors_;
    static std::vector < gsl_vector* > eigenvalues_;
    static std::vector < gsl_matrix * > matTildes_;

    static void store_new_eigendecomposition(gsl_matrix *matXGam,std::string gammasVector);

    static int find_key(std::string gammas_to_search);

    static void get_last_eigendecomposition(gsl_matrix *gslEigenVecs,
					    gsl_vector *gslEigenVals);

    static void get_eigendecomposition_for_key(unsigned int current_key,
					       gsl_matrix *gslEigenVecs,
					       gsl_vector *gslEigenVals);

    static void store_new_matTilde(gsl_matrix *matTilde,
				   std::string gammasVector);

    static gsl_matrix *  get_matTilde(unsigned int current_key);

    static void getEigenDecomposition(gsl_matrix *matXGam,
				      gsl_matrix* gslEigenVecs,
				      gsl_vector* gslEigenVals,
				      unsigned int pXGam);
private:
    static unsigned int keys_index_;

    static gsl_matrix* matrix_copy(const gsl_matrix *in);
    static gsl_vector* vector_copy(const gsl_vector *in);
};

#endif /* EIGENSTORAGE_H_ */
