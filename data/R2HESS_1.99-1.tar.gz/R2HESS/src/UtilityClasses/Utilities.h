#ifndef UTILITIES_H_
#define UTILITIES_H_

void exitWithError(std::string msg);
std::string Show_Time(double remainingTime);

#endif // UTILITIES_H_
