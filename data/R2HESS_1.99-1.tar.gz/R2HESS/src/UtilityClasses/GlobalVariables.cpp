/* This file is part of ESS-OO.
 *      Copyright (c) Marc Chadeau-Hyam (m.chadeau@imperial.ac.uk)
 *                    Leonardo Bottolo (l.bottolo@imperial.ac.uk)
 *                    David Hastie (d.hastie@imperial.ac.uk)
 *      2014
 * Software designed and restructured by Loizos Markides (lm1011@ic.ac.uk)
 * ESS-OO is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ESS-OO is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ESS-OO.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "GlobalVariables.h"
using namespace std;

flags GlobalVariables::GlobalFlags = {// Variable Initialization
    true,false,0,0,0,true,false,false,false,false,
    false,false/*logflag, was false*/,false,false,false,false,
    false,false,false,false,false,true,false};

IOFN GlobalVariables::InputOutputFileNames =  {"",""};
IFS GlobalVariables::InputFileStreams;
SSS GlobalVariables::OutputStringStreams;
OFS GlobalVariables::OutputFileStreams;
Timing GlobalVariables::Time;

#if _CUDA_
CUDAoptions GlobalVariables::CudaOpts = {NULL,500,10000,20,100,10,100};
#endif

GlobalVariables::GlobalVariables() {
    // TODO Auto-generated constructor stub
}

GlobalVariables::~GlobalVariables() {
    // TODO Auto-generated destructor stub
}

