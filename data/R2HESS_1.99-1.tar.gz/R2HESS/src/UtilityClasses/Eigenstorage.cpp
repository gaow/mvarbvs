/* This file is part of ESS-OO.
 *      Copyright (c) Marc Chadeau-Hyam (m.chadeau@imperial.ac.uk)
 *                    Leonardo Bottolo (l.bottolo@imperial.ac.uk)
 *                    David Hastie (d.hastie@imperial.ac.uk)
 *      2014
 * Software designed and restructured by Loizos Markides (lm1011@ic.ac.uk)
 * ESS-OO is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ESS-OO is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ESS-OO.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "Eigenstorage.h"

using std::map;
using std::vector;
using std::string;

map < string , unsigned int> Eigenstorage::keys_ = map < string , unsigned int>();
vector < gsl_matrix * > Eigenstorage::eigenvectors_ = vector < gsl_matrix * >();
vector < gsl_vector* > Eigenstorage::eigenvalues_ = vector < gsl_vector* >();
vector < gsl_matrix * > Eigenstorage::matTildes_ = vector < gsl_matrix * >();
unsigned int Eigenstorage::keys_index_ = 0;

Eigenstorage::Eigenstorage() {
    // TODO Auto-generated constructor stub
}

Eigenstorage::~Eigenstorage() {
    for (unsigned int i = 0; i < keys_index_; i++)
    {
	gsl_matrix_free(eigenvectors_[i]);
	gsl_vector_free(eigenvalues_[i]);
	gsl_matrix_free(matTildes_[i]);
    }
    eigenvectors_.clear();
    eigenvalues_.clear();
    matTildes_.clear();
    keys_.clear();
}

int Eigenstorage::find_key(string gammas_to_search)
{
    // returns the position of the eigenvectors and eigenvalues in the storage
    // the key is the gamma vector string
    // or returns -1 if not found
    map<std::string,unsigned int>::const_iterator got = keys_.find(gammas_to_search);

    if ( got == keys_.end() )
    {
	return -1;
    }
    else
    {
	return got->second;
    }
}

void Eigenstorage::store_new_matTilde(gsl_matrix *matTilde,
				      string gammasVector)
{
    matTildes_.push_back(new gsl_matrix());
    matTildes_[keys_index_] = gsl_matrix_alloc(matTilde->size1,matTilde->size2);
    gsl_matrix_memcpy(matTildes_[keys_index_],matTilde);
    // adding new indexes for the eigendecomposition
    std::pair<string,unsigned int> new_pair (gammasVector,keys_index_);
    keys_.insert(new_pair);

    keys_index_++;
}

gsl_matrix * Eigenstorage::get_matTilde(unsigned int current_key)
{
    return matTildes_[current_key];
}

void Eigenstorage::store_new_eigendecomposition(gsl_matrix *matXGam,
						string gammasVector)
{
    unsigned int pXGam = matXGam->size2;

    gsl_matrix *gslEigenVecs=gsl_matrix_calloc(pXGam,pXGam);
    gsl_vector *gslEigenVals=gsl_vector_calloc(pXGam);

    getEigenDecomposition(matXGam,gslEigenVecs,gslEigenVals,pXGam);

    // adding new eigendecomposition matrices
    eigenvectors_.push_back(gslEigenVecs);
    eigenvalues_.push_back(gslEigenVals);

    // adding new indexes for the eigendecomposition
    std::pair<string,unsigned int> new_pair (gammasVector,keys_index_);
    keys_.insert(new_pair);

    keys_index_++;
}

void Eigenstorage::get_last_eigendecomposition(gsl_matrix *gslEigenVecs,
					       gsl_vector *gslEigenVals)
{
    get_eigendecomposition_for_key(keys_index_-1,gslEigenVecs,gslEigenVals);
}

void Eigenstorage::get_eigendecomposition_for_key(unsigned int current_key,
						  gsl_matrix *gslEigenVecs,
						  gsl_vector *gslEigenVals)
{
    gslEigenVecs = matrix_copy(eigenvectors_[current_key]);
    gslEigenVals = vector_copy(eigenvalues_[current_key]);
}

void Eigenstorage::getEigenDecomposition(gsl_matrix *matXGam,
					 gsl_matrix* gslEigenVecs,
					 gsl_vector* gslEigenVals,
					 unsigned int pXGam)
{
    gsl_matrix *gslMatrixXGamTXGam=gsl_matrix_calloc(pXGam,pXGam);
    gsl_blas_dgemm(CblasTrans,CblasNoTrans,1.0,matXGam,matXGam,0.0,gslMatrixXGamTXGam);

    gsl_eigen_symmv_workspace *w=gsl_eigen_symmv_alloc(pXGam);
    gsl_eigen_symmv(gslMatrixXGamTXGam,gslEigenVals,gslEigenVecs,w);
    gsl_eigen_symmv_sort(gslEigenVals,gslEigenVecs,GSL_EIGEN_SORT_VAL_ASC);
    gsl_eigen_symmv_free(w);
  
    gsl_matrix_free(gslMatrixXGamTXGam);
}

gsl_matrix * Eigenstorage::matrix_copy(const gsl_matrix *in)
{
    if (!in) return NULL;
    gsl_matrix *out = gsl_matrix_alloc(in->size1, in->size2);
    gsl_matrix_memcpy(out, in);
    return out;
}

gsl_vector * Eigenstorage::vector_copy(const gsl_vector *in){
    if (!in) return NULL;
    gsl_vector *out = gsl_vector_alloc(in->size);
    gsl_vector_memcpy(out, in);
    return out;
}
