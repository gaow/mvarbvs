/* This file is part of ESS-OO.
 *      Copyright (c) Marc Chadeau-Hyam (m.chadeau@imperial.ac.uk)
 *                    Leonardo Bottolo (l.bottolo@imperial.ac.uk)
 *                    David Hastie (d.hastie@imperial.ac.uk)
 *      2014
 * Software designed and restructured by Loizos Markides (lm1011@ic.ac.uk)
 * ESS-OO is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ESS-OO is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ESS-OO.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef MATRIXMANIPULATION_H_
#define MATRIXMANIPULATION_H_

#include <iostream>
#include <iomanip>
#include <sstream>
#include <fstream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <stdlib.h>
#include <stddef.h>
#include <stdarg.h>
#include <string.h>
#include <stdio.h>
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_rng.h>
#include <gsl/gsl_math.h>
#include <gsl/gsl_permutation.h>
#include <gsl/gsl_blas.h>
#include <vector>
#include <algorithm>
#include "Matrix.h"

//#include "../Classes/Double_Matrices_cont.h"

class MatrixManipulation {
public:

    MatrixManipulation();
    virtual ~MatrixManipulation();

    static void Read_File_Double(std::ifstream & File, std::vector < std::vector <double > > & Mat);
    static void Read_File_Double(std::fstream & File, std::vector < std::vector <double > > & Mat);

    static void Read_File_Double(std::ifstream & File, std::vector <double > & Vec);
    static void Read_File_Int(std::ifstream & File, std::vector < std::vector <unsigned int > > & Mat);
    static void Read_File_Int(std::ifstream & File, std::vector <unsigned int > & Vec);

    static double gsl_ran_gaussian_copy (const gsl_rng * r, const double sigma);

    static void standardize_matrix_gsl(gsl_matrix* M);

    static void getTildeResidualsMatrix(gsl_matrix * TildeResidualsMatrix,
					gsl_matrix *QSubTYTilde);

    static void getQSubTYTilde(gsl_matrix * QSubTYTilde,
			       gsl_matrix *matXGamTilde,
			       gsl_matrix *matYTilde,
			       gsl_matrix *matY);

    static unsigned int sum_vector_int(std::vector <unsigned int> &Myvector);

    static void get_list_var_in_and_out(std::vector <unsigned int> &list_columns_var_in,
					std::vector <unsigned int> &list_columns_var_out,
					std::vector <bool> &is_var_in);

    static gsl_matrix* get_sub_matrix_col(gsl_matrix *mat_X,
					  size_t first_col,
					  size_t last_col);

    static gsl_matrix* get_sub_matrix_row(gsl_matrix *mat_X,
					  size_t first_row,
					  size_t last_row);

    static void display_gsl_matrix(gsl_matrix *M);

    static void display_gsl_vector(gsl_vector *V);

    static void display_gsl_perm(gsl_permutation *P);

    static void fill_sub_matrix_row(gsl_matrix *X_red,
				    gsl_matrix *mat_X,
				    size_t first_row,
				    size_t last_row);

    static void fill_sub_matrix_col(gsl_matrix *X_red,
				    gsl_matrix *mat_X,
				    size_t first_col,
				    size_t last_col);

    static void display_matrix_var_dim(std::vector < std::vector <unsigned int> > &M);

    static void center_matrix_gsl(gsl_matrix *M);

    static void display_vector_int(std::vector < unsigned int> &vector);

    static unsigned int sum_line_std_mat(std::vector < std::vector <unsigned int> > &M,
					 unsigned int line);

    static void get_list_var_in(std::vector <unsigned int> &list_columns_var_in,
				std::vector <bool> &is_var_in);

    static gsl_matrix* get_X_reduced(std::vector <unsigned int> &list_columns_var,
				     gsl_matrix *mat_X);

    static void Display_Vector(std::vector < unsigned int > * M);
    static void Display_Vector(std::vector < unsigned int > M);
    static void Display_Vector(std::vector < double > * M);
    static void Display_Vector(std::vector < double > M);
    static void Display_Matrices(std::vector < std::vector < double > > * M);
    static void Display_Matrices(std::vector < std::vector < double > > M);
    static void Display_Matrices(std::vector < std::vector < unsigned int > > M);
    static void Write_Matrix(std::ostream & File,
			     std::vector <std::vector < unsigned int > > & Matrix,
			     std::string Field_Separator);
    static void Mean_Matrix(std::vector <std::vector < double > > & Matrix,
			    std::vector <double> &Mean,
			    unsigned int burnin,
			    unsigned int nsweep);
    static void Write_Matrix(std::ostream & File,
			     std::vector <std::vector < double > > & Matrix,
			     std::string Field_Separator);
    static void Write_Vector(std::ostream & File,
			     std::vector < double > & Vector);
    static void Write_Vector(std::ostream & File,
			     std::vector < unsigned int > & Vector);
    static void Write_Vector_Line(std::ostream & File,
				  std::vector < double > & Vector,
				  std::string FieldSeparator);
    static void Row2Col(gsl_matrix * Row, float *Col, int M, int N);
};

#endif /* MATRIXMANIPULATION_H_ */
