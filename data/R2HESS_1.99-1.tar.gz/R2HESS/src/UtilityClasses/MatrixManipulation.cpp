/* This file is part of ESS-OO.
 *      Copyright (c) Marc Chadeau-Hyam (m.chadeau@imperial.ac.uk)
 *                    Leonardo Bottolo (l.bottolo@imperial.ac.uk)
 *                    David Hastie (d.hastie@imperial.ac.uk)
 *      2014
 * Software designed and restructured by Loizos Markides (lm1011@ic.ac.uk)
 * ESS-OO is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ESS-OO is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ESS-OO.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "MatrixManipulation.h"
#include <gsl/gsl_linalg.h>
#include <gsl/gsl_blas.h>
#define DEBUG 0

using namespace std;

MatrixManipulation::MatrixManipulation() {
    // TODO Auto-generated constructor stub
}

MatrixManipulation::~MatrixManipulation() {
    // TODO Auto-generated destructor stub
}


// 2D version
void MatrixManipulation::Read_File_Double(ifstream & File, vector < vector <double > > & Mat)
{
    string Line;
    vector <double> Temp_Line;

    while ( getline(File, Line) ) //Reads the file line by line, and stores each line in Line
    {
        Temp_Line.resize(0);

        //Now we read each line Ligne into separate entries
        string Word;
        istringstream Read_Line(Line);
        while (Read_Line >> Word)
        {
            Temp_Line.push_back(atof(Word.c_str()));
        }
        Mat.push_back(Temp_Line);

    }
}

void MatrixManipulation::Read_File_Double(fstream & File, vector < vector <double > > & Mat)
{
    string Line;
    vector <double> Temp_Line;

    // Seek to the beginning of the file (needed if reading after writing to the same file)
    File.seekg(ios::beg);

    while ( getline(File, Line) ) //Reads the file line by line, and stores each line in Line
    {
        Temp_Line.resize(0);

        //Now we read each line Ligne into separate entries
        string Word;
        istringstream Read_Line(Line);
        while (Read_Line >> Word)
        {
            Temp_Line.push_back(atof(Word.c_str()));
        }
        Mat.push_back(Temp_Line);
    }

    // getline sets the failbit when reaching end of file. Reset so file can be read again.
    File.clear();
}

// 1D version
void MatrixManipulation::Read_File_Double(ifstream & File, vector <double > & Vec)
{
    string Line;

    while ( getline(File, Line) ) //Reads the file line by line, and stores each line in Line
    {
        //Now we read each line Ligne into separate entries
        string Word;
        istringstream Read_Line(Line);
        while (Read_Line >> Word)
        {
            Vec.push_back(atof(Word.c_str()));
        }
    }
}

void MatrixManipulation::Read_File_Int(ifstream & File, vector < vector <unsigned int > > & Mat)
{
    string Line;
    vector <unsigned int > Temp_Line;

    while ( getline(File, Line) ) //Reads the file line by line, and stores each line in Line
    {
        Temp_Line.resize(0);

        //Now we read each line Ligne into separate entries
        string Word;
        istringstream Read_Line(Line);
        while (Read_Line >> Word)
        {
            Temp_Line.push_back(atoi(Word.c_str()));
        }
        Mat.push_back(Temp_Line);
    }
}

// 1D version
void MatrixManipulation::Read_File_Int(ifstream & File, vector <unsigned int > & Vec)
{
    string Line;

    while ( getline(File, Line) ) //Reads the file line by line, and stores each line in Line
    {
        //Now we read each line Ligne into separate entries
        string Word;
        istringstream Read_Line(Line);
        while (Read_Line >> Word)
        {
            Vec.push_back(atoi(Word.c_str()));
        }
    }
}

void MatrixManipulation::getTildeResidualsMatrix(gsl_matrix * TildeResidualsMatrix,
						 gsl_matrix *QSubTYTilde)
{
    gsl_blas_dgemm(CblasTrans,CblasNoTrans,1.0,QSubTYTilde,QSubTYTilde,0.0,TildeResidualsMatrix);
}

void MatrixManipulation::getQSubTYTilde(gsl_matrix * QSubTYTilde,
					gsl_matrix *matXGamTilde,
					gsl_matrix *matYTilde,
					gsl_matrix *matY)
{
    //clog << "Enter getTildeResidualsMatrix" << endl;

    unsigned int pY=matY->size2;
    unsigned int nQ=matXGamTilde->size1;
    unsigned int pXGam=matXGamTilde->size2;

    //QR decomposition
    gsl_vector *tau=gsl_vector_alloc(pXGam);

    gsl_linalg_QR_decomp(matXGamTilde,tau);
    gsl_matrix *matQTYTilde=gsl_matrix_calloc(nQ,pY);
    gsl_matrix_memcpy(matQTYTilde,matYTilde);
    gsl_linalg_QR_QTmat(matXGamTilde,tau,matQTYTilde);

    //Defining Q_sub
    gsl_matrix_view viewMatQTYTilde = gsl_matrix_submatrix(matQTYTilde,pXGam,0
							   ,nQ-pXGam,pY);

    gsl_matrix_memcpy(QSubTYTilde,&(viewMatQTYTilde.matrix));

    gsl_matrix_free(matQTYTilde);
    gsl_vector_free(tau);
}

double MatrixManipulation::gsl_ran_gaussian_copy (const gsl_rng * r, const double sigma)
{
    double x, y, r2;

    do
    {
	/* choose x,y in uniform square (-1,-1) to (+1,+1) */
	x = -1 + 2 * gsl_rng_uniform_pos (r);
	y = -1 + 2 * gsl_rng_uniform_pos (r);

	/* see if it is in the unit circle */
	r2 = x * x + y * y;
    }
    while (r2 > 1.0 || r2 == 0);

    /* Box-Muller transform */
    return sigma * y * sqrt (-2.0 * log (r2) / r2);
}

void MatrixManipulation::standardize_matrix_gsl(gsl_matrix* M)
{
    int nb_rows=M->size1;
    int nb_columns=M->size2;
    for(int col=0;col<nb_columns;col++){
	double mean=0.0;
	for(int row=0;row<nb_rows;row++){
	    mean+=gsl_matrix_get(M,row,col);
	}
	mean/=(double)nb_rows;
	double temp_var=0.0;
	for(int row=0;row<nb_rows;row++){
	    temp_var+=pow((gsl_matrix_get(M,row,col)-mean),2.0);
	}
	if(nb_rows>1){
	    temp_var/=nb_rows-1;
	}
	else{
	    clog << "USAGE::standardize_matrix :: matrix size <2 to compute variance!!!!! run_stopped " << endl;
	    exit(1);
	}
	double Mystd=sqrt(temp_var);
	if(Mystd>0){
	    for(int row=0;row<nb_rows;row++){
		gsl_matrix_set(M,row,col,gsl_matrix_get(M,row,col)/Mystd);
	    }
	}
	else{
	    clog << "Warning: std deviation of variable " << col << " is zero.\n";
	}
    }
}


void MatrixManipulation::center_matrix_gsl(gsl_matrix *M)
{
    for(unsigned int col=0;col<M->size2;col++){
	double mean=0.0;
	for(unsigned int row=0;row<M->size1;row++){
	    mean+=gsl_matrix_get(M,row,col);
	}
	mean/=(double)M->size1;
	for(unsigned int row=0;row<M->size1;row++){
	    gsl_matrix_set(M,row,col,gsl_matrix_get(M,row,col)-mean);
	}
    }
}

/*
gsl_matrix* MatrixManipulation::Double_matrices_cont_2_gsl_matrix(Double_Matrices_cont source)
{
    gsl_matrix* M=gsl_matrix_calloc(source.nb_rows,source.nb_columns);
    M->data=&source.matrix[0];
    return M;
}

gsl_matrix* MatrixManipulation::Double_matrices_2_gsl_matrix(Matrix<double> source)
{
    gsl_matrix* M=gsl_matrix_calloc(source.nb_rows,source.nb_columns);
    for(int j=0;j<source.nb_rows;j++){
	for(int k=0;k<source.nb_columns;k++){
	    M->data[j*source.nb_columns+k]=source.matrix[j][k];
	}
    }
    return M;
}
*/

unsigned int MatrixManipulation::sum_vector_int(vector <unsigned int> &Myvector)
{
    unsigned int Mysum=0.0;
    for(unsigned int i=0;i<Myvector.size();i++){
	Mysum+=Myvector[i];
    }
    return Mysum;
}

void MatrixManipulation::get_list_var_in_and_out(vector <unsigned int> &list_columns_var_in,
						 vector <unsigned int> &list_columns_var_out,
						 vector <bool> &is_var_in)
{
    //the in matrix will contain all the confounders at the end
    // the out matrix will contain the rest

    for(unsigned int i=0;i<is_var_in.size();i++){
	if(is_var_in[i]){
	    list_columns_var_in.push_back(i);
	}
	else{
	    list_columns_var_out.push_back(i);
	}
    }
}

void MatrixManipulation::get_list_var_in(vector <unsigned int> &list_columns_var_in,
					 vector <bool> &is_var_in)
{

    /*
    unsigned int numVars = 0;
    list_columns_var_in.resize(is_var_in.size());
    vector<unsigned int>::iterator it,it2,it3;
    it2=list_columns_var_in.begin();
    it3=is_var_in.end();
    unsigned int i=0;
    for(it=is_var_in.begin();it<it3;it++){
	if(*it){
	    *it2=i;
	    it2++;
	    numVars++;
	}
	i++;
    }
    list_columns_var_in.resize(numVars);
    */
    
    list_columns_var_in.clear();
    for (int i = 0; i < is_var_in.size(); i++) {
	if (is_var_in[i]) {
	    list_columns_var_in.push_back(i);
	}
    }
}

gsl_matrix* MatrixManipulation::get_sub_matrix_col(gsl_matrix *mat_X,
						   size_t first_col,
						   size_t last_col)
{
    unsigned int n_vars=last_col-first_col;
    unsigned int nX=mat_X->size1;
    gsl_matrix *X_red=gsl_matrix_alloc(nX,n_vars);

    for(unsigned int col=0;col<n_vars;col++){
	//Copying the the col^th variable (at position list_columns_var_in[col] in mat_X)
	gsl_vector_view current_col = gsl_matrix_column (mat_X,first_col+col);
	gsl_matrix_set_col (X_red,col,&current_col.vector);
    }
    return X_red;
}

void MatrixManipulation::fill_sub_matrix_col(gsl_matrix *X_red,
					     gsl_matrix *mat_X,
					     size_t first_col,
					     size_t last_col)
{
    unsigned int n_vars=last_col-first_col;

    for(unsigned int col=0;col<n_vars;col++){
	gsl_vector_view current_col = gsl_matrix_column (mat_X,first_col+col);
	gsl_matrix_set_col (X_red,col,&current_col.vector);
    }
}

gsl_matrix* MatrixManipulation::get_sub_matrix_row(gsl_matrix *mat_X,
						   size_t first_row,
						   size_t last_row)
{
    unsigned int n_row=last_row-first_row;
    unsigned int nY=mat_X->size2;
    gsl_matrix *X_red=gsl_matrix_alloc(n_row,nY);

    for(unsigned int row=0;row<n_row;row++){
	gsl_vector_view current_row = gsl_matrix_row(mat_X,first_row+row);
	gsl_matrix_set_row(X_red,row,&current_row.vector);
    }
    return X_red;
}

void MatrixManipulation::fill_sub_matrix_row(gsl_matrix *X_red,
					     gsl_matrix *mat_X,
					     size_t first_row,
					     size_t last_row)
{
    unsigned int n_row=last_row-first_row;

    for(unsigned int row=0;row<n_row;row++){
	gsl_vector_view current_row = gsl_matrix_row(mat_X,first_row+row);
	gsl_matrix_set_row(X_red,row,&current_row.vector);
    }
}

void MatrixManipulation::display_gsl_matrix(gsl_matrix *M)
{
    clog << "nb_rows " << M->size1 << " -- nb_columns " << M->size2 << endl;
    for(unsigned int i=0;i<M->size1;i++){
	for(unsigned int j=0;j<M->size2;j++){
	    clog << M->data[i*(M->size2)+j] << " ";
	}
	clog << endl;
    }
}

void MatrixManipulation::display_gsl_vector(gsl_vector *V)
{
    clog << "vector size " << V->size << endl;
    for(unsigned int i=0;i<V->size;i++){
	clog << V->data[i] << " ";
    }
    clog << endl;
}

void MatrixManipulation::display_gsl_perm(gsl_permutation *P)
{
    clog << "perm size " << P->size << endl;
    for(unsigned int i=0;i<P->size;i++){
	clog << P->data[i] << " ";
    }
    clog << endl;
}

void MatrixManipulation::display_vector_int(vector < unsigned int> &vector)
{
    clog << "Vector size " << vector.size() << endl;
    for(unsigned int i=0;i<vector.size();i++){
	clog << vector[i] << " ";
    }
    clog << endl;
}

void MatrixManipulation::display_matrix_var_dim(vector < vector <unsigned int> > &M)
{
    for(unsigned int row=0;row<M.size();row++){
	clog << "Row #" << row+1 << " -- nb columns " << M[row].size() << endl;
	for(unsigned int col=0;col<M[row].size();col++){
	    clog << M[row][col] << " ";
	}
	if(M[row].size()>0){
	    clog << endl;
	}
    }
}

unsigned int MatrixManipulation::sum_line_std_mat(vector < vector <unsigned int> > &M,
						  unsigned int line)
{
    unsigned int tmp_sum=0;
    vector<unsigned int>::iterator it,itEnd;
    itEnd=M[line].end();
    for(it=M[line].begin();it<itEnd;++it){
	tmp_sum+=(*it);
    }
    return tmp_sum;
}

/*
void MatrixManipulation::display_result_per_sweep(vector < vector <unsigned int> > vect_gam,
						  vector < unsigned int > chain_idx,
						  Matrix<double>  mat_log_marg,
						  Matrix<double>  mat_log_cond_post,
						  unsigned int sweep,
						  TemperatureTuning *t_tun)
{
    for(unsigned int chain=0;chain<vect_gam.size();chain++){
	unsigned int pos_chain=chain_idx[chain];
	unsigned int n_vars_in=sum_line_std_mat(vect_gam,
						pos_chain);
	clog << "Chain #" << chain+1
	     << " -- position: " << pos_chain+1
	     << " -- log_marg " << mat_log_marg.matrix[pos_chain][sweep]
	     << " -- log_cond_post " << mat_log_cond_post.matrix[pos_chain][sweep]
	     << " -- n_vars_in " << n_vars_in
	     << " -- t_tun.t " << (*t_tun).t[chain]
	     << endl;
	for(unsigned int var=0;var<vect_gam[chain].size();var++){
	    if(vect_gam[pos_chain][var]==1){
		clog << var << " ";
	    }
	}
	clog << endl;
    }
}
*/

gsl_matrix* MatrixManipulation::get_X_reduced(vector <unsigned int> &list_columns_var,
					      gsl_matrix *mat_X)
{
    unsigned int n_vars=list_columns_var.size();
    unsigned int nX=mat_X->size1;
    gsl_matrix* X_red=gsl_matrix_alloc(nX,(n_vars));
    //Setting the other columns to the list of vars in
    for(unsigned int col=0;col<n_vars;col++)
    {
	//Copying the the col^th variable (at position list_columns_var_in[col] in mat_X)
	gsl_vector_view current_col = gsl_matrix_column (mat_X,list_columns_var[col]);

	//Setting the col^th column of X_red
	gsl_matrix_set_col (X_red,col,&current_col.vector);
    }
    return X_red;
}

void MatrixManipulation::Write_Vector(ostream & File,
				      vector < unsigned int > & Vector)
{
    unsigned int Nb_Lines=Vector.size();
    for (unsigned int line=0;line<Nb_Lines;line++)
    {
        File << Vector[line]<< endl;
    }

}

void MatrixManipulation::Write_Vector(ostream & File,
				      vector < double > & Vector)
{
    unsigned int Nb_Lines=Vector.size();
    for (unsigned int line=0;line<Nb_Lines;line++)
    {
        File << Vector[line]<< endl;
    }

}
void MatrixManipulation::Write_Vector_Line(ostream & File,
					   vector < double > & Vector,
					   string Field_Separator=" ")
{
    unsigned int Nb_Lines=Vector.size();
    for (unsigned int line=0;line<Nb_Lines;line++)
    {
        File << Vector[line]<< Field_Separator;
    }
    File << endl;
}


void MatrixManipulation::Write_Matrix(ostream & File,
				      vector <vector < double > > & Matrix,
				      string Field_Separator)
{
    unsigned int Nb_Lines=Matrix.size();
    for (unsigned int line=0;line<Nb_Lines;line++)
    {
        unsigned int Nb_Col=Matrix[line].size();
        for (unsigned int col=0;col<Nb_Col;col++)
        {
            File << Matrix[line][col] << Field_Separator;
        }
        File << endl;
    }
}

void MatrixManipulation::Mean_Matrix(vector <vector < double > > & Matrix,
				     vector <double> &Mean,
				     unsigned int burnin,
				     unsigned int nsweep)
{
    for (unsigned int col=0;col<Mean.size();col++)
    {   Mean[col]=0;}

    for (unsigned int sweep=burnin;sweep<nsweep;sweep++)
    {
        unsigned int Nb_Col=Matrix[sweep].size();
        for (unsigned int col=0;col<Nb_Col;col++)
        {
            Mean[col]=Mean[col]+Matrix[sweep][col]/(double)(nsweep-burnin);
        }
    }
}

void MatrixManipulation::Write_Matrix(ostream & File,
				      vector <vector < unsigned int > > & Matrix,
				      string Field_Separator)
{
    unsigned int Nb_Lines=Matrix.size();
    for (unsigned int line=0;line<Nb_Lines;line++)
    {
        unsigned int Nb_Col=Matrix[line].size();
        for (unsigned int col=0;col<Nb_Col;col++)
        {
            File << Matrix[line][col] << Field_Separator;
        }
        File << endl;
    }
}

void MatrixManipulation::Display_Matrices(vector < vector < unsigned int > > M)
{
    unsigned int Nb_l=M.size();
    for (unsigned int l=0;l<Nb_l;l++)
    {
        clog << "Line " << l << endl;
        unsigned int Nb_c=M[l].size();

        for (unsigned int c=0;c<Nb_c;c++)
        {
            clog << "\t" << M[l][c];
            //clog << "\t["<< l << "," << c << "]";
        }
        clog << endl;
    }
    clog << endl;
}

void MatrixManipulation::Display_Matrices(vector < vector < double > > M)
{
    vector < vector < double > > *p_M=& M;
    Display_Matrices(p_M);
}

void MatrixManipulation::Display_Matrices(vector < vector < double > > * M)
{
    unsigned int Nb_l=M->size();
    for (unsigned int l=0;l<Nb_l;l++)
    {
        clog << "Line " << l << endl;
        unsigned int Nb_c=(*M)[l].size();

        for (unsigned int c=0;c<Nb_c;c++)
        {
            clog << "\t" << (*M)[l][c];
            //clog << "\t["<< l << "," << c << "]";
        }
        clog << endl;
    }
    clog << endl;
}

void MatrixManipulation::Display_Vector(vector < double > M)
{
    vector < double > *p_M=& M;
    Display_Vector(p_M);
}

void MatrixManipulation::Display_Vector(vector < double > * M)
{
    unsigned int Nb_l=M->size();
    for (unsigned int l=0;l<Nb_l;l++)
    {
        clog << "\t" << (*M)[l];
        clog << endl;
    }
    //clog << endl;
}

void MatrixManipulation::Display_Vector(vector < unsigned int > M)
{
    vector < unsigned int > *p_M=& M;
    Display_Vector(p_M);
}

void MatrixManipulation::Display_Vector(vector < unsigned int > * M)
{
    unsigned int Nb_l=M->size();
    for (unsigned int l=0;l<Nb_l;l++)
    {
        clog << "\t" << (*M)[l];
        clog << endl;
    }
    //clog << endl;
}

void MatrixManipulation::Row2Col(gsl_matrix * Row, float *Col, int M, int N){

    float *c;
    double *r;
    c=Col;
    r=gsl_matrix_ptr (Row, 0, 0);
    for(int i =0;i < M;i++)
    {
	for(int j = 0;j<N;j++)
	    c[j*M+i]= (float) r[i*N+j];
    }
}
