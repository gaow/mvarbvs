#include <iostream>
#include <sstream>
#include <iomanip>
#include <cmath>

#include "Utilities.h"

void exitWithError(std::string msg) {
    std::cerr << "Error: " << msg << std::endl;
    exit(1);
}

std::string Show_Time(double remainingTime)
{

    std::ostringstream ss;
    
    double Time_Hr=0;
    double Time_Mn=0;
    double Time_s=0;

    double Residue=remainingTime;
    Time_Hr=floor(Residue/3600.0);
    Residue=Residue-3600.0*Time_Hr;

    Time_Mn=floor(Residue/60.0);
    Residue=Residue-60.0*Time_Mn;

    Time_s=Residue;

    if (Time_Hr==0)
    {
	if (Time_Mn==0)
	{
	    if (Time_s==0)
	    {
		ss << " 0 s";
	    }
	    else
	    {
		ss << std::setprecision(2) << Time_s << " s";
	    }
	}
	else
	{
	    ss << Time_Mn << " mn " << Time_s << " s";
	}
    }
    else
    {
	ss << Time_Hr << " hr " << Time_Mn << " mn " << Time_s << " s";
    }

    return ss.str();
}
