#ifndef SETTINGS_H_
#define SETTINGS_H_

#include <iostream>
#include <fstream>
#include <vector>
#include "Utilities.h"

using std::clog;
using std::cerr;
using std::endl;

struct GlobalSettings {

    enum modelT { modelESS, modelHESS };
    modelT model = modelHESS;  // 0 = ESS, 1 = HESS
    bool verbose = false;

    // Input files
    std::ifstream Xfile;
    std::ifstream Yfile;

    // Y Terminology:
    // n observations, indexed 'i'
    // p snps, indexed 'j'
    // q responses, indexed 'k'
    // - Each response may contain r_k conditions, for 
    // r a q-vector, k = 0..q-1
    // - The conditions are equivalent to tissues in multi-tissue HESS
    // If the r vector has the same value across all elements, we treat
    // r = number of conditions as a scalar shorthand, indexed 'm'

    // Problem size: Set by code when reading input files
    unsigned long nX = 0;  // Number of observations
    unsigned long nY = 0;  // Number of y observations
    unsigned long pX = 0;  // Number of variables
    unsigned long qY = 0;  // Number of y variables / responses
    unsigned int rFirst = 0; // Number of conditions/tissues (first y only)

    unsigned int nConfounders = 0;

    int numSweeps = 0;
    int burnIn = 0;
    long seed = -1;
    bool resumeRun = false;
    int extendRun = 0;
    int nChains = 3;
    
    enum initRegressionT { simple, stepwise };
    initRegressionT initRegression = simple;
    bool eigenstorage = false;	// Enable storing cache of calculated eigenvecs/vals
    bool noTemperature = false;	// Disable temperature of chains
    bool standardiseX = true;	// Standardise X data matrix

    enum PriorTypeT { gPrior, Independent, Power };
    PriorTypeT priorType = gPrior;
    enum LikelihoodTypeT { Linear, GLM, Survival };
    LikelihoodTypeT likelihoodType = Linear;
    enum PenalisationTypeT { wmegaFixed, wmegaBetaBinomial, wmegaBernoulli };
    PenalisationTypeT penalisationType = wmegaFixed;

    bool calcMPPI = 0;		// Enable calculation of MPPI (very slow)
    bool moveLog = false;	// Enable built-in logging of MCMC moves.
    
    double Egam = 2;
    double Sgam = 1;
    double maxPGamma = 0;
    double maxPGammaFactor = 7;

    double pMutation = 0.5;
    double pSel = 0.5;
    double pCsrv = 0.5; // Was 0.375 in code, 0.5 in par.xml
    double pDR = 0.5;
    double regrNpEnter = 0.1; // Was: Regression::n_Pvalue_enter/remove
    double regrNpRemove = 0.1; // Was 0.01 in code, 0.1 in par.xml 

    // g prior
    // TODO: Confirm these values should not be -1
    double priorGalpha = -1;  // -1 implies values are calculated at runtime 
    double priorGbeta = -1;

    // g Adaptive M-H move
    unsigned int gNBatch = 100;
    double gAdMH_optimal = 0.44;
    double gAdMH_ls = 0;
    double gMmin = 0;
    double gMmax = 0;

    // Crossover move
    unsigned crossoverKmax = 2;
    // Gibbs move
    unsigned gibbsNbatch = 500;

    // Temperature
    double bt = 2;
    double at_under5k = 2;	// a_t_den for pX <= 5k
    double at_5k10k = 4;	// a_t_den for 5k < pX <= 10k
    double at_over10k = 2;	// a_t_den for 10k < pX
    double tempNbatch = 50;
    double tempOptimal = 0.234;  // Was 0.5 in code, 0.234 in par.xml
    std::vector<double> mInput = {1, 4};
    
    double activeY = 0.25;

    // Adaptive transcript selection
    bool adaptiveSelection = false; 
    enum AdaptiveWeightsFnT { avgModelSize, avgR2 };
    AdaptiveWeightsFnT adaptiveWeightsFn = avgR2;
    int adaptBatchSize = 50;  // Reselect transcripts every n sweeps
    int adaptC = 100;

    int gammaCountInterval = 100;   // Print gamma counts every n sweeps

    // G
    bool gInitFlag = false;
    double gInit = 1;
    bool gSampleFlag = true;
    bool singleG = true;

    // Gamma Update Move
    bool gammaUpdateMove = false;
    double gammaUpdateMoveProb = 0.75;
    double gammaUpdateSwap = 0.25;
    double gammaUpdateAdd = 0.5;
    double gammaUpdateRandGeometric = 0.3;
    double gammaUpdateGeometricInvProb = 25;

    // Hyperparams for regression coeffs beta
    double beta_d = 3;
    double beta_k = 0;

    // TODO: Confirm these vals should not be negative
    double omegak_a = -1;      // If negative, set at runtime
    double omegak_b = -1;

    double rhoj_c = 1.2;
    double rhoj_d = 1.2;

    // Post-processing options
    bool doPostProc = false;
    bool postProcOnly = false;
    bool slowPostProc = false;
    bool memLimited = false;

    int topNModels = 100;

    // Input
    bool initGamma = false;  // Provide initial values
    bool initOmega = false;
    bool initRho = false;
    bool fixOmega = false;   // Disable sampling of omega/rho
    bool fixRho = false;
    std::string initGammaName;
    std::string initOmegaName;
    std::string initRhoName;
    std::ifstream initGammaFile;  

    // Output files
    std::string outputDir = ".";
    
    struct outFiles {
	std::ofstream activeY;
	std::ofstream adaptBatchWeights;
	std::ofstream avMatrixOmega;
	std::ofstream avOmegaK;
	std::ofstream avRhoJ;
	std::ofstream bestModels;
	std::ofstream bestModelsProbs;
	std::ofstream cbAccept;
	std::ofstream fsmhAccept;
	std::ofstream gammaCounts;
	std::ofstream gammaActiveCounts;
	std::ofstream gammaProp;
	std::ofstream gammaPropAdd;
	std::ofstream historyG;
	std::fstream historyOmega;
	std::fstream historyRho;
	std::ofstream initGamma;
	std::ofstream lsOmega;
	std::ofstream lsRho;
	std::ofstream modelsFull;
	std::ofstream modelPostProb;
	std::ofstream modelSizes;
	std::ofstream mpiComplex;
	std::ofstream mpiSimple;
	std::ofstream mpiUnique;
	std::ofstream mtBeta;
	std::ofstream mtDebug;
	std::ofstream rsquare;
	std::ofstream sgamma;
	std::ofstream tailProbs;
    } out;

    // Output file flags; write output if true
    struct outFileFlags {
	bool activeY = false;
	bool adaptBatchWeights = false;
	bool avMatrixOmega = false;
	bool bestModels = false;
	bool bestModelsProbs = false;
	bool cbAccept = false;
	bool fsmhAccept = true;
	bool gammaCounts = true;
	bool gammaActiveCounts = false;
	bool gammaProp = false;
	bool historyG = false;
	bool historyOmega = false;
	bool historyRho = false;
	bool initGamma = false;
	bool ls = false;
	bool modelsFull = false;
	bool modelPostProb = false;
	bool modelSizes = true;
	bool mpiComplex = false;
	bool mpiSimple = true;
	bool mpiUnique = false;
	bool mtBeta = false;
	bool mtDebug = false;
	bool rsquare = false;
	bool sgamma = false;
	bool tailProbs = true;
    } outFlags;

    std::vector<int> cbAcceptLine;
    std::vector<double> fsmhAcceptLine;
    
    struct outFileNames {
	std::string activeY = "Active_Y.txt";
	std::string adaptBatchWeights = "Batch_Weights.txt";
	std::string avMatrixOmega = "Av_Matrix_Omega_kj.txt";
	std::string avOmegaK = "Av_Omega_k.txt";
	std::string avRhoJ = "Av_Rho_j.txt";
	std::string bestModels = "Best_Models_List.txt";
	std::string bestModelsProbs = "Best_Models_Post_Prob.txt";
	std::string cbAccept = "CB_Move_Acceptance.txt";
	std::string fsmhAccept = "FSMH_Move_Acceptance.txt";
	std::string gammaCounts = "Gamma_Counts_kj.txt";
	std::string gammaActiveCounts = "Gamma_Counts_kj_Active.txt";
	std::string gammaProp = "Gamma_Proposed.txt";
	std::string gammaPropAdd = "Gamma_Proposed_Add.txt";
	std::string historyG = "History_g.txt";
	std::string historyOmega = "History_Omega_k.txt";
	std::string historyRho = "History_Rho_j.txt";
	std::string initGamma = "Initial_Gammas.txt";
	std::string lsOmega = "Omega_ls.txt";
	std::string lsRho = "Rho_ls.txt";
	std::string modelsFull = "Models_List_Full.txt";
	std::string modelPostProb = "List_Models_Post_Prob.txt";
	std::string modelSizes = "Model_Sizes.txt";	
	std::string mpiComplex = "Complex_Marg_Prob_Incl.txt";
	std::string mpiSimple = "Marg_Prob_Incl.txt";
	std::string mpiUnique = "Unique_Marg_Prob_Incl.txt";
	std::string mtBeta = "Multitissue_Beta.txt";
	std::string mtDebug = "mtdebug.txt";
	std::string rsquare = "RSquare.txt";
	std::string sgamma = "SGamma.txt";
	std::string tailProbs = "Tail_Prob_Rho_j.txt";
    } outNames;

    // Constructor. By default, we want clog to point to cout, not cerr
    GlobalSettings() {
	clog.rdbuf(std::cout.rdbuf());
    }

    void readProgramOptions(int argc, char *argv[]);
    void openOutputFiles();
    void writeSettingsToLog();

};

extern GlobalSettings Settings;

#endif // SETTINGS_H_
