/* This file is part of ESS-OO.
 *      Copyright (c) Marc Chadeau-Hyam (m.chadeau@imperial.ac.uk)
 *                    Leonardo Bottolo (l.bottolo@imperial.ac.uk)
 *                    David Hastie (d.hastie@imperial.ac.uk)
 *      2014
 * Software designed and restructured by Loizos Markides (lm1011@ic.ac.uk)
 * ESS-OO is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ESS-OO is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ESS-OO.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "inputRoutines.h"
#include "../UtilityClasses/Settings.hpp"

using namespace std;

string get_standarized_name(string File_name,
			    string Output_type,
			    string Extension)
{
    string Result;
    string separator="_";
    
    Result= File_name+separator+Output_type+Extension;
    
    return Result;
}

void exitEss() {
#if _CUDA_
    stopCula();
#endif
    exit(1);
}

void read_arguments(int argc, char *  argv[],
		    MCMC *mcmc)
{
    double time_limit=-1;
    char filename_in_mat_X[1000];
    char filename_in_mat_Y[1000];
    char path_name_out[1000];

    bool X_Flag=false;
    bool Y_Flag=false;

    double g_init=1.0;
    long MY_SEED=-1;
    unsigned int burn_in=0;
    unsigned int n_top_models_from_read=100;
    int na=1;
    //Reading arguments from command line
    while(na < argc)
    {
	if ( 0 == strcmp(argv[na],"-X") )
	{
	    X_Flag=true;
	    strcpy(filename_in_mat_X,argv[++na]);
	    ifstream ifs(filename_in_mat_X);
	    if (! ifs.is_open()) {
		std::cerr << "Error: Unable to open X file: " << filename_in_mat_X << endl;
		exitEss();
	    }
	    ifs.close();
	    if (na+1==argc) break;
	    ++na;
	}
	else if ( 0 == strcmp(argv[na],"-Y") )
	{
	    Y_Flag=true;
	    strcpy(filename_in_mat_Y,argv[++na]);
	    ifstream ifs(filename_in_mat_Y);
	    if (! ifs.is_open()) {
		std::cerr << "Error: Unable to open Y file: " << filename_in_mat_Y << endl;
		exitEss();
	    }
	    ifs.close();
	    if (na+1==argc) break;
	    ++na;
	}
	else if ( 0 == strcmp(argv[na],"-burn_in") )
	{
	    burn_in=atoi(argv[++na]);
	    if (na+1==argc) break;
	    ++na;
	}
	else if ( 0 == strcmp(argv[na],"-seed") )
	{
	    MY_SEED=(long)((atoi(argv[++na])));
	    if (na+1==argc) break;
	    ++na;
	}
	else if ( 0 == strcmp(argv[na],"-out") )
	{
	    strcpy(path_name_out,argv[++na]);
	    if (na+1==argc) break;
	    ++na;
	}
	else if ( 0 == strcmp(argv[na],"-out_full") )
	{
	    GlobalVariables::GlobalVariables::GlobalFlags.Out_full_Flag=true;
	    strcpy(path_name_out,argv[++na]);
	    if (na+1==argc) break;
	    ++na;
	}
	else if ( 0 == strcmp(argv[na],"-history") )
	{
	    GlobalVariables::GlobalVariables::GlobalFlags.HistoryFlag=true;
	    if (na+1==argc) break;
	    ++na;
	}
	else if ( 0 == strcmp(argv[na],"-time") )
	{
	    GlobalVariables::GlobalFlags.Time_monitorFlag=true;
	    if (na+1==argc) break;
	    ++na;
	}
	else if ( 0 == strcmp(argv[na],"-top") )
	{
	    n_top_models_from_read=atoi(argv[++na]);
	    if (na+1==argc) break;
	    ++na;
	}
	else if ( 0 == strcmp(argv[na],"-log") )
	{
	    GlobalVariables::GlobalFlags.Log_Flag=true;
	    ++na;
	}
	else if ( 0 == strcmp(argv[na],"-init") )
	{
	    GlobalVariables::GlobalFlags.fixInit = true;
	    Regression::filename_init = new char[1000];
	    strcpy(Regression::filename_init,argv[++na]);
	    // Read the initial gamma from file
	    GlobalVariables::InputFileStreams.inputFile.open(Regression::filename_init);
	    if (na+1==argc) break;
	    ++na;
	}
	else if ( 0 == strcmp(argv[na],"-cuda") )
	{
#if _CUDA_
	    GlobalVariables::GlobalFlags.cudaFlag=true;
	    startCula();
#else
	    GlobalVariables::GlobalFlags.cudaFlag=false;
#endif
	    if (na+1==argc) break;
	    ++na;
	}		
	else if ( 0 == strcmp(argv[na],"-pXGamthresh_low") )
	{
#if _CUDA_
	    GlobalVariables::CudaOpts.pXGam_threshold_low =atoi(argv[++na]);
#endif
	    if (na+1==argc) break;
	    ++na;
	}
			
	else if ( 0 == strcmp(argv[na],"-pXGamthresh_high") )
	{
#if _CUDA_
	    GlobalVariables::CudaOpts.pXGam_threshold_high =atoi(argv[++na]);
#endif
	    if (na+1==argc) break;
	    ++na;
	}
	// ESS only
	else if ( 0 == strcmp(argv[na],"-timeLimit") )
	{
	    time_limit=atof(argv[++na]);
	    if (na+1==argc) break;
	    ++na;
	}
	else
	{
	    clog << "Unknown option: " << argv[na] << endl;
#if _CUDA_
	    stopCula();
#endif
	    exit(1);
	}
    }//end reading from command line

    // Checking if the required parameters are in
    if(!X_Flag) undefined_matrix_error("predictor matrix X");
    if(!Y_Flag) undefined_matrix_error("outcome matrix Y");

    if(Settings.postProcOnly)
    {
	Settings.resumeRun=false;
	GlobalVariables::GlobalFlags.fixInit=false;
	Settings.extendRun=0;
    }

    //Setting score specifics
    Score::setLikelihoodStrategy(GlobalVariables::GlobalFlags.LikelihoodType);
    Score::setPenalizationStrategy(GlobalVariables::GlobalFlags.PenalizationType);

    //Input matrix X and matrix Y in the MCMC
    clog << "Reading input files\n";
    mcmc->setMatrixFiles(filename_in_mat_X,filename_in_mat_Y);
    mcmc->readMatrixX();
    mcmc->readMatrixY();

    //Setting up modeling parameters.
    unsigned int n_top_models=Settings.numSweeps;

    //Reading elements of the par file and checking for each parameter
    if(n_top_models_from_read!=0)
    {
	n_top_models=n_top_models_from_read;
    }

    // Add in the number of confounders
    Settings.Egam += Settings.nConfounders;

    // Set the limit on the maximum number of factors
    unsigned int maxPGamma = (unsigned int)(Settings.Egam+Settings.Sgam*Settings.maxPGammaFactor);
    if(maxPGamma>MCMC::nX)
    {
	maxPGamma=MCMC::nX;
    }

    //Moves Parameters

    //Temperature Placement
    // Initialize to default values
    //vector < double > M_input(2);
    //M_input[0]=Settings.mmin;
    //M_input[1]=Settings.mmax;

    if (GlobalVariables::GlobalFlags.Log_Flag)
	clog << "Initialising MCMC\n";

    MCMC::initializeRandomNumberGenerator(MY_SEED);

    open_and_initialize_files(path_name_out,Settings.nChains);

    //////////////////////////////////
    //  Setting up prior parameters
    //////////////////////////////////
    Prior::set(Settings.Egam,
	       Settings.Sgam,
	       MCMC::pX,
	       mcmc->pY,
	       MCMC::nX,
	       ScoreESS::lambda,
	       Settings.pMutation,
	       Settings.pSel,
	       Settings.pCsrv,
	       Settings.pDR);

    mcmc->initializeFromRead(Settings.numSweeps,
			     burn_in,
			     n_top_models_from_read,
			     Settings.nConfounders,
			     Settings.extendRun,
			     Settings.nChains,
			     Settings.gibbsNbatch,
			     maxPGamma,
			     g_init,
			     time_limit,
			     MY_SEED);

    mcmc->initializeAdaptiveMH(Settings.gNBatch,
			       Settings.gAdMH_optimal,
			       Settings.gAdMH_ls,
			       Settings.gMmin,
			       Settings.gMmax);

    mcmc->initializeCrossover(Settings.crossoverKmax);


    if(Settings.resumeRun||Settings.postProcOnly||Settings.extendRun)
    {
	//Check if resuming, post processing or extend
	mcmc->createChainsfromResume();
    }
    else
    {
	// if not resume, postprocessing or extend field --> initialization
	if(!GlobalVariables::GlobalFlags.fixInit)
	{
	    // CCS TODO: Fix
	    mcmc->createChainsfromSimple();
	    //mcmc->createChainsfromRegression();
	}
	else
	{
	    // if the fixInit is set then we don't do regression
	    // and we read from input instead
	    mcmc->createChainsfromFixed();
	    
	}// finish regression using a fixInit input file
    }// finish all regression clause if not for resume, post-processing or extend

    //Prior::updateKwithRMSE(mcmc->vect_RMSE());
    //mcmc->set_prior_k(Prior::k);
    clog << "************* WARNING: Using fixed k prior\n";
    mcmc->set_prior_k(1e-3);

    if(!Settings.postProcOnly)
    {
	Prior::display();
    }

    mcmc->initializeTemperature(Settings.bt,
				Settings.at_under5k,
				Settings.at_5k10k,
				Settings.at_over10k,
				Settings.tempNbatch,
				Settings.mInput,
				Settings.tempOptimal);

    /////////////////////////////////////////
    ///Printing options ////////////////////
    ///////////////////////////////////////

    //clog << "**********************************************************" << endl
    clog << "***************** Setup options **********************" << endl;

    if(Settings.postProcOnly)
    {
	clog << "Post processing previous run only" << endl;
    }
    else
    {
	if(Settings.resumeRun)
	{
	    clog << "Resuming previous run" << endl;
	}
	else if(Settings.extendRun)
	{
	    clog << "Extending previous run for " << Settings.extendRun << " sweeps" << endl;
	}
	else
	{
	    clog << "Random seed " << MY_SEED << endl;
	}
	clog << "nb_chains " << Settings.nChains << endl
	     << "n_sweeps " << Settings.numSweeps << endl
	     << "n_top_models " << n_top_models << endl
	     << "burn_in " << burn_in << endl
	     << "E_p_gam_input " << Settings.Egam-Settings.nConfounders << endl
	     << "Sd_p_gam_input " << Settings.Sgam << endl
	     << "Max_p_gam_factor " << Settings.maxPGammaFactor << endl
	     << "Max p_gam " << maxPGamma-Settings.nConfounders << endl;

	if(Settings.gSampleFlag)
	{
	    clog << "Sampling g" << endl;
	}
	else
	{
	    clog << "Not sampling g" << endl;
	    clog << "g " << g_init << endl;
	}

	if(Settings.priorType == GlobalSettings::gPrior)
	{
	    clog << "Using g prior" << endl;
	}
	else
	{
	    if(Settings.priorType == GlobalSettings::Independent)
	    {
		clog << "Using independence prior" << endl;
	    }
	    else
	    {
		clog << "Using powered prior with lambda = " << ScoreESS::lambda << endl;
	    }
	}

	clog << "CUDA " << GlobalVariables::GlobalFlags.cudaFlag << endl;
	clog << "No. confounders " << Settings.nConfounders << endl;
    }

    //clog << "**********************************************************" << endl
    //	 << "**********************************************************" << endl << endl;

    if(!Settings.postProcOnly&&!Settings.resumeRun&&!GlobalVariables::GlobalFlags.fixInit&&!Settings.extendRun)
    {
	//clog << "**********************************************************" << endl
	clog << endl << "*************** Regression parameters ********************" << endl
	     << "n_Pvalue_enter " << Settings.regrNpEnter << endl
	     << "n_Pvalue_remove " << Settings.regrNpEnter << endl
	     << "Pvalue_enter stepwise " << Regression::Pvalue_enter << endl
	     << "Pvalue_remove stepwise " << Regression::Pvalue_remove << endl;
	//     << "**********************************************************" << endl
	// << "**********************************************************" << endl << endl;
    }

    if(!Settings.postProcOnly)
    {
	//clog << "**********************************************************" << endl
	clog << endl << "****************** MOVES parameters **********************" << endl
	     << "g-adaptative M-H" << endl
	     << "\t-g_n_batch: " << Settings.gNBatch << endl
	     << "\t-g_AdMH_optimal: " << Settings.gAdMH_optimal << endl
	     << "\t-g_AdMH_ls: " << Settings.gAdMH_ls << endl
	     << "Crossover Move" << endl
	     << "\tk_max: " << Settings.crossoverKmax << endl
	     << "Gibbs Move" << endl
	     << "\tGibbs_n_batch: " << Settings.gibbsNbatch << endl;
	//     << "**********************************************************" << endl
	//     << "**********************************************************" << endl << endl;

	//clog << "**********************************************************" << endl
	clog << endl << "****************** TEMP parameters **********************" << endl
	     << "b_t " << Settings.bt << endl
	     << "a_t_den_inf_5k " << Settings.at_under5k << endl
	     << "a_t_den_5_10k " << Settings.at_5k10k << endl
	     << "a_t_den_sup_10k " << Settings.at_over10k << endl
	     << "temp_n_batch " << Settings.tempNbatch << endl
	     << "temp_optimal " << Settings.tempOptimal << endl
	     << " M= [" << Settings.mInput[0] << " - " << Settings.mInput[1] << "]" << endl;
	//     << "**********************************************************" << endl
	//     << "**********************************************************" << endl << endl;
    }
}

void open_and_initialize_files(char* path_name_out,unsigned int n_chains)
{
    //Testing PATH-file names for the creation of output files
    string Extension_out=".txt";
    string Main_Output_name="output_models_history";
    string OutputName=get_standarized_name(path_name_out,
					   Main_Output_name,
					   Extension_out);
    string OutputName_n_vars_in=get_standarized_name(path_name_out,
						     "output_model_size_history",
						     Extension_out);
    string OutputName_n_models_visited=get_standarized_name(path_name_out,
							    "output_n_models_visited_history",
							    Extension_out);
    string OutputName_log_cond_post_per_chain=get_standarized_name(path_name_out,
								   "output_log_cond_post_prob_history",
								   Extension_out);
    string OutputName_FSMH=get_standarized_name(path_name_out,
						"output_fast_scan_history",
						Extension_out);
    string OutputName_CM=get_standarized_name(path_name_out,
					      "output_cross_over_history",
					      Extension_out);
    string OutputName_AE=get_standarized_name(path_name_out,
					      "output_all_exchange_history",
					      Extension_out);
    string OutputName_DR=get_standarized_name(path_name_out,
					      "output_delayed_rejection_history",
					      Extension_out);
    string OutputName_g=get_standarized_name(path_name_out,
					     "output_g_history",
					     Extension_out);
    string OutputName_g_adapt=get_standarized_name(path_name_out,
						   "output_g_adaptation_history",
						   Extension_out);
    string OutputName_Gibbs=get_standarized_name(path_name_out,
						 "output_gibbs_history",
						 Extension_out);
    string OutputName_t_tun=get_standarized_name(path_name_out,
						 "output_temperature_history",
						 Extension_out);
    GlobalVariables::InputOutputFileNames.resume=get_standarized_name(path_name_out,
								      "resume",
								      Extension_out);
    GlobalVariables::InputOutputFileNames.rng=get_standarized_name(path_name_out,
								   "random",
								   ".rng");

    ios_base::openmode fileMode;

    if(Settings.resumeRun || Settings.extendRun)
    {
	fileMode=ios::app;
    }
    else
    {
	fileMode=ios::out;
    }

    if(GlobalVariables::GlobalFlags.HistoryFlag)
    {
	if(Settings.resumeRun||Settings.postProcOnly||Settings.extendRun)
	{
	    GlobalVariables::InputFileStreams.f_in.open(OutputName.c_str(),ios::in);
	    if(GlobalVariables::InputFileStreams.f_in.fail())
	    {
		clog << "Trying to resume a run where no history was written -- stopping run" << endl;
#if _CUDA_
		stopCula();
#endif
		exit(-1);
	    }

	    if(Settings.resumeRun || Settings.extendRun)
	    {
		GlobalVariables::OutputFileStreams.f_out.open(OutputName.c_str(),fileMode);
	    }
	}
	else
	{
	    GlobalVariables::OutputFileStreams.f_out.open(OutputName.c_str(),fileMode);
	}

	if(!Settings.postProcOnly)
	{
	    if(GlobalVariables::OutputFileStreams.f_out.fail())
	    {
		clog << "Invalid Path and/or permission rights for " << OutputName << " -- run stopped." << endl;
#if _CUDA_
		stopCula();
#endif
		exit(-1);
	    }
	    else
	    {
		if(!Settings.resumeRun && !Settings.extendRun)
		{
		    GlobalVariables::OutputFileStreams.f_out << "Sweep\tModel_size\tlog_marg\tlog_cond_post\tModel"<<endl;
		}
	    }

	    GlobalVariables::OutputFileStreams.f_out_n_vars_in.open(OutputName_n_vars_in.c_str(),fileMode);

	    if(GlobalVariables::OutputFileStreams.f_out_n_vars_in.fail())
	    {
		clog << "Invalid Path and/or permission rights for " << OutputName_n_vars_in << " -- run stopped." << endl;
#if _CUDA_
		stopCula();
#endif
		exit(-1);
	    }
	    else
	    {
		if(!Settings.resumeRun && !Settings.extendRun)
		{
		    GlobalVariables::OutputFileStreams.f_out_n_vars_in << "Sweep\t";
		    for(unsigned int tmp_chain=0;tmp_chain<n_chains;tmp_chain++)
		    {
			GlobalVariables::OutputFileStreams.f_out_n_vars_in << "Chain_"<< tmp_chain+1 << "\t";
		    }
		    GlobalVariables::OutputFileStreams.f_out_n_vars_in << endl;
		}
	    }
	}

	if(Settings.resumeRun||Settings.postProcOnly||Settings.extendRun)
	{
	    GlobalVariables::InputFileStreams.f_in_n_models_visited.open(OutputName_n_models_visited.c_str(),ios::in);
	    if(GlobalVariables::InputFileStreams.f_in_n_models_visited.fail())
	    {
		clog << "Trying to resume a run where no history was written -- stopping run" << endl;
#if _CUDA_
		stopCula();
#endif
		exit(-1);
	    }

	    if(Settings.resumeRun || Settings.extendRun)
	    {
		GlobalVariables::OutputFileStreams.f_out_n_models_visited.open(OutputName_n_models_visited.c_str(),fileMode);
	    }
	}
	else
	{
	    GlobalVariables::OutputFileStreams.f_out_n_models_visited.open(OutputName_n_models_visited.c_str(),fileMode);
	}

	if(!Settings.postProcOnly)
	{
	    if(GlobalVariables::OutputFileStreams.f_out_n_models_visited.fail())
	    {
		clog << "Invalid Path and/or permission rights for " << OutputName_n_models_visited << " -- run stopped." << endl;
#if _CUDA_
		stopCula();
#endif
		exit(-1);
	    }
	    else
	    {
		if(!Settings.resumeRun  && !Settings.extendRun)
		{
		    GlobalVariables::OutputFileStreams.f_out_n_models_visited << "Sweep\tn_models_visited" << endl;
		}
	    }
	}

	if(!Settings.postProcOnly)
	{
	    GlobalVariables::OutputFileStreams.f_out_log_cond_post_per_chain.open(OutputName_log_cond_post_per_chain.c_str(),fileMode);
	    if(GlobalVariables::OutputFileStreams.f_out_log_cond_post_per_chain.fail())
	    {
		clog << "Invalid Path and/or permission rights for " << OutputName_log_cond_post_per_chain << " -- run stopped." << endl;
#if _CUDA_
		stopCula();
#endif
		exit(-1);
	    }
	    else
	    {
		if(!Settings.resumeRun && !Settings.extendRun)
		{
		    GlobalVariables::OutputFileStreams.f_out_log_cond_post_per_chain << "Sweep"<< "\t";
		    for(unsigned int tmp_chain=0;tmp_chain<n_chains;tmp_chain++)
		    {
			GlobalVariables::OutputFileStreams.f_out_log_cond_post_per_chain << "Chain_"<< tmp_chain+1 << "\t";
		    }
		    GlobalVariables::OutputFileStreams.f_out_log_cond_post_per_chain << endl;
		}
	    }

	    GlobalVariables::OutputFileStreams.f_out_Gibbs.open(OutputName_Gibbs.c_str(),fileMode);
	    GlobalVariables::OutputFileStreams.f_out_FSMH.open(OutputName_FSMH.c_str(),fileMode);
	    GlobalVariables::OutputFileStreams.f_out_CM.open(OutputName_CM.c_str(),fileMode);
	    GlobalVariables::OutputFileStreams.f_out_AE.open(OutputName_AE.c_str(),fileMode);
	    GlobalVariables::OutputFileStreams.f_out_DR.open(OutputName_DR.c_str(),fileMode);
	    if(Settings.gSampleFlag)
	    {
		GlobalVariables::OutputFileStreams.f_out_g.open(OutputName_g.c_str(),fileMode);
		GlobalVariables::OutputFileStreams.f_out_g_adapt.open(OutputName_g_adapt.c_str(),fileMode);
	    }
	    if(Settings.noTemperature==false)
	    {
		GlobalVariables::OutputFileStreams.f_out_t_tun.open(OutputName_t_tun.c_str(),fileMode);
	    }
	}
    }// End of History Flag
    else
    {
	// No History Flag

	if(Settings.resumeRun||Settings.postProcOnly||Settings.extendRun)
	{
	    clog << "Trying to resume a run where no history was written -- stopping run" << endl;
#if _CUDA_
	    stopCula();
#endif
	    exit(-1);
	}
    }// End of No History Flag

    //Initializing standard output files

    string OutputName_time;

    if(!Settings.postProcOnly)
    {
	if(GlobalVariables::GlobalFlags.Time_monitorFlag)
	{
	    OutputName_time=get_standarized_name(path_name_out,
						 "output_time_monitor",
						 Extension_out);
	    GlobalVariables::OutputFileStreams.f_out_time.open(OutputName_time.c_str(),fileMode);
	    if(!Settings.resumeRun && !Settings.extendRun)
	    {
		GlobalVariables::OutputFileStreams.f_out_time << "Sweep\tTime\tTime_per_eval_model"<<endl;
	    }
	}
    }

    string OutputName_best_models=get_standarized_name(path_name_out,
						       "output_best_visited_models",
						       Extension_out);

    GlobalVariables::OutputFileStreams.f_out_best_models.open(OutputName_best_models.c_str(),ios::out);
    if(GlobalVariables::OutputFileStreams.f_out_best_models.fail())
    {
	clog << "Invalid Path and/or permission rights for " << OutputName_best_models << " -- run stopped." << endl;
#if _CUDA_
	stopCula();
#endif
    	exit(-1);
    }
    else
    {
	if(GlobalVariables::GlobalFlags.Out_full_Flag)
	{
	    GlobalVariables::OutputFileStreams.f_out_best_models << "Rank\t#Visits\tSweep_1st_visit\t#models_eval_before_1st_visit\tModel_size\tlog_Post_Prob\tModel_Post_Prob\tJeffreys_scale\tModel"<<endl;
	}
	else
	{
	    GlobalVariables::OutputFileStreams.f_out_best_models << "Rank\t#Visits\tModel_size\tlog_Post_Prob\tModel_Post_Prob\tJeffreys_scale\tModel"<<endl;
	}
    }

    string OutputName_features=get_standarized_name(path_name_out,
						    "features",
						    Extension_out);

    GlobalVariables::OutputFileStreams.f_out_features.open(OutputName_features.c_str(),ios::out);
    if(GlobalVariables::OutputFileStreams.f_out_features.fail())
    {
	clog << "Invalid Path and/or permission rights for " << OutputName_features << " -- run stopped." << endl;
#if _CUDA_
	stopCula();
#endif
    	exit(-1);
    }
    else
    {
	GlobalVariables::OutputFileStreams.f_out_features << "Feature\tvalue"<<endl;
    }

    string OutputName_marg_gam=get_standarized_name(path_name_out,
						    "output_marg_prob_incl",
						    Extension_out);

    GlobalVariables::OutputFileStreams.f_out_marg_gam.open(OutputName_marg_gam.c_str(),ios::out);
    if(GlobalVariables::OutputFileStreams.f_out_marg_gam.fail())
    {
	clog << "Invalid Path and/or permission rights for " << OutputName_marg_gam << " -- run stopped." << endl;
#if _CUDA_
	stopCula();
#endif
    	exit(-1);
    }
    else
    {
	GlobalVariables::OutputFileStreams.f_out_marg_gam << "Predictor\tMarg_Prob_Incl"<< endl;
    }
}

void undefined_matrix_error(string matrix_name)
{
    clog << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl
	 << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl
	 << "   The "<< matrix_name <<" has not been specified, RUN STOPPED" << endl
	 << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl
	 << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;

#if _CUDA_
    stopCula();
#endif

    exit(1);
}
