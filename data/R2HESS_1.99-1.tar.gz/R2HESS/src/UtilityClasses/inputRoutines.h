/* This file is part of ESS-OO.
 *      Copyright (c) Marc Chadeau-Hyam (m.chadeau@imperial.ac.uk)
 *                    Leonardo Bottolo (l.bottolo@imperial.ac.uk)
 *                    David Hastie (d.hastie@imperial.ac.uk)
 *      2014
 * Software designed and restructured by Loizos Markides (lm1011@ic.ac.uk)
 * ESS-OO is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ESS-OO is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ESS-OO.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef INPUTROUTINES_H_
#define INPUTROUTINES_H_

#include <stdlib.h>
#include <stddef.h>
#include <stdarg.h>
#include <string.h>
#include <stdio.h>
#include <cstring>
#include <iostream>
#include <sstream>
#include <cstdarg>
#include "../MCMC/Regression.h"
#include "../MCMC/MCMC.h"
#include "GlobalVariables.h"

std::string get_standarized_name(std::string File_name,
			    std::string Output_type,
			    std::string Extension);

void read_arguments(int argc, char *  argv[],
		    MCMC *mcmc);

void open_and_initialize_files(char* path_name_out,
			       unsigned int n_chains);

void undefined_matrix_error(std::string matrix_name);

#endif /* INPUTROUTINES_H_ */
