#include <fstream>
#include <boost/program_options.hpp>
#include "Settings.hpp"
#include "../MCMC/Regression.h"
#include "../HESS/ScoreHESS.h"

/**
 * Removed options
 * -time_limit: Was not used in HESS (may be re-added for ESS)
 * -gam_set: Disable the gamma update move. Was buggy so didn't work.
 */

/**
 * Unimplemented options:
 * GPU:
 * -cuda: Set GlobalVariables::GlobalFlags.cudaFlag
 * -pXGamthresh_low: / -pXGamthresh_high: Set GlobalVariables::CudaOpts.pXGam_threshold_{low,high}
 */

namespace po = boost::program_options;

using std::string;

void GlobalSettings::readProgramOptions(int argc, char *argv[]) {

    try {
	po::options_description optionsList("Allowed options");
        optionsList.add_options()
            ("help", "produce help message")
	    ("config", po::value<string>(), "Name of configuration file")

            ("model", po::value<int>(), "Select model: 0 for ESS, 1 for HESS")
	    ("log", po::value<string>(), "Name of log file (default is stdout)")
	    ("verbose", po::bool_switch()->default_value(verbose), "Print verbose output")
	    ("X", po::value<string>(), "Name of X matrix input file")
	    ("Y", po::value<string>(), "Name of Y matrix input file")
	    ("nConfounders", po::value<int>(), "")

	    ("nsweep", po::value<int>(), "Total number of sweeps (including burn-in)")
	    ("burn_in", po::value<int>(), "Number of burn-in sweeps")
	    ("seed", po::value<long>(), "Random number seed")
	    ("resume", po::bool_switch()->default_value(resumeRun), "")
	    ("extend", po::value<int>(), "")
	    ("n_chain", po::value<int>(), "Number of chains")

	    ("init-regression", po::value<string>(), "Regression method for model initialisation: one of 'simple' (default) or 'stepwise'")
	    ("eigenstorage", po::bool_switch()->default_value(eigenstorage), "In likelihood calculation, store a dictionary of eigen decompositions")
	    ("no-standardise-X", po::bool_switch()->default_value(! standardiseX), "Disable standardisation of X matrix")
	    ("no-temperature", po::bool_switch()->default_value(noTemperature), "Disable temperatures for each chain")

	    ("lambda", po::value<double>(), "Specify lambda value for prior; if 0, use independent prior")
	    ("likelihood", po::value<string>(), "Likelihood type: one of 'linear' (default), 'survival', 'glm'")
	    ("penalisation", po::value<string>(), "Penalisation type: one of 'fixed' (default), 'bernoulli', 'binomial'")

	    ("calcMPPI", po::bool_switch()->default_value(calcMPPI), "Run postprocessing code to calculate MPPI (can be very slow)")
	    
	    ("Egam", po::value<double>(), "")
	    ("Sgam", po::value<double>(), "")
	    ("max-pgamma-factor", po::value<double>(), "")
	    
	    ("p-mutation", po::value<double>(), "")
	    ("p-sel", po::value<double>(), "")
	    ("p-csrv", po::value<double>(), "")
	    ("p-dr", po::value<double>(), "")
	    ("regress-npval-enter", po::value<double>(), "")
	    ("regress-npval-remove", po::value<double>(), "")

	    ("prior-g-alpha", po::value<double>(), "")
	    ("prior-g-beta", po::value<double>(), "")

	    ("g-nbatch", po::value<unsigned>(), "")
	    ("g-admh-optimal", po::value<double>(), "")
	    ("g-admh-ls", po::value<double>(), "")
	    ("g-mmin", po::value<double>(), "")
	    ("g-mmax", po::value<double>(), "")
	    
	    ("crossover-kmax", po::value<unsigned>(), "")
	    ("gibbs-nbatch", po::value<unsigned>(), "")

	    ("bt", po::value<double>(), "")
	    ("at-under5k", po::value<double>(), "")
	    ("at-5k10k", po::value<double>(), "")
	    ("at-over10k", po::value<double>(), "")
	    ("temp-nbatch", po::value<double>(), "")
	    ("temp-optimal", po::value<double>(), "")
	    ("m-min", po::value<double>(), "")
	    ("m-max", po::value<double>(), "")

	    ("gamma-count-interval", po::value<int>(), "Save gamma counts every n sweeps")
	    
	    ("g-init", po::value<double>(), "")
	    ("g-sample", po::bool_switch()->default_value(gSampleFlag), "")
	    ("multiple-g", po::bool_switch()->default_value(! singleG), "") // Inverse logic for backwards compatibility

	    ("active-y", po::value<double>(), "")

	    ("adaptive-selection", po::bool_switch()->default_value(adaptiveSelection), "")
	    ("adapt-weights-fn", po::value<std::string>(), "")
	    ("adapt-batch-size", po::value<int>(), "Update chosen transcripts for adaptive selection every n sweeps")
	    ("adapt-c", po::value<int>(), "")
	    
	    ("gamma-update-move", po::bool_switch()->default_value(gammaUpdateMove), "Perform covariance-based gamma update move")
	    ("gamma-update-move-prob", po::value<double>(), "Probability of choosing the covariance-based move, given that we do a local move")
	    ("gamma-update-swap-prob", po::value<double>(), "Gamma update: Probability of swapping vars")
	    ("gamma-update-add-prob", po::value<double>(), "Gamma update: Given we are not swapping, probability of adding a variable (as opposed to removing one)")
	    ("gamma-update-rand-geometric", po::value<double>(), "Gamma update: When selecting variable to add, probability of using geometric distribution (as opposed to uniform) to choose variable")
	    ("gamma-update-geometric-invprob", po::value<double>(), "Gamma update: Inverse probability p for the geometric distribution")

	    ("omegak-a", po::value<double>(), "")
	    ("omegak-b", po::value<double>(), "")
	    ("rhoj-c", po::value<double>(), "")
	    ("rhoj-d", po::value<double>(), "")

	    ("postproc", po::bool_switch()->default_value(doPostProc), "")
	    ("postproc-only", po::bool_switch()->default_value(postProcOnly), "")
	    ("slow-postproc", po::bool_switch()->default_value(slowPostProc), "")
	    ("memory-limited", po::bool_switch()->default_value(memLimited), "")

	    ("top-n-models", po::value<int>(), "Maximum number of models to show in best models list")

	    ("init", po::value<string>(), "")  // Read initial gamma from file
	    ("init-omega", po::value<string>(), "")
	    ("init-omega-fixed", po::value<string>(), "")
	    ("init-rho", po::value<string>(), "")
	    ("init-rho-fixed", po::value<string>(), "")

	    ("out", po::value<string>(), "Output directory and/or file prefix")
	    ("out_full", po::value<string>(), "Output directory (deprecated in favour of '-out' flag)")

	    ("out-activeY", po::bool_switch()->default_value(outFlags.activeY), "Save matrix of active transcripts at each iteration")
	    ("out-adapt-batch-weights", po::bool_switch()->default_value(outFlags.adaptBatchWeights), "")
	    ("out-av-matrix-omega", po::bool_switch()->default_value(outFlags.avMatrixOmega), "Save matrix of average omega_kj")
	    ("out-best-models", po::bool_switch()->default_value(outFlags.bestModels), "")
	    ("out-cbaccept", po::bool_switch()->default_value(outFlags.cbAccept), "")
	    ("out-fsmh-accept", po::bool_switch()->default_value(outFlags.fsmhAccept), "")
	    ("out-gamma-counts", po::bool_switch()->default_value(outFlags.gammaCounts), "Save matrix of total gamma counts")
	    ("out-gamma-active-counts", po::bool_switch()->default_value(outFlags.gammaActiveCounts), "")
	    ("out-gamma-proposed", po::bool_switch()->default_value(outFlags.gammaProp), "Save sum of proposed gamma updates over all post-burn-in iterations")
	    ("out-history-g", po::bool_switch()->default_value(outFlags.historyG), "")
	    ("out-history-omega", po::bool_switch()->default_value(outFlags.historyOmega), "Save history of omega values")
	    ("out-history-rho", po::bool_switch()->default_value(outFlags.historyRho), "Save history of rho values")
	    ("out-init-gamma", po::bool_switch()->default_value(outFlags.initGamma), "Save initial model gammas")
	    ("out-ls", po::bool_switch()->default_value(outFlags.ls), "")
	    ("out-models-full", po::bool_switch()->default_value(outFlags.modelsFull), "Save full interim models")
	    ("out-model-post-prob", po::bool_switch()->default_value(outFlags.modelPostProb), "")
	    ("out-model-sizes", po::bool_switch()->default_value(outFlags.modelSizes), "Save model sizes at each iteration")
	    ("out-mpi", po::bool_switch()->default_value(outFlags.mpiSimple), "")
	    ("out-mpi-complex", po::bool_switch()->default_value(outFlags.mpiComplex), "")
	    ("out-mpi-unique", po::bool_switch()->default_value(outFlags.mpiUnique), "")
	    ("out-rsquare", po::bool_switch()->default_value(outFlags.rsquare), "Save r-squared values")
	    ("out-sgamma", po::bool_switch()->default_value(outFlags.sgamma), "Save sgamma values used to calculate R2")
	    ("out-tail-probs", po::bool_switch()->default_value(outFlags.tailProbs), "")

	    ;

        po::variables_map store;

	// Process command line options
	po::store(po::command_line_parser(argc, argv)
		    .options(optionsList)
		    // Allow single-hyphen -option prefix as well as --option
		    .style(po::command_line_style::unix_style
			   | po::command_line_style::allow_long_disguise)
		    // Ignore unrecognised options - now disabled
		    // .allow_unregistered()
		    .run(),
		  store);
	
	po::notify(store);

	// Read options from configuration file
	// Processing these second implicitly ensures command line options have
	// priority over config file options
	if (store.count("config")) {
	    string configFile = store["config"].as<string>();
	    std::ifstream in(configFile);
	    if (!in) {
		cerr << "Error: Cannot open config file: " << configFile << endl;
		exit(1);
	    }

	    po::store(parse_config_file(in, optionsList), store);
	    in.close();
	}
	// Special options that should be looked at first
	
	if (store.count("help")) {
	    std::cout << optionsList << "\n";
	    exit(0);
	}
	
	if (store.count("log")) {
	    string logFile = store["log"].as<string>();

	    // Using rdbuf to redirect clog only copies the pointer to the buffer.
	    // We must keep the ofstream object alive for the duration of the program.
	    std::ofstream *out = new std::ofstream(logFile);
	    if (! *out) {
		cerr << "Error: Cannot open log file: " << logFile << endl;
		exit(1);
	    }
	    clog.rdbuf(out->rdbuf());
	}

	// For reference, print command line to log
	clog << "Command: ";
	for (int i = 0; i < argc; i++)
	    clog << argv[i] << " ";
	clog << endl;

	//clog << "Executable version " << VERSION << endl;

	// And the config file
	if (store.count("config")) {
	    string configFile = store["config"].as<string>();
	    std::ifstream in(configFile); // We have already error-checked the file
	    clog << "\nConfig file:\n>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n";
	    clog << in.rdbuf();
	    clog << "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<\n\n";
	    in.close();
	}

	// -----------------

	if (store.count("model"))
	    model = (modelT) store["model"].as<int>();
	if (model != modelESS && model != modelHESS)
	    exitWithError("Invalid value of 'model' argument");
	
	// For bool_switch variables, store.count() always returns true
	verbose = store["verbose"].as<bool>();

	if (store.count("X")) {
	    string filename = store["X"].as<string>();
	    Xfile.open(filename);
	    if (! Xfile.is_open())
		exitWithError("Unable to open X file: "  + filename);
	} else
	    exitWithError("X data file was not specified");

	if (store.count("Y")) {
	    string filename = store["Y"].as<string>();
	    Yfile.open(filename);
	    if (! Yfile.is_open())
		exitWithError("Unable to open Y file: " + filename);
	} else
	    exitWithError("Y data file was not specified");
	if (store.count("nConfounders"))
	    nConfounders = store["nConfounders"].as<int>();

	if (store.count("nsweep"))
	    numSweeps = store["nsweep"].as<int>();
	if (numSweeps <= 0)
	    exitWithError("Number of sweeps not specified or <= 0");
	if (store.count("burn_in"))
	    burnIn = store["burn_in"].as<int>();
	if (burnIn >= numSweeps)
	    exitWithError("Number of burn-in sweeps >= total number of sweeps");

	if (store.count("seed"))
	    seed = store["seed"].as<long>();
	resumeRun = store["resume"].as<bool>();
	if (store.count("extend"))
	    extendRun = store["extend"].as<int>();
	if (store.count("n_chain"))
	    nChains = store["n_chain"].as<int>();

	if (store.count("init-regression")) {
	    string val = store["init-regression"].as<string>();
	    if (val == "simple")
		initRegression = GlobalSettings::simple;
	    else if (val == "stepwise")
		initRegression = GlobalSettings::stepwise;
	    else
		exitWithError("Parameter 'init-regression' has invalid value. Should be one of 'simple' or 'stepwise'");
	}
	eigenstorage = store["eigenstorage"].as<bool>();
	standardiseX = ! store["no-standardise-X"].as<bool>();
	noTemperature = store["no-temperature"].as<bool>();

	if (store.count("lambda")) {
	    Score::lambda = store["lambda"].as<double>();
	    if (model == modelHESS)
		ScoreHESS::lambda = store["lambda"].as<double>();
	    if (fabs(Score::lambda) < 1e-10)
		priorType = Independent;
	}
	if (store.count("likelihood")) {
	    string val = store["likelihood"].as<string>();
	    if (val == "linear")
		likelihoodType = GlobalSettings::Linear;
	    else if (val == ("glm"))
		likelihoodType = GlobalSettings::GLM;
	    else if (val == ("survival"))
		likelihoodType = GlobalSettings::Survival;
	    else
		exitWithError("Parameter 'likelihood' has invalid value. Should be one of 'linear', 'survival' or 'glm'");
	}

	if (store.count("penalisation")) {
	    string val = store["penalisation"].as<string>();
	    if (val == "fixed")
		penalisationType = GlobalSettings::wmegaFixed;
	    else if (val == "binomial")
		penalisationType = GlobalSettings::wmegaBetaBinomial;
	    else if (val == "bernoulli")
		penalisationType = GlobalSettings::wmegaBernoulli;
	    else
		exitWithError("Parameter 'penalisation' has invalid value. Should be one of 'fixed', 'bernoulli' or 'binomial'");
	}

	calcMPPI = store["calcMPPI"].as<bool>();
	
	if (store.count("Egam"))
	    Egam = store["Egam"].as<double>();
	if (store.count("Sgam"))
	    Sgam = store["Sgam"].as<double>();
	if (store.count("max-pgamma-factor"))
	    maxPGammaFactor = store["max-pgamma-factor"].as<double>();

	if (store.count("p-mutation"))
	    pMutation = store["p-mutation"].as<double>();
	if (store.count("p-sel"))
	    pSel = store["p-sel"].as<double>();
	if (store.count("p-csrv"))
	    pCsrv = store["p-csrv"].as<double>();
	if (store.count("p-dr"))
	    pDR = store["p-dr"].as<double>();
	if (store.count("regress-npval-enter"))
	    regrNpEnter = store["regress-npval-enter"].as<double>();
	if (store.count("regress-npval-remove"))
	    regrNpRemove = store["regress-npval-remove"].as<double>();

	if (store.count("prior-g-alpha"))
	    priorGalpha = store["prior-g-alpha"].as<double>();
	if (store.count("prior-g-beta"))
	    priorGbeta = store["prior-g-beta"].as<double>();

	if (store.count("g-nbatch"))
	    gNBatch = store["g-nbatch"].as<unsigned>();
	if (store.count("g-admh-optimal"))
	    gAdMH_optimal = store["g-admh-optimal"].as<double>();
	if (store.count("g-admh-ls"))
	    gAdMH_ls = store["g-admh-ls"].as<double>();
	if (store.count("g-mmin"))
	    gMmin = store["g-mmin"].as<double>();
	if (store.count("g-mmax"))
	    gMmax = store["g-mmax"].as<double>();
	
	if (store.count("bt"))
	    bt = store["bt"].as<double>();
	if (store.count("at-under5k"))
	    at_under5k = store["at-under5k"].as<double>();
	if (store.count("at-5k10k"))
	    at_5k10k = store["at-5k10k"].as<double>();
	if (store.count("at-over10k"))
	    at_over10k = store["at-over10k"].as<double>();
	if (store.count("temp-nbatch"))
	    tempNbatch = store["temp-nbatch"].as<double>();
	if (store.count("temp-optimal"))
	    tempOptimal = store["temp-optimal"].as<double>();

	if (store.count("m-min"))
	    mInput[0] = store["m-min"].as<double>();
	if (store.count("m-max"))
	    mInput[1] = store["m-max"].as<double>();

	if (store.count("crossover-kmax"))
	    crossoverKmax = store["crossover-kmax"].as<unsigned>();
	if (store.count("gibbs-nbatch"))
	    gibbsNbatch = store["gibbs-nbatch"].as<unsigned>();

	if (store.count("g-init")) {
	    gInitFlag = true;
	    gInit = store["g-init"].as<double>();
	}
	gSampleFlag = store["g-sample"].as<bool>();
	singleG = ! store["multiple-g"].as<bool>();

	if (gSampleFlag && store.count("g-init"))
	    clog << "Warning: The g-sample flag is true, so the provided g-init value is ignored\n";

	if (store.count("gamma-count-interval"))
	    gammaCountInterval = store["gamma-count-interval"].as<int>();

	if (store.count("active-y"))
	    activeY = store["active-y"].as<double>();

	adaptiveSelection = store["adaptive-selection"].as<bool>();
	if (store.count("adapt-weights-fn")) {
	    string val = store["adapt-weights-fn"].as<string>();
	    if (val == "avgModelSize")
		adaptiveWeightsFn = avgModelSize;
	    else if (val == "avgR2")
		adaptiveWeightsFn = avgR2;
	    else
		exitWithError("Parameter 'adapt-weights-fn' has invalid value. Should be one of 'avgModelSize' or 'avgR2'");
	}
	if (store.count("adapt-batch-size"))
	    adaptBatchSize = store["adapt-batch-size"].as<int>();
	if (store.count("adapt-c"))
	    adaptC = store["adapt-c"].as<int>();
	if (adaptC <= 1)
	    exitWithError("Parameter 'adapt-c', for adaptive transcript selection, must be > 1");

	gammaUpdateMove = store["gamma-update-move"].as<bool>();
	if (store.count("gamma-update-move-prob"))
	    gammaUpdateMoveProb = store["gamma-update-move-prob"].as<double>();
	if (store.count("gamma-update-swap-prob"))
	    gammaUpdateSwap = store["gamma-update-swap-prob"].as<double>();
	if (store.count("gamma-update-add-prob"))
	    gammaUpdateAdd = store["gamma-update-add-prob"].as<double>();
	if (store.count("gamma-update-rand-geometric"))
	    gammaUpdateRandGeometric = store["gamma-update-rand-geometric"].as<double>();
	if (store.count("gamma-update-geometric-invprob"))
	    gammaUpdateGeometricInvProb = store["gamma-update-geometric-invprob"].as<double>();

	if (store.count("omegak-a"))
	    omegak_a = store["omegak-a"].as<double>();
	if (store.count("omegak-b"))
	    omegak_b = store["omegak_b"].as<double>();
	if (store.count("rhoj-c"))
	    rhoj_c = store["rhoj-c"].as<double>();
	if (store.count("rhoj-d"))
	    rhoj_d = store["rhoj-d"].as<double>();

	doPostProc = store["postproc"].as<bool>();
	postProcOnly = store["postproc-only"].as<bool>();
	slowPostProc = store["slow-postproc"].as<bool>();
	memLimited = store["memory-limited"].as<bool>();

	if (store.count("top-n-models"))
	    topNModels = store["top-n-models"].as<int>();

	if (store.count("init")) {
	    initGamma = true;
	    initGammaName = store["init"].as<string>();
	}
	if (store.count("init-omega") && store.count("init-omega-fixed"))
	    exitWithError("Only one of 'init-omega' and 'init-omega-fixed' can be used at one time");
	if (store.count("init-omega")) {
	    initOmega = true;
	    initOmegaName = store["init-omega"].as<string>();
	}
	if (store.count("init-omega-fixed")) {
	    initOmega = true;
	    fixOmega = true;
	    initOmegaName = store["init-omega-fixed"].as<string>();
	}
	if (store.count("init-rho") && store.count("init-rho-fixed"))
	    exitWithError("Only one of 'init-rho' and 'init-rho-fixed' can be used at one time");
	if (store.count("init-rho")) {
	    initRho = true;
	    initRhoName = store["init-rho"].as<string>();
	}
	if (store.count("init-rho-fixed")) {
	    initRho = true;
	    fixRho = true;
	    initRhoName = store["init-rho-fixed"].as<string>();
	}

	if (store.count("out_full"))
	    outputDir = store["out_full"].as<string>();
	if (store.count("out"))
	    outputDir = store["out"].as<string>();

	outFlags.activeY = store["out-activeY"].as<bool>();
	outFlags.adaptBatchWeights = store["out-adapt-batch-weights"].as<bool>();
	outFlags.avMatrixOmega = store["out-av-matrix-omega"].as<bool>();
	outFlags.bestModels = store["out-best-models"].as<bool>();
	outFlags.cbAccept = store["out-cbaccept"].as<bool>();
	outFlags.fsmhAccept = store["out-fsmh-accept"].as<bool>();
	outFlags.gammaCounts = store["out-gamma-counts"].as<bool>();
	outFlags.gammaActiveCounts = store["out-gamma-active-counts"].as<bool>();
	outFlags.gammaProp = store["out-gamma-proposed"].as<bool>();
	outFlags.historyG = store["out-history-g"].as<bool>();
	outFlags.historyOmega = store["out-history-omega"].as<bool>();
	outFlags.historyRho = store["out-history-rho"].as<bool>();
	outFlags.initGamma = store["out-init-gamma"].as<bool>();
	outFlags.ls = store["out-ls"].as<bool>();
	outFlags.modelsFull = store["out-models-full"].as<bool>();
	outFlags.modelPostProb = store["out-model-post-prob"].as<bool>();
	outFlags.modelSizes = store["out-model-sizes"].as<bool>();
	outFlags.mpiSimple = store["out-mpi"].as<bool>();
	outFlags.mpiComplex = store["out-mpi-complex"].as<bool>();
	outFlags.mpiUnique = store["out-mpi-unique"].as<bool>();
	outFlags.rsquare = store["out-rsquare"].as<bool>();
	outFlags.sgamma = store["out-sgamma"].as<bool>();
	outFlags.tailProbs = store["out-tail-probs"].as<bool>();

	if (calcMPPI && (! outFlags.historyOmega || ! outFlags.historyRho))
	    // Calculating the MPPI requires storing the omega and rho values
	    exitWithError("Calculating the MPPI requires storing the omega and rho values. If 'calcMPPI' is set, both 'out-history-omega' and 'out-history-rho' must be set.");

	if (postProcOnly) {
	    Settings.resumeRun=false;
	    Settings.initGamma=false;
	    Settings.extendRun=0;
	}

	// Add in the number of confounders
	Egam += nConfounders;

	// Set limit on maximum number of factors
	maxPGamma = Egam + Sgam * maxPGammaFactor;
	

    } catch(std::exception& e) {
	// Thrown when user enters an invalid option
        cerr << "Error: " << e.what() << "\n";
        exit(1);
    }
    return;
}

void openFile(std::ifstream &file, string &name) {
    file.open(name);
    if (! file.is_open())
	exitWithError("unable to open input file: " + name + "\n");
}

void openFile(std::fstream &file, string &name) {
    file.open(Settings.outputDir + name, std::fstream::in | std::fstream::out | std::fstream::trunc);
    if (! file.is_open())
	exitWithError("unable to open file: " + Settings.outputDir + name + "\n");
}

void openFile(std::ofstream &file, string &name) {
    file.open(Settings.outputDir + name);
    if (! file.is_open())
	exitWithError("unable to open file: " + Settings.outputDir + name + "\n");
}

void GlobalSettings::openOutputFiles() {
    if (Settings.outFlags.activeY)
	openFile(Settings.out.activeY, Settings.outNames.activeY);
    if (Settings.outFlags.adaptBatchWeights)
	openFile(Settings.out.adaptBatchWeights, Settings.outNames.adaptBatchWeights);
    if (Settings.outFlags.avMatrixOmega)
	openFile(Settings.out.avMatrixOmega, Settings.outNames.avMatrixOmega);
    if (Settings.outFlags.bestModels) {
	openFile(Settings.out.bestModels, Settings.outNames.bestModels);
	openFile(Settings.out.bestModelsProbs, Settings.outNames.bestModelsProbs);
    }
    if (Settings.outFlags.cbAccept)
	openFile(Settings.out.cbAccept, Settings.outNames.cbAccept);
    if (Settings.outFlags.fsmhAccept)
	openFile(Settings.out.fsmhAccept, Settings.outNames.fsmhAccept);
    if (Settings.outFlags.gammaCounts)
	openFile(Settings.out.gammaCounts, Settings.outNames.gammaCounts);
    if (Settings.outFlags.gammaActiveCounts)
	openFile(Settings.out.gammaActiveCounts, Settings.outNames.gammaActiveCounts);
    if (Settings.outFlags.gammaProp) {
	openFile(Settings.out.gammaProp, Settings.outNames.gammaProp);
	openFile(Settings.out.gammaPropAdd, Settings.outNames.gammaPropAdd);
    }
    if (Settings.outFlags.historyG)
	openFile(Settings.out.historyG, Settings.outNames.historyG);
    if (Settings.outFlags.historyRho) {
	openFile(Settings.out.historyRho, Settings.outNames.historyRho);
	openFile(Settings.out.avRhoJ, Settings.outNames.avRhoJ);
    }
    if (Settings.outFlags.historyOmega) {
	openFile(Settings.out.historyOmega, Settings.outNames.historyOmega);
	openFile(Settings.out.avOmegaK, Settings.outNames.avOmegaK);
    }
    if (Settings.outFlags.initGamma)
	openFile(Settings.out.initGamma, Settings.outNames.initGamma);
    if (Settings.outFlags.ls) {
	openFile(Settings.out.lsOmega, Settings.outNames.lsOmega);
	openFile(Settings.out.lsRho, Settings.outNames.lsRho);
    }
    if (Settings.outFlags.modelsFull)
	openFile(Settings.out.modelsFull, Settings.outNames.modelsFull);
    if (Settings.outFlags.modelPostProb)
	openFile(Settings.out.modelPostProb, Settings.outNames.modelPostProb);
    if (Settings.outFlags.modelSizes)
	openFile(Settings.out.modelSizes, Settings.outNames.modelSizes);
    if (Settings.outFlags.mpiSimple)
	openFile(Settings.out.mpiSimple, Settings.outNames.mpiSimple);
    if (Settings.outFlags.mpiComplex)
	openFile(Settings.out.mpiComplex, Settings.outNames.mpiComplex);
    if (Settings.outFlags.mpiUnique)
	openFile(Settings.out.mpiUnique, Settings.outNames.mpiUnique);

    if (Settings.outFlags.mtBeta)
	openFile(Settings.out.mtBeta, Settings.outNames.mtBeta);
    if (Settings.outFlags.mtDebug)
	openFile(Settings.out.mtDebug, Settings.outNames.mtDebug);
    
    if (Settings.outFlags.rsquare)	
	openFile(Settings.out.rsquare, Settings.outNames.rsquare);
    if (Settings.outFlags.sgamma)
	openFile(Settings.out.sgamma, Settings.outNames.sgamma);
    if (Settings.outFlags.tailProbs)
	openFile(Settings.out.tailProbs, Settings.outNames.tailProbs);

    if (Settings.initGamma)
	openFile(Settings.initGammaFile, Settings.initGammaName);
}


void GlobalSettings::writeSettingsToLog() {

    clog << "***************** Setup options **********************" << endl << endl;

    clog << "Problem Size:" << endl
	 << "\tObservations: " << Settings.nX << endl
	 << "\tVariables: " << Settings.pX << endl
	 << "\tConfounders: " << Settings.nConfounders << endl
	 << "\tResponses: " << Settings.qY << endl
	 << "\tTissues: " << Settings.rFirst << endl
	 << endl
	 << "Total sweeps: " << Settings.numSweeps << endl
	 << "Burn-in sweeps: " << Settings.burnIn << endl
	 << "Chains: " << Settings.nChains << endl
	 << endl;

    if(Settings.postProcOnly)
	clog << "Post processing previous run only" << endl;
    else {

	if(Settings.resumeRun)
	    clog << "Resuming previous run" << endl;
	else if(Settings.extendRun)
	    clog << "Extending previous run for " << Settings.extendRun << " sweeps" << endl;

	clog << "Random number seed " << Settings.seed << endl;

	clog << "n_top_models " << Settings.topNModels << endl
	     << "E_p_gam " << Settings.Egam << endl
	     << "Sd_p_gam " << Settings.Sgam << endl
	     << "Max_p_gam_factor " << Settings.maxPGammaFactor << endl
	     << "Max p_gam " << Settings.maxPGamma << endl
	     << "Single g " << Settings.singleG << endl;

	if(Settings.gSampleFlag) {
	    clog << "Sampling g" << endl;
	    clog << "Initial value " << Settings.gInit << endl;
	} else {
	    clog << "Not sampling g" << endl;
	    clog << "g " << Settings.gInit << endl;
	}

	if(Settings.priorType == GlobalSettings::gPrior)
	    clog << "Using g prior" << endl;
	else {
	    if(Settings.priorType == GlobalSettings::Independent)
		clog << "Using independence prior" << endl;
	    else
		clog << "Using powered prior with lambda = " << Score::lambda << endl;
	}
	clog << endl;
    }

    if (Settings.initRegression == GlobalSettings::simple)
	clog << "Initialising using simple regression\n";
    else if (Settings.initRegression == GlobalSettings::stepwise)
	clog << "Initialising using stepwise regression\n";
    clog << endl << endl;

    if(!Settings.postProcOnly&&!Settings.resumeRun&&!Settings.initGamma&&!Settings.extendRun) {
	clog << "*************** Regression parameters ********************" << endl
	     << "n_Pvalue_enter " << Settings.regrNpEnter << endl
	     << "n_Pvalue_remove " << Settings.regrNpRemove << endl
	     << "Pvalue_enter stepwise " << Regression::Pvalue_enter << endl
	     << "Pvalue_remove stepwise " << Regression::Pvalue_remove << endl << endl;
    }

    if(!Settings.postProcOnly) {
	clog << "****************** MOVES parameters **********************" << endl
	     << "g-adaptative M-H" << endl
	     << "\t-g_n_batch: " << Settings.gNBatch << endl
	     << "\t-g_AdMH_optimal: " << Settings.gAdMH_optimal << endl
	     << "\t-g_AdMH_ls: " << Settings.gAdMH_ls << endl
	     << "Crossover Move" << endl
	     << "\tk_max: " << Settings.crossoverKmax << endl
	     << "Gibbs Move" << endl
	     << "\tGibbs_n_batch: " << Settings.gibbsNbatch << endl << endl;

	clog << "****************** TEMP parameters **********************" << endl
	     << "b_t " << Settings.bt << endl
	     << "a_t_den_inf_5k " << Settings.at_under5k << endl
	     << "a_t_den_5_10k " << Settings.at_5k10k << endl
	     << "a_t_den_sup_10k " << Settings.at_over10k << endl
	     << "temp_n_batch " << Settings.tempNbatch << endl
	     << "temp_optimal " << Settings.tempOptimal << endl
	    << " M= [" << Settings.mInput[0] << " - " << Settings.mInput[1] << "]" << endl;
    }
}





