r2hess.binary <- if (WINDOWS) "mthess.exe" else "mthess"
if (!file.exists(r2hess.binary)) {
    message(sprintf("%s not found", r2hess.binary))
} else {
    bin.arch <- if (nzchar(R_ARCH)) paste0("bin", R_ARCH) else "bin"
    dest <- file.path(R_PACKAGE_DIR, bin.arch)
    message(sprintf("Installing %s to %s", r2hess.binary, dest))
    dir.create(dest, showWarnings=FALSE, recursive=TRUE)
    file.copy(r2hess.binary, dest, overwrite=TRUE)
}

