/* This file is part of ESS-OO.
 *      Copyright (c) Marc Chadeau-Hyam (m.chadeau@imperial.ac.uk)
 *                    Leonardo Bottolo (l.bottolo@imperial.ac.uk)
 *                    David Hastie (d.hastie@imperial.ac.uk)
 *      2014
 *
 * Software designed and restructured by Loizos Markides (lm1011@ic.ac.uk)
 * ESS-OO is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ESS-OO is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ESS-OO.  If not, see <http://www.gnu.org/licenses/>.
 */


#include <iostream>
#include <ctime>

#include "HESS/MCMCVector.h"
#include "UtilityClasses/Settings.hpp"
#include "UtilityClasses/inputRoutines.h"

GlobalSettings Settings;

void ESSOO(int argc, char *argv[]);
void HESSOO(int argc, char *argv[]);

int main(int argc, char *argv[])
{
    Settings.readProgramOptions(argc, argv);
    Settings.openOutputFiles();

    if (Settings.model == 0)
	ESSOO(argc, argv);

    else if (Settings.model == 1)
	HESSOO(argc, argv);

    return 0;
}

void HESSOO(int argc, char *argv[]){

    std::clock_t start = std::clock();
    std::clock_t totalStart = start;
    
    MCMCVector mcmcVector;

    mcmcVector.readData();
    mcmcVector.initialise(); 
    Settings.writeSettingsToLog();
   
    std::clock_t end = std::clock();
    double Setup_Time = (end - start) / (double) (CLOCKS_PER_SEC);
    clog << "Setup Time: " << Show_Time(Setup_Time) << endl << endl;
    start = std::clock();
    
    // MCMC Iterations
    mcmcVector.run();

    end = std::clock();
    double MCMCLoopTime = (end - start) / (double)(CLOCKS_PER_SEC);
    
    mcmcVector.writeFinalOutput();
    
    clog << endl << endl << "MCMC loop time: " << Show_Time(MCMCLoopTime) << endl;
    start = std::clock();
 
    //Postprocessing
    if (Settings.calcMPPI)
	mcmcVector.computeMPPI();
    
    // Output model posterior probabilities
    mcmcVector.outputPosterior();
    
#if _CUDA_
    stopCula();
#endif
    
    end = std::clock();
    double PostProcessTime = (end - start) / (double)(CLOCKS_PER_SEC);
    double Total_Time = (end - totalStart) / (double)(CLOCKS_PER_SEC);
    
    clog << "Total time: " << Show_Time(Total_Time) << endl << endl;
    clog << "Setup Time: " << Show_Time(Setup_Time) << endl;
    clog << "MCMC loop time: " << Show_Time(MCMCLoopTime) << endl;
    clog << "Post-process time: " << Show_Time(PostProcessTime) << endl << endl;
}


// ******************************************************************************

void ESSOO(int argc, char *  argv[]){

    // Clock handling to measure time of execution
    GlobalVariables::Time.begin = time(NULL);
    clock_t time_start = std::clock();
    clock_t tmpTime;
    double setupTime=0.0,mainLoopTime=0.0,postProcessTime=0.0;
    
    MCMC* mcmc = new MCMC();
    
    //Reads all arguments from the input files and initializes classes
    read_arguments(argc,argv,mcmc);
    
    //Get a fresh copy of matrix X
    //mcmc->readMatrixX();
    
    clock_t time_end = std::clock();
    tmpTime = time_start;
    setupTime = (time_end-tmpTime)/(double)(CLOCKS_PER_SEC);
    
    ///////////////////////////////////////
    //Start MCMC///////////////////////////
    ///////////////////////////////////////
    
    if(!Settings.postProcOnly)
    {
        mcmc->firstSweep();
        
        if(!Settings.resumeRun && !Settings.extendRun)
        {
            mcmc->print_main_results_per_sweep();
        }
    }
    
    ////////////////////////////////////
    //   START OF THE ITERATIVE
    //   ALGORITHM
    ////////////////////////////////////
    
    mcmc->initializeModelsVisited();
    
    if(!Settings.postProcOnly){
        /////////////////////////////////////
        // Outputing features of the run
        /////////////////////////////////////
        
        GlobalVariables::OutputFileStreams.f_out_features << "n\t" << mcmc->nX << endl;
        GlobalVariables::OutputFileStreams.f_out_features << "p\t" << mcmc->pX << endl;
        GlobalVariables::OutputFileStreams.f_out_features << "q\t" << mcmc->pY << endl;
        GlobalVariables::OutputFileStreams.f_out_features << "n_conf\t" << mcmc->nConfounders() << endl;
        GlobalVariables::OutputFileStreams.f_out_features << "nsweeps\t" << mcmc->n_sweeps() << endl;
        GlobalVariables::OutputFileStreams.f_out_features << "burn.in\t" << mcmc->burn_in() << endl;
        GlobalVariables::OutputFileStreams.f_out_features << "Egam\t" << Prior::E_p_gam << endl;
        GlobalVariables::OutputFileStreams.f_out_features << "Sgam\t" << Prior::Sd_p_gam << endl;
        GlobalVariables::OutputFileStreams.f_out_features << "top\t" << mcmc->n_top_models() << endl;
        GlobalVariables::OutputFileStreams.f_out_features << "nb.chain\t" << mcmc->n_chains() << endl;
        GlobalVariables::OutputFileStreams.f_out_features << "cuda\t" << GlobalVariables::GlobalFlags.cudaFlag << endl;
        GlobalVariables::OutputFileStreams.f_out_features << "history\t" << GlobalVariables::GlobalFlags.HistoryFlag << endl;
        GlobalVariables::OutputFileStreams.f_out_features << "time\t" << GlobalVariables::GlobalFlags.Time_monitorFlag << endl;
        GlobalVariables::OutputFileStreams.f_out_features << "med_RMSE\t" << sqrt(Prior::k) << endl;
        GlobalVariables::OutputFileStreams.f_out_features << "seed\t" << mcmc->seed() << endl;
        
        mcmc->run();
        
        tmpTime = time_end;
        time_end = std::clock();
        mainLoopTime = (time_end-tmpTime)/(double)(CLOCKS_PER_SEC);
    }
    
    //////////////////
    //Post-Processing
    //////////////////
    
    mcmc->runPostProcessing();
    
    GlobalVariables::GlobalFlags.run_finished=true;
    GlobalVariables::OutputFileStreams.f_out_features << "run_finished\t" << GlobalVariables::GlobalFlags.run_finished << endl;
    
    tmpTime = time_end;
    time_end = std::clock();
    postProcessTime = (time_end-tmpTime)/(double)(CLOCKS_PER_SEC);
    clog << "Setup Time: " << setupTime  << endl;
    if(!Settings.postProcOnly)
    {
        clog << "Main Loop Time: " << mainLoopTime  << endl;
    }
    clog << "Post Processing Time: " << postProcessTime  << endl;
    
    GlobalVariables::OutputFileStreams.f_out_marg_gam.close();
    GlobalVariables::OutputFileStreams.f_out_best_models.close();
    GlobalVariables::OutputFileStreams.f_out_features.close();
    
#if _CUDA_
    stopCula();
#endif
}
