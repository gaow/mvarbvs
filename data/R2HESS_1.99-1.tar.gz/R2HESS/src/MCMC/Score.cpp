/* This file is part of ESS-OO.
 *      Copyright (c) Marc Chadeau-Hyam (m.chadeau@imperial.ac.uk)
 *                    Leonardo Bottolo (l.bottolo@imperial.ac.uk)
 *                    David Hastie (d.hastie@imperial.ac.uk)
 *      2014
 *
 * Software designed and restructured by Loizos Markides (lm1011@ic.ac.uk)
 * ESS-OO is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ESS-OO is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ESS-OO.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "Score.h"
#include "../ScoreStrategies/AllScoreStrategyDefinitions.h"

using std::vector;

ScoreLikelihoodStrategy* Score::likelihoodStrategy_ = NULL;
ScorePenalizationStrategy* Score::penalizationStrategy_ = NULL;
double Score::lambda =-1.0;

Score::Score() {
    omega_k_=0.0;
    Rho_V_.resize(0);
}

Score::~Score() {
    // TODO Auto-generated destructor stub
}

void Score::initialize(GlobalSettings::LikelihoodTypeT lstrategy,
		       GlobalSettings::PenalisationTypeT pstrategy)
{
    setLikelihoodStrategy(lstrategy);
    setPenalizationStrategy(pstrategy);
}

void Score::setLikelihoodStrategy(int type)
{
    delete likelihoodStrategy_;
    if (type == GlobalSettings::Linear)
	likelihoodStrategy_= new LinearLikelihood();
    else if (type == GlobalSettings::GLM)
	likelihoodStrategy_= new GLMLikelihood();
    else if (type == GlobalSettings::Survival)
	likelihoodStrategy_= new SurvivalLikelihood();
}

void Score::setPenalizationStrategy(int type)
{
    delete penalizationStrategy_;
    if (type == GlobalSettings::wmegaFixed)
	penalizationStrategy_ = new wmegaFixedPenalization();
    else if (type == GlobalSettings::wmegaBetaBinomial)
	penalizationStrategy_ = new wmegaBetaBinomialPenalization();
    else if (type == GlobalSettings::wmegaBernoulli)
	penalizationStrategy_ = new wmegaBernoulliPenalization();
}


// TODO:
// We assume this is called only once, so there is no need to free the matrix. 
// We also assume that there is only one score object per chain, so no copy constructor
// is necessary (any copying, eg triggered by vector resizes, would keep the same underlying data)
void Score::setPY(unsigned int pY) {
    this->pY = pY;
    sgamma_ = gsl_matrix_alloc(pY, pY);
}

void Score::computeLogPosterior(double& logMargLik,
				double& logPosterior,
				vector<unsigned int> &list_vars_in,
				double g_,
				gsl_matrix* mat_Y,
				double &prior_k,
				unsigned int pX) {

    computeLogPosteriorSGamma(logMargLik, logPosterior, list_vars_in, g_, mat_Y, prior_k, pX, sgamma_, true);

}

void Score::computeLogPosteriorSGamma(double& logMargLik,
				double& logPosterior,
				vector<unsigned int> &list_vars_in,
				double g_,
				gsl_matrix* mat_Y,
				double &prior_k,
				unsigned int pX,
				gsl_matrix* sgamma,
				bool withSGamma) {

    if (withSGamma)
	logMargLik = likelihoodStrategy_->getMarginalLikelihoodSGamma(g_,list_vars_in, mat_Y, prior_k, sgamma);
    else
	logMargLik = likelihoodStrategy_->getMarginalLikelihood(g_,list_vars_in, mat_Y, prior_k);

    if(std::isnan(logMargLik)||std::isinf(logMargLik))
    {
	logMargLik=-1000000000;
    }

    double logPGam=getPriorGam(list_vars_in,pX);
    if(std::isnan(logPGam)||std::isinf(logPGam))
    {
	logPGam=-1000000000;
    }

    double logPG=getPriorG(g_);
    if(std::isnan(logPG)||std::isinf(logPG))
    {
	logPG=-1000000000;
    }

    //This is a placeholder. Currently returning 0.0
    double logPenalization=penalizationStrategy_->getPenalization();
    if(std::isnan(logPenalization)||std::isinf(logPenalization))
    {
	logPenalization=-1000000000;
    }

    logPosterior= logPGam + logPG + logMargLik + logPenalization;
}


double Score::invGammaPdf(double x,
			  double alpha,
			  double beta)
{
    double temp1 = alpha * log(beta) - gsl_sf_lngamma(alpha);
    double temp2 = -(alpha + 1) * log(x) -beta/x;
    double res=temp1 + temp2;

    return res;
}

void Score::Get_R2_Mat_GPriors(gsl_matrix * R2_Mat_GPriors,
			       vector <bool> &Gamma,
			       gsl_matrix * mat_X,
			       gsl_matrix * matY)
{

    unsigned int nX=mat_X->size1;
    unsigned int pY=matY->size2;

    // Count number of variables in
    vector < unsigned int > list_columns_X_gam;
    MatrixManipulation::get_list_var_in(list_columns_X_gam,Gamma);

    unsigned int pXGam=list_columns_X_gam.size();
    unsigned int nQ;

    nQ=nX;

    if(pXGam<nQ)
    {
        gsl_matrix *QSubTYTilde=gsl_matrix_alloc(nQ-pXGam,pY);

        if(pXGam==0)
        {
            gsl_matrix_memcpy(QSubTYTilde,matY);
        }
        else
        {
            // Build matXGam
            gsl_matrix *matXGam = MatrixManipulation::get_X_reduced(list_columns_X_gam,mat_X);

            //*******************************************************
            // QR decomposition calculations in the case of g-priors:
            //*******************************************************
#if _CUDA_
            if (!GlobalVariables::GlobalFlags.cudaFlag)
            {
#endif
		//NO GPU
                //clog << "NO GPU" << endl;
                MatrixManipulation::getQSubTYTilde(QSubTYTilde,matXGam,matY,matY);
#if _CUDA_
            }
            else
            {
		// WITH GPU
                //clog << "WITH GPU" << endl;
                float * matrixXGamTilde = (float*) malloc(nQ*pXGam*sizeof(float));
                float * matrixYTilde = (float*) malloc(nQ*pY*sizeof(float));

                for(unsigned int i=0;i<nQ;i++)
                {
		    for(unsigned int j=0;j<pXGam;j++)
		    {
			matrixXGamTilde[j*nQ+i]=gsl_matrix_get(matXGam,i,j);
		    }
		    for(unsigned int j=0;j<pY;j++){
			matrixYTilde[j*nQ+i]=gsl_matrix_get(matY,i,j);
		    }
                }

                getQSubTYTildeCula(QSubTYTilde,matrixXGamTilde,matrixYTilde,matY,nQ,pXGam);

                free(matrixXGamTilde);
                free(matrixYTilde);
            }
#endif
            gsl_matrix_free(matXGam);
        }

        // Least-squares
        // *************
        // This step stores in R2_Mat_GPriors the matrix of residues
        // from the least squares projection.

        gsl_blas_dgemm(CblasTrans,CblasNoTrans,1.0,QSubTYTilde,QSubTYTilde,0.0,R2_Mat_GPriors);

        gsl_matrix_free(QSubTYTilde);
    }
    else// Case pXGam>=nQ, ie not enough observations
    {
        gsl_matrix_set_all(R2_Mat_GPriors,0.0);
    }
}


double Score::getPriorG(double g_)
{
    double res=0.0;
    if(Settings.gSampleFlag)
    {
	res=invGammaPdf(g_,Prior::alpha,Prior::beta);
    }
    else
    {
	res=0.0;
    }

    return res;
}

double Score::update_omega_k(double new_omega_k,
			     vector<unsigned int> &listVarsIn,
			     unsigned int pX)
{
    //updates omega_k and returns priorgam difference to be added in the log_con_post
    double currentPriorGam = getPriorGam(listVarsIn,pX);
    omega_k_ = new_omega_k;
    double newPriorGam = getPriorGam(listVarsIn,pX);

    return (newPriorGam - currentPriorGam);
}

double Score::update_rho_j(vector<double> &Rho_j,
			   vector<unsigned int> &listVarsIn,
			   unsigned int pX)
{
    //updates omega_k and returns priorgam difference to be added in the log_con_post
    double currentPriorGam = getPriorGam(listVarsIn,pX);
    copy(Rho_j.begin(),Rho_j.end(),Rho_V_.begin());
    double newPriorGam = getPriorGam(listVarsIn,pX);

    return (newPriorGam - currentPriorGam);
}

void Score::set_omega_and_rho(double omega_k,vector<double> &Rho_V)
{
    omega_k_ = omega_k;
    copy(Rho_V.begin(),Rho_V.end(),Rho_V_.begin());
}

#if _CUDA_

void Score::computeLogPosterior(double& logMargLik,
				double& logPosterior,
				vector<unsigned int> &list_vars_in,
				double g_,
				gsl_matrix* mat_Y,
				double &prior_k,
				unsigned int pX,
				float* mat_Y_GPU)
{
    logMargLik = likelihoodStrategy_->getMarginalLikelihood(g_,list_vars_in, mat_Y, prior_k,mat_Y_GPU);
    if(std::isnan(logMargLik)||std::isinf(logMargLik))
    {
	logMargLik=-1000000000;
    }

    double logPGam=getPriorGam(list_vars_in,pX);
    if(std::isnan(logPGam)||std::isinf(logPGam))
    {
	logPGam=-1000000000;
    }

    double logPG=getPriorG(g_);
    if(std::isnan(logPG)||std::isinf(logPG))
    {
	logPG=-1000000000;
    }

    //This is a placeholder. Currently returning 0.0
    double logPenalization=penalizationStrategy_->getPenalization();
    if(std::isnan(logPenalization)||std::isinf(logPenalization))
    {
	logPenalization=-1000000000;
    }

    logPosterior= logPGam + logPG + logMargLik + logPenalization;
}


void Score::getQSubTYTildeCula(gsl_matrix * QSubTYTilde,
			       float *matrixXGamTilde,
			       float *matrixYTilde,
			       gsl_matrix *matY,
			       unsigned int nQ,
			       unsigned int pXGam)
{
    //clog << "Enter getTildeResidualsMatrix" << endl;

    unsigned int pY=matY->size2;
    //unsigned int nQ=matXGamTilde->size1;
    //unsigned int pXGam=matXGamTilde->size2;

    //QR decomposition
    float *tau=(float*) malloc(pXGam*sizeof(float));

    //DEBUG
    //clog << "DEBUG: Cula not activated" << endl;
    culaSgeqrf(nQ,pXGam,matrixXGamTilde,nQ,tau);

    culaSormqr('L','T',nQ,pY,pXGam,matrixXGamTilde,nQ,tau,matrixYTilde,nQ);
    //clog << "matrixXGamTilde[0] = " << matrixXGamTilde[0] << endl;
    //clog << "matrixYTilde[0] = " << matrixYTilde[0] << endl;

    //matrixYTilde is modified and stores actually matrixQTYTilde

    for(unsigned int i=pXGam;i<nQ;i++)
    {
    	for(unsigned int j=0;j<pY;j++)
    	{
	    gsl_matrix_set(QSubTYTilde,i-pXGam,j,matrixYTilde[j*nQ+i]);
    	}
    }

    free(tau);
}

#endif
