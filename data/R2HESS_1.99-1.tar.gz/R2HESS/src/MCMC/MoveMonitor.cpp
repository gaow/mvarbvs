/* This file is part of ESS-OO.
 *      Copyright (c) Marc Chadeau-Hyam (m.chadeau@imperial.ac.uk)
 *                    Leonardo Bottolo (l.bottolo@imperial.ac.uk)
 *                    David Hastie (d.hastie@imperial.ac.uk)
 *      2014
 *
 * Software designed and restructured by Loizos Markides (lm1011@ic.ac.uk)
 * ESS-OO is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ESS-OO is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ESS-OO.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "../UtilityClasses/Settings.hpp"
#include "MoveMonitor.h"

MoveMonitor::MoveMonitor() {
    // TODO Auto-generated constructor stub
}

MoveMonitor::~MoveMonitor() {
    // TODO Auto-generated destructor stub
}

void MoveMonitor::set(FSMHlog fsmh_new,
		      CrossoverLog cm_new,
		      DelayedRejectionLog dr_new,
		      AllExchangeLog ae_new,
		      AdaptiveMHLog amh_new,
		      GibbsLog gibbs_new,
		      TemperatureLog temper_new)
{
    fsmh = fsmh_new;
    cm = cm_new;
    dr = dr_new;
    ae = ae_new;
    amh = amh_new;
    gibbs = gibbs_new;
    temper = temper_new;
}

void MoveMonitor::display_move_monitor_full()
{
    clog << endl << "****************************************************************************************************" << endl
	 << "****************************************** Moves monitor *******************************************" << endl
	 << endl << "####################" << endl
	 << "  -Fast Scan M-H" << endl
	 << "####################" << endl
	 << "\tnb_sweep = " << fsmh.nb_sweep << endl
	 << "\tnb_model_tot = " << fsmh.nb_model_tot << endl
	 << "\tnb_accept = " << fsmh.nb_accept_tot << endl
	 << "\tnb_model_0_1 = " << fsmh.nb_model_0_1 << endl
	 << "\tnb_accept_0_1 = " << fsmh.nb_accept_0_1 << endl
	 << "\tnb_model_1_0 = " << fsmh.nb_model_1_0 << endl
	 << "\tnb_accept_1_0 = " << fsmh.nb_accept_1_0 << endl;
    if(fsmh.list_sweep.size()>0){
	clog << "\tFSMH Per-sweep, monitoring:" << endl
	     << "\tSweep\tn_mod\tn_accept\tn_mod_0_1\tn_accept_0_1\tn_mod_1_0\tn_accept_1_0" << endl;
	for(unsigned int col=0;col<fsmh.list_sweep.size();col++){
	    clog << "\t" << fsmh.list_sweep[col] << "\t"
		 << fsmh.nb_model_per_sweep[col] <<"\t"
		 << fsmh.nb_accept_per_sweep[col] <<"\t\t"
		 << fsmh.nb_model_per_sweep_0_1[col] <<"\t\t"
		 << fsmh.nb_accept_per_sweep_0_1[col] <<"\t\t"
		 << fsmh.nb_model_per_sweep_1_0[col] <<"\t\t"
		 << fsmh.nb_accept_per_sweep_1_0[col] << endl;
	}
    }

    clog << endl << "####################" << endl
	 << "  -CM Move" << endl
	 << "####################" << endl
	 << "\tnb_sweep = " << cm.nb_sweep << endl
	 << "\tnb_model = " << cm.nb_model << endl
	 << "\tnb_accept = " << cm.nb_accept << endl
	 << "\tCM_nb_sweep_per_CM_move" << endl
	 << "\t";
    for(unsigned int col=0;col<cm.n_nb_sweep_per_CM_move.size();col++){
	clog << cm.n_nb_sweep_per_CM_move[col] << " ";
    }
    clog << endl;
    clog << "\tCM_nb_accept_per_CM_move" << endl
	 << "\t";
    for(unsigned int col=0;col<cm.n_nb_accept_per_CM_move.size();col++){
	clog << cm.n_nb_accept_per_CM_move[col] << " ";
    }
    clog << endl;
    if(cm.history[0].size()>0){
	clog << "\tCM per-sweep monitoring:" << endl;
	clog << "\tSweep\ttype\t#Bkpoints\tchain1\tchain2" << endl;
	for(unsigned int col=0;col<cm.history[0].size();col++){
	    clog << "\t" << cm.history[0][col]
		 << "\t" << cm.history[1][col]
		 << "\t" << cm.history[2][col]
		 << "\t" << cm.history[3][col]
		 << "\t" << cm.history[4][col]
		 << endl;
	}
    }

    clog << endl << "####################" << endl
	 << "  -All Exchange" << endl
	 << "####################" << endl
	 << "\tnb_sweep = " << ae.nb_sweep << endl
	 << "\tnb_accept = " << ae.n_accept << endl
	 << "\tVect Freq:" << endl;
    clog << "\t";
    for(unsigned int col=0;col<ae.freq.size();col++){
	clog << ae.freq[col] << "\t";
    }
    clog << endl;
    if(ae.move_history[0].size()>0){
	clog << "\tAll exchange per-sweep monitoring:" << endl;
	clog << "\tSweep\tChain_i\tChain_f" << endl;
	for(unsigned int col=0;col<ae.move_history[0].size();col++){
	    clog << "\t" << ae.move_history[0][col]
		 << "\t" << ae.move_history[1][col]
		 << "\t" << ae.move_history[2][col] << endl;
	}
    }
    clog << endl << "####################" << endl
	 << "  -DR Move" << endl
	 << "####################" << endl
	 << "\tnb_sweep = " << dr.nb_sweep << endl
	 << "\tnb_accept = " << dr.n_accept << endl
	 << "\tVect Freq:" << endl;
    clog << "\t";
    for(unsigned int col=0;col<dr.freq.size();col++){
	clog << dr.freq[col] << "\t";
    }
    clog << endl;
    if(dr.move_history[0].size()>0){
	clog << "\tDR per-sweep monitoring:" << endl;
	clog << "\tSweep\tChain_i\tChain_f" << endl;
	for(unsigned int col=0;col<dr.move_history[0].size();col++){
	    clog << "\t" << dr.move_history[0][col]
		 << "\t" << dr.move_history[1][col]
		 << "\t" << dr.move_history[2][col] << endl;
	}
    }
    clog << endl << "####################" << endl
	 << "  -g Sample" << endl
	 << "####################" << endl
	 << "\tnb_sweep = " << amh.nb_sweep << endl
	 << "\tnb_accept = " << amh.nb_accept << endl;
    if(amh.sample_history.size()>0){
	clog << "\tHistory:" << endl;
	clog << "\t";
	for(unsigned int col=0;col<amh.sample_history.size();col++){
	    clog << amh.sample_history[col] << "\t";
	}
	clog << endl;
    }
    if(amh.adapt_history[0].size()>0){
	clog << endl
	     << "\tg_adapt History:" << endl;
	clog << "\tSweep\t%accept\tls\tls_new" << endl;
	for(unsigned int row=0;row<amh.adapt_history[0].size();row++){
	    clog << "\t" << amh.adapt_history[0][row]
		 << "\t" << amh.adapt_history[1][row]
		 << "\t" << amh.adapt_history[2][row]
		 << "\t" << amh.adapt_history[3][row] << endl;
	}
    }

    clog << endl << "####################" << endl
	 << "  -Gibbs Move" << endl
	 << "####################" << endl
	 << "\tnb_sweep = " << gibbs.nb_sweep << endl
	 << "\tnb_model = " << gibbs.nb_model << endl
	 << "\tnb_0_1 moves = " << gibbs.nb_0_1 << endl
	 << "\tnb_1_0 moves = " << gibbs.nb_1_0 << endl;
    if(gibbs.move_history[0].size()>0){
	clog << "\tGibbs per-sweep monitoring:" << endl;
	clog << "\tSweep\tn_0_1\tn_1_0\tn_unchanged" << endl;
	for(unsigned int col=0;col<gibbs.move_history[0].size();col++){
	    clog << "\t" << gibbs.move_history[0][col]
		 << "\t" << gibbs.move_history[1][col]
		 << "\t" << gibbs.move_history[2][col]
		 << "\t" << gibbs.move_history[3][col] << endl;
	}
    }

    clog << endl << "####################" << endl
	 << "  -Temperatures" << endl
	 << "####################" << endl;

    clog << "\tSweep ";
    for(unsigned int chain=1;chain<temper.history.size();chain++){
	clog << "\tchain # " << chain;
    }
    clog << endl;
    for(unsigned int sweep=0;sweep<temper.history[0].size();sweep++){
	for(unsigned int row=0;row<temper.history.size();row++){
	    clog <<"\t " << temper.history[row][sweep];
	}
	clog << endl;
    }

    clog << endl << "####################" << endl << endl;

    clog << "****************************************************************************************************" << endl
	 << "****************************************************************************************************" << endl << endl;

}

void MoveMonitor::display_move_monitor()
{
    clog << endl << "****************************************************************************************************" << endl
	 << "****************************************** Moves monitor *******************************************" << endl
	 << endl << "####################" << endl
	 << "  -Fast Scan M-H" << endl
	 << "####################" << endl
	 << "\tnb_sweep = " << fsmh.nb_sweep << endl
	 << "\tnb_model_tot = " << fsmh.nb_model_tot << endl
	 << "\tnb_accept = " << fsmh.nb_accept_tot << endl
	 << "\tnb_model_0_1 = " << fsmh.nb_model_0_1 << endl
	 << "\tnb_accept_0_1 = " << fsmh.nb_accept_0_1 << endl
	 << "\tnb_model_1_0 = " << fsmh.nb_model_1_0 << endl
	 << "\tnb_accept_1_0 = " << fsmh.nb_accept_1_0 << endl;

    clog << endl << "####################" << endl
	 << "  -CM Move" << endl
	 << "####################" << endl
	 << "\tnb_sweep = " << cm.nb_sweep << endl
	 << "\tnb_model = " << cm.nb_model << endl
	 << "\tnb_accept = " << cm.nb_accept << endl
	 << "\tCM_nb_sweep_per_CM_move" << endl
	 << "\t";
    for(unsigned int col=0;col<cm.n_nb_sweep_per_CM_move.size();col++){
	clog << cm.n_nb_sweep_per_CM_move[col] << " ";
    }
    clog << endl;
    clog << "\tCM_nb_accept_per_CM_move" << endl
	 << "\t";
    for(unsigned int col=0;col<cm.n_nb_accept_per_CM_move.size();col++){
	clog << cm.n_nb_accept_per_CM_move[col] << " ";
    }
    clog << endl;

    clog << endl << "####################" << endl
	 << "  -All Exchange" << endl
	 << "####################" << endl
	 << "\tnb_sweep = " << ae.nb_sweep << endl
	 << "\tnb_accept = " << ae.n_accept << endl
	 << "\tVect Freq:" << endl;
    clog << "\t";
    for(unsigned int col=0;col<ae.freq.size();col++){
	clog << ae.freq[col] << "\t";
    }
    clog << endl;
    clog << endl << "####################" << endl
	 << "  -DR Move" << endl
	 << "####################" << endl
	 << "\tnb_sweep = " << dr.nb_sweep << endl
	 << "\tnb_accept = " << dr.n_accept << endl
	 << "\tVect Freq:" << endl;
    clog << "\t";
    for(unsigned int col=0;col<dr.freq.size();col++){
	clog << dr.freq[col] << "\t";
    }
    clog << endl;
    clog << endl << "####################" << endl
	 << "  -g Sample" << endl
	 << "####################" << endl
	 << "\tnb_sweep = " << amh.nb_sweep << endl
	 << "\tnb_accept = " << amh.nb_accept << endl;

    clog << endl << "####################" << endl
	 << "  -Gibbs Move" << endl
	 << "####################" << endl
	 << "\tnb_sweep = " << gibbs.nb_sweep << endl
	 << "\tnb_model = " << gibbs.nb_model << endl
	 << "\tnb_0_1 moves = " << gibbs.nb_0_1 << endl
	 << "\tnb_1_0 moves = " << gibbs.nb_1_0 << endl;

    clog << "****************************************************************************************************" << endl
	 << "****************************************************************************************************" << endl << endl;
}

void MoveMonitor::print_move_monitor_full(unsigned int g_sample)
{
    GlobalVariables::OutputFileStreams.f_out_FSMH << "Sweep\tn_mod\tn_accept\tn_mod_0_1\tn_accept_0_1\tn_mod_1_0\tn_accept_1_0" << endl;
    if(fsmh.list_sweep.size()>0){
	for(unsigned int col=0;col<fsmh.list_sweep.size();col++){
	    GlobalVariables::OutputFileStreams.f_out_FSMH << fsmh.list_sweep[col] << "\t"
							  << fsmh.nb_model_per_sweep[col] <<"\t"
							  << fsmh.nb_accept_per_sweep[col] <<"\t"
							  << fsmh.nb_model_per_sweep_0_1[col] <<"\t"
							  << fsmh.nb_accept_per_sweep_0_1[col] <<"\t"
							  << fsmh.nb_model_per_sweep_1_0[col] <<"\t"
							  << fsmh.nb_accept_per_sweep_1_0[col] << endl;
	}
    }

    GlobalVariables::OutputFileStreams.f_out_CM << "Sweep\tMove_type\t#Breakpoints\tChain_l\tChain_r" << endl;
    if(cm.history[0].size()>0){
	for(unsigned int col=0;col<cm.history[0].size();col++){
	    GlobalVariables::OutputFileStreams.f_out_CM << cm.history[0][col]
							<< "\t" << cm.history[1][col]+1
							<< "\t" << cm.history[2][col]
							<< "\t" << cm.history[3][col]+1
							<< "\t" << cm.history[4][col]+1
							<< endl;
	}
    }

    GlobalVariables::OutputFileStreams.f_out_AE << "Sweep\tChain_l\tChain_r" << endl;
    if(ae.move_history[0].size()>0){
	for(unsigned int col=0;col<ae.move_history[0].size();col++){
	    GlobalVariables::OutputFileStreams.f_out_AE << ae.move_history[0][col]
							<< "\t" << ae.move_history[1][col]+1
							<< "\t" << ae.move_history[2][col]+1 << endl;
	}
    }

    GlobalVariables::OutputFileStreams.f_out_DR << "Sweep\tChain_l\tChain_r" << endl;

    if(dr.move_history[0].size()>0){
	for(unsigned int col=0;col<dr.move_history[0].size();col++){
	    GlobalVariables::OutputFileStreams.f_out_DR << dr.move_history[0][col]
							<< "\t" << dr.move_history[1][col]+1
							<< "\t" << dr.move_history[2][col]+1 << endl;
	}
    }
    if(g_sample!=0){
	GlobalVariables::OutputFileStreams.f_out_g << "Sweep\tg" << endl;
	if(amh.sample_history.size()>0){
	    for(unsigned int col=0;col<amh.sample_history.size();col++){
		GlobalVariables::OutputFileStreams.f_out_g << col+1 << "\t"
							   << amh.sample_history[col] << endl;
	    }
	    GlobalVariables::OutputFileStreams.f_out_g << endl;
	}
	GlobalVariables::OutputFileStreams.f_out_g_adapt << "Sweep\tAcceptance_rate\tlog_proposal_std" << endl;
	if(amh.adapt_history[0].size()>0){
	    for(unsigned int row=0;row<amh.adapt_history[0].size();row++){
		GlobalVariables::OutputFileStreams.f_out_g_adapt << amh.adapt_history[0][row]
								 << "\t" << amh.adapt_history[1][row]
								 << "\t" << amh.adapt_history[3][row] << endl;
	    }
	}
    }
    GlobalVariables::OutputFileStreams.f_out_Gibbs << "Sweep\tn_0->1\tn_1->0" << endl;
    if(gibbs.move_history[0].size()>0){
	for(unsigned int col=0;col<gibbs.move_history[0].size();col++){
	    GlobalVariables::OutputFileStreams.f_out_Gibbs << gibbs.move_history[0][col]
							   << "\t" << gibbs.move_history[1][col]
							   << "\t" << gibbs.move_history[2][col] << endl;
	}
    }
    if(!Settings.noTemperature){
	GlobalVariables::OutputFileStreams.f_out_t_tun << "Sweep\t";
	for(unsigned int chain=1;chain<temper.history.size();chain++){
	    GlobalVariables::OutputFileStreams.f_out_t_tun << "Chain_" << chain << "\t";
	}
	GlobalVariables::OutputFileStreams.f_out_t_tun << endl;
	if(temper.history[0].size()>0){
	    for(unsigned int sweep=0;sweep<temper.history[0].size();sweep++){
		GlobalVariables::OutputFileStreams.f_out_t_tun << temper.history[0][sweep] << "\t";
		for(unsigned int row=1;row<temper.history.size();row++){
		    GlobalVariables::OutputFileStreams.f_out_t_tun << temper.history[row][sweep] << "\t";
		}
		GlobalVariables::OutputFileStreams.f_out_t_tun << endl;
	    }
	}
    }
}

void MoveMonitor::print_move_monitor_per_sweep_to_file(unsigned int sweep,
						       unsigned int nChains)
{

    unsigned int lastSweep=0;
    unsigned int col=0;
    unsigned int row=0;

    if(sweep==1){
	GlobalVariables::OutputFileStreams.f_out_FSMH << "Sweep\tn_mod\tn_accept\tn_mod_0_1\tn_accept_0_1\tn_mod_1_0\tn_accept_1_0" << endl;
    }
    lastSweep=fsmh.list_sweep.size();
    col=lastSweep-1;
    if(lastSweep>0){
	if(fsmh.list_sweep[col]==sweep){
	    GlobalVariables::OutputFileStreams.f_out_FSMH << fsmh.list_sweep[col] << "\t"
							  << fsmh.nb_model_per_sweep[col] <<"\t"
							  << fsmh.nb_accept_per_sweep[col] <<"\t"
							  << fsmh.nb_model_per_sweep_0_1[col] <<"\t"
							  << fsmh.nb_accept_per_sweep_0_1[col] <<"\t"
							  << fsmh.nb_model_per_sweep_1_0[col] <<"\t"
							  << fsmh.nb_accept_per_sweep_1_0[col] << endl;
	}
    }

    if(sweep==1){
	GlobalVariables::OutputFileStreams.f_out_CM << "Sweep\tMove_type\tnBreakpoints\tChain_l\tChain_r" << endl;
    }
    lastSweep=cm.history[0].size();
    col=lastSweep-1;
    if(lastSweep>0){
	if(cm.history[0][col]==sweep){
	    GlobalVariables::OutputFileStreams.f_out_CM << cm.history[0][col]
							<< "\t" << cm.history[1][col]+1
							<< "\t" << cm.history[2][col]
							<< "\t" << cm.history[3][col]+1
							<< "\t" << cm.history[4][col]+1
							<< endl;
	}
    }

    if(sweep==1){
	GlobalVariables::OutputFileStreams.f_out_AE << "Sweep\tChain_l\tChain_r" << endl;
    }
    lastSweep=ae.move_history[0].size();
    col=lastSweep-1;
    if(lastSweep>0){
	if(ae.move_history[0][col]==sweep){
	    GlobalVariables::OutputFileStreams.f_out_AE << ae.move_history[0][col]
							<< "\t" << ae.move_history[1][col]+1
							<< "\t" << ae.move_history[2][col]+1 << endl;
	}
    }

    if(sweep==1){
	GlobalVariables::OutputFileStreams.f_out_DR << "Sweep\tChain_l\tChain_r" << endl;
    }
    lastSweep=dr.move_history[0].size();
    col=lastSweep-1;
    if(lastSweep>0){
	if(dr.move_history[0][col]==sweep){
	    GlobalVariables::OutputFileStreams.f_out_DR << dr.move_history[0][col]
							<< "\t" << dr.move_history[1][col]+1
							<< "\t" << dr.move_history[2][col]+1 << endl;
	}
    }

    if(Settings.gSampleFlag){
	if(sweep==1){
	    GlobalVariables::OutputFileStreams.f_out_g << "Sweep\tg" << endl;
	}
	lastSweep=amh.sample_history.size();
	col=lastSweep-1;
	GlobalVariables::OutputFileStreams.f_out_g << sweep << "\t"
						   << amh.sample_history[col] << endl;

	if(sweep==1){
	    GlobalVariables::OutputFileStreams.f_out_g_adapt << "Sweep\tAcceptance_rate\tlog_proposal_std" << endl;
	}
	lastSweep=amh.adapt_history[0].size();
	row=lastSweep-1;
	if(lastSweep>0){
	    if(amh.adapt_history[0][row]==sweep){
		GlobalVariables::OutputFileStreams.f_out_g_adapt << amh.adapt_history[0][row]
								 << "\t" << amh.adapt_history[1][row]
								 << "\t" << amh.adapt_history[3][row] << endl;
	    }
	}
    }

    if(sweep==1){
	GlobalVariables::OutputFileStreams.f_out_Gibbs << "Sweep\tn_0->1\tn_1->0" << endl;
    }
    lastSweep=gibbs.move_history[0].size();
    col=lastSweep-1;
    if(lastSweep>0){
	if(gibbs.move_history[0][col]==sweep){
	    GlobalVariables::OutputFileStreams.f_out_Gibbs << gibbs.move_history[0][col]
							   << "\t" << gibbs.move_history[1][col]
							   << "\t" << gibbs.move_history[2][col] << endl;
	}
    }
    if(!Settings.noTemperature){
	if(sweep==1){
	    GlobalVariables::OutputFileStreams.f_out_t_tun << "Sweep\t";
	    for(unsigned int chain=1;chain<=nChains;chain++){
		GlobalVariables::OutputFileStreams.f_out_t_tun << "Chain_" << chain << "\t";
	    }
	    GlobalVariables::OutputFileStreams.f_out_t_tun << endl;
	}
	lastSweep=temper.history[0].size();
	col=lastSweep-1;
	if(lastSweep>0){
	    if(temper.history[0][col]==sweep){
		GlobalVariables::OutputFileStreams.f_out_t_tun << temper.history[0][col] << "\t";
		for(unsigned int row=1;row<=nChains;row++){
		    GlobalVariables::OutputFileStreams.f_out_t_tun << temper.history[row][col] << "\t";
		}
		GlobalVariables::OutputFileStreams.f_out_t_tun << endl;
	    }
	}
    }
}

void MoveMonitor::print_move_monitor_per_sweep_to_string(unsigned int sweep,
							 unsigned int nChains)
{
    unsigned int lastSweep=0;
    unsigned int col=0;
    unsigned int row=0;

    if(sweep==1){
	GlobalVariables::OutputStringStreams.strStrOutFSMH << "Sweep\tn_mod\tn_accept\tn_mod_0_1\tn_accept_0_1\tn_mod_1_0\tn_accept_1_0" << endl;
    }
    lastSweep=fsmh.list_sweep.size();
    col=lastSweep-1;
    if(lastSweep>0){
	if(fsmh.list_sweep[col]==sweep){
	    GlobalVariables::OutputStringStreams.strStrOutFSMH << fsmh.list_sweep[col] << "\t"
							       << fsmh.nb_model_per_sweep[col] <<"\t"
							       << fsmh.nb_accept_per_sweep[col] <<"\t"
							       << fsmh.nb_model_per_sweep_0_1[col] <<"\t"
							       << fsmh.nb_accept_per_sweep_0_1[col] <<"\t"
							       << fsmh.nb_model_per_sweep_1_0[col] <<"\t"
							       << fsmh.nb_accept_per_sweep_1_0[col] << endl;

	}
    }

    if(sweep==1){
	GlobalVariables::OutputStringStreams.strStrOutCM << "Sweep\tMove_type\tnBreakpoints\tChain_l\tChain_r" << endl;
    }
    lastSweep=cm.history[0].size();
    col=lastSweep-1;
    if(lastSweep>0){
	if(cm.history[0][col]==sweep){
	    GlobalVariables::OutputStringStreams.strStrOutCM << cm.history[0][col]
							     << "\t" << cm.history[1][col]+1
							     << "\t" << cm.history[2][col]
							     << "\t" << cm.history[3][col]+1
							     << "\t" << cm.history[4][col]+1
							     << endl;
	}
    }

    if(sweep==1){
	GlobalVariables::OutputStringStreams.strStrOutAE << "Sweep\tChain_l\tChain_r" << endl;
    }
    lastSweep=ae.move_history[0].size();
    col=lastSweep-1;
    if(lastSweep>0){
	if(ae.move_history[0][col]==sweep){
	    GlobalVariables::OutputStringStreams.strStrOutAE << ae.move_history[0][col]
							     << "\t" << ae.move_history[1][col]+1
							     << "\t" << ae.move_history[2][col]+1 << endl;
	}
    }

    if(sweep==1){
	GlobalVariables::OutputStringStreams.strStrOutDR << "Sweep\tChain_l\tChain_r" << endl;
    }
    lastSweep=dr.move_history[0].size();
    col=lastSweep-1;
    if(lastSweep>0){
	if(dr.move_history[0][col]==sweep){
	    GlobalVariables::OutputStringStreams.strStrOutDR << dr.move_history[0][col]
							     << "\t" << dr.move_history[1][col]+1
							     << "\t" << dr.move_history[2][col]+1 << endl;
	}
    }

    if(Settings.gSampleFlag){
	if(sweep==1){
	    GlobalVariables::OutputStringStreams.strStrOutG << "Sweep\tg" << endl;
	}
	lastSweep=amh.sample_history.size();
	col=lastSweep-1;
	GlobalVariables::OutputStringStreams.strStrOutG << sweep << "\t"
							<< amh.sample_history[col] << endl;

	if(sweep==1){
	    GlobalVariables::OutputStringStreams.strStrOutGAdapt << "Sweep\tAcceptance_rate\tlog_proposal_std" << endl;
	}
	lastSweep=amh.adapt_history[0].size();
	row=lastSweep-1;
	if(lastSweep>0){
	    if(amh.adapt_history[0][row]==sweep){
		GlobalVariables::OutputStringStreams.strStrOutGAdapt << amh.adapt_history[0][row]
								     << "\t" << amh.adapt_history[1][row]
								     << "\t" << amh.adapt_history[3][row] << endl;
	    }
	}
    }

    if(sweep==1){
	GlobalVariables::OutputStringStreams.strStrOutGibbs << "Sweep\tn_0->1\tn_1->0" << endl;
    }
    lastSweep=gibbs.move_history[0].size();
    col=lastSweep-1;
    if(lastSweep>0){
	if(gibbs.move_history[0][col]==sweep){
	    GlobalVariables::OutputStringStreams.strStrOutGibbs << gibbs.move_history[0][col]
								<< "\t" << gibbs.move_history[1][col]
								<< "\t" << gibbs.move_history[2][col] << endl;
	}
    }
    if(!Settings.noTemperature){
	if(sweep==1){
	    GlobalVariables::OutputStringStreams.strStrOutTTun << "Sweep\t";
	    for(unsigned int chain=1;chain<=nChains;chain++){
		GlobalVariables::OutputStringStreams.strStrOutTTun << "Chain_" << chain << "\t";
	    }
	    GlobalVariables::OutputStringStreams.strStrOutTTun << endl;
	}
	lastSweep=temper.history[0].size();
	col=lastSweep-1;
	if(lastSweep>0){
	    if(temper.history[0][col]==sweep){
		GlobalVariables::OutputStringStreams.strStrOutTTun << temper.history[0][col] << "\t";
		for(unsigned int row=1;row<=nChains;row++){
		    GlobalVariables::OutputStringStreams.strStrOutTTun << temper.history[row][col] << "\t";
		}
		GlobalVariables::OutputStringStreams.strStrOutTTun << endl;
	    }
	}
    }
}
