/* This file is part of ESS-OO.
 *      Copyright (c) Marc Chadeau-Hyam (m.chadeau@imperial.ac.uk)
 *                    Leonardo Bottolo (l.bottolo@imperial.ac.uk)
 *                    David Hastie (d.hastie@imperial.ac.uk)
 *      2014
 *
 * Software designed and restructured by Loizos Markides (lm1011@ic.ac.uk)
 * ESS-OO is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ESS-OO is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ESS-OO.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef SCORE_H_
#define SCORE_H_

#include "../UtilityClasses/Settings.hpp"
#include "Definitions.h"
#include "../ScoreStrategies/ScoreLikelihoodStrategy.h"
#include "../ScoreStrategies/ScorePenalizationStrategy.h"

class Score {
public:
    Score();
    virtual ~Score();

    // Abstract because this is an abstract class
    virtual Score *clone() = 0;

    static double lambda;

    //Initialization and static functions
    static void initialize(GlobalSettings::LikelihoodTypeT lstrategy,
    			   GlobalSettings::PenalisationTypeT pstrategy);
    static void setLikelihoodStrategy(int type);
    static void setPenalizationStrategy(int type);

    static double invGammaPdf(double x,
			      double alpha,
			      double beta);
    static void Get_R2_Mat_GPriors(gsl_matrix * R2_Mat_GPriors,
				   std::vector <bool> &Gamma,
				   gsl_matrix * mat_X,
				   gsl_matrix * matY);

    void setPY(unsigned int pY);

    void set_omega_and_rho(double omega_k,std::vector<double> &Rho_V);

    void computeLogPosterior(double& logMargLik,
			     double& logPosterior,
			     std::vector<unsigned int> &list_vars_in,
			     double g,
			     gsl_matrix* mat_Y,
			     double &prior_k,
			     unsigned int pX);

    void computeLogPosteriorSGamma(double& logMargLik,
			     double& logPosterior,
			     std::vector<unsigned int> &list_vars_in,
			     double g,
			     gsl_matrix* mat_Y,
			     double &prior_k,
			     unsigned int pX,
			     gsl_matrix* sgamma,
			     bool withSGamma=true);

    //pure abstract method. Should be implemented by inherited classes
    virtual double getPriorGam(std::vector<unsigned int> &listVarsIn,
			       unsigned int pX)=0;

    double getPriorG(double g_);

    virtual double update_omega_k(double new_omega_k,
				  std::vector<unsigned int> &listVarsIn,
				  unsigned int pX);
    virtual double update_rho_j(std::vector<double> &Rho_j,
				std::vector<unsigned int> &listVarsIn,
				unsigned int pX);
    //only used in HESS
    double omega_k_;
    std::vector<double> Rho_V_;
    
    gsl_matrix* sgamma_;
    gsl_matrix* sgamma() { return sgamma_; }
    unsigned int pY;

#if _CUDA_
    void computeLogPosterior(double& logMargLik,
			     double& logPosterior,
			     std::vector<unsigned int> &list_vars_in,
			     double g_,
			     gsl_matrix* mat_Y,
			     double &prior_k,
			     unsigned int pX,
			     float* mat_Y_GPU);
#endif

#if _CUDA_
    static void getQSubTYTildeCula(gsl_matrix * QSubTYTilde,
				   float *matrixXGamTilde,
				   float *matrixYTilde,
				   gsl_matrix *matY,
				   unsigned int nQ,
				   unsigned int pXGam);
#endif

protected:
    static ScoreLikelihoodStrategy* likelihoodStrategy_;
    static ScorePenalizationStrategy* penalizationStrategy_;
};

#endif /* SCORE_H_ */
