/* This file is part of ESS-OO.
 *      Copyright (c) Marc Chadeau-Hyam (m.chadeau@imperial.ac.uk)
 *                    Leonardo Bottolo (l.bottolo@imperial.ac.uk)
 *                    David Hastie (d.hastie@imperial.ac.uk)
 *      2014
 *
 * Software designed and restructured by Loizos Markides (lm1011@ic.ac.uk)
 * ESS-OO is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ESS-OO is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ESS-OO.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef MOVEMONITOR_H_
#define MOVEMONITOR_H_
#include <algorithm>
#include <fstream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <cstddef>
#include <iostream>
#include <sstream>
#include <string>
#include "Definitions.h"
#include "../UtilityClasses/GlobalVariables.h"

class MoveMonitor {
public:

    MoveMonitor();
    virtual ~MoveMonitor();

    void set(FSMHlog fsmh_new,
	     CrossoverLog cm_new,
	     DelayedRejectionLog dr_new,
	     AllExchangeLog ae_new,
	     AdaptiveMHLog amh_new,
	     GibbsLog gibbs_new,
	     TemperatureLog temper_new);
    
    void display_move_monitor_full();
    void display_move_monitor();
    void print_move_monitor_full(unsigned int g_sample);
    
    void print_move_monitor_per_sweep_to_file(unsigned int sweep,
					      unsigned int nChains);
    
    void print_move_monitor_per_sweep_to_string(unsigned int sweep,
						unsigned int nChains);
    
private:
    FSMHlog fsmh;
    CrossoverLog cm;
    DelayedRejectionLog dr;
    AllExchangeLog ae;
    AdaptiveMHLog amh;
    GibbsLog gibbs;
    TemperatureLog temper;
};

#endif /* MOVEMONITOR_H_ */
