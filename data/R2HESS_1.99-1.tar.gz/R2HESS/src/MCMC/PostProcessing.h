/* This file is part of ESS-OO.
 *      Copyright (c) Marc Chadeau-Hyam (m.chadeau@imperial.ac.uk)
 *                    Leonardo Bottolo (l.bottolo@imperial.ac.uk)
 *                    David Hastie (d.hastie@imperial.ac.uk)
 *      2014
 *
 * Software designed and restructured by Loizos Markides (lm1011@ic.ac.uk)
 * ESS-OO is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ESS-OO is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ESS-OO.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef POSTPROCESSING_H_
#define POSTPROCESSING_H_

#include <iostream>
#include <sstream>
#include <fstream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <stdlib.h>
#include <stddef.h>
#include <stdarg.h>
#include <string.h>
#include <stdio.h>
#include "../UtilityClasses/GlobalVariables.h"
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_math.h>
#include <gsl/gsl_permutation.h>
#include <gsl/gsl_blas.h>
#include <vector>
#include "MCMC.h"

class PostProcessing {
public:
    PostProcessing();
    virtual ~PostProcessing();

    static int getUniqueList(std::vector<std::vector<unsigned int> > &uniqueListModels,
			     const std::vector<std::vector<unsigned int> >& listModels,
			     const std::vector<unsigned int>& n_modelsVisited,
			     const unsigned int& burnIn,
			     const unsigned int& pX,
			     const unsigned int& nConfounders);

    static void getLogPost(std::vector<std::vector<double> >& margLogPostVec,
			   std::vector<std::vector<unsigned int> >& uniquelistModels,
			   double gMean,
			   gsl_matrix* mat_Y,
			   float *mat_Y_GPU,
			   double& prior_k);

    static void getAndSortPostGam(gsl_vector* postGamVec,
				  gsl_permutation* idxPostGamSort,
				  const std::vector<std::vector<double> >& margLogPostVec);

    static void combineAndPrintBestModel(gsl_permutation* const idxPostGamSort,
					 gsl_vector* const postGamVec,
					 const std::vector<std::vector<double> >& margLogPostVec,
					 const std::vector<std::vector<unsigned int> >& uniqueListModels,
					 const unsigned int& nRetainedModels,
					 const unsigned int& posNullModel,
					 const unsigned int& nConfounders);

    static void getAndPrintMargGam(
	const std::vector<std::vector<unsigned int> >& uniqueListModels,
	gsl_vector* const postGamVec,
	const unsigned int& pX,
	const unsigned int& nConfounders);
};

#endif /* POSTPROCESSING_H_ */
