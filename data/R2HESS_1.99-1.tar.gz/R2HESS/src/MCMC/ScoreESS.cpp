/* This file is part of ESS-OO.
 *      Copyright (c) Marc Chadeau-Hyam (m.chadeau@imperial.ac.uk)
 *                    Leonardo Bottolo (l.bottolo@imperial.ac.uk)
 *                    David Hastie (d.hastie@imperial.ac.uk)
 *      2014
 *
 * Software designed and restructured by Loizos Markides (lm1011@ic.ac.uk)
 * ESS-OO is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ESS-OO is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ESS-OO.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "ScoreESS.h"
#include <stdlib.h>

#if _CUDA_
#include <cuda.h>
#include <cuda_runtime_api.h>
#include <cublas.h>
#include <cula.h>
#endif

using namespace std;

ScoreESS::ScoreESS() {
    // TODO Auto-generated constructor stub
}

ScoreESS::~ScoreESS() {
    // TODO Auto-generated destructor stub
}

ScoreESS *ScoreESS::clone() {
    return new ScoreESS(*this);
}

double ScoreESS::getPriorGam(vector<unsigned int> &Gamma,
			     unsigned int pX)
{
    unsigned int pXGam = Gamma.size();
    
    double temp1=gsl_sf_lngamma(Prior::a_pi+(double)(pXGam));
    double temp2=gsl_sf_lngamma((double)(pX)+Prior::b_pi-(double)(pXGam));
    double temp3=gsl_sf_lngamma((double)(pX)+Prior::b_pi+Prior::a_pi);
    double res=temp1 + temp2 - temp3;
    
    return res;
}

