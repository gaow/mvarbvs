/* This file is part of ESS-OO.
 *      Copyright (c) Marc Chadeau-Hyam (m.chadeau@imperial.ac.uk)
 *                    Leonardo Bottolo (l.bottolo@imperial.ac.uk)
 *                    David Hastie (d.hastie@imperial.ac.uk)
 *      2014
 *
 * Software designed and restructured by Loizos Markides (lm1011@ic.ac.uk)
 * ESS-OO is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ESS-OO is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ESS-OO.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "MCMC.h"
#include <numeric>
#include "../UtilityClasses/Settings.hpp"

using std::vector;

#if _CUDA_
#else
double timestamp ()
{
    struct timeval tv;
    gettimeofday (&tv, 0);
    return tv.tv_sec + 1e-6*tv.tv_usec;
}
#endif

// #define DEBUG 1

gsl_matrix* MCMC::mat_X = NULL;
char* MCMC::filename_in_mat_X_ = NULL;
char* MCMC::filename_in_mat_Y_ = NULL;
gsl_rng* MCMC::RandomNumberGenerator = NULL;
unsigned int MCMC::nX=0;
unsigned int MCMC::pX=0;
unsigned int MCMC::burn_in_=0;

#if _CUDA_
float *MCMC::mat_X_GPU = NULL;
float *MCMC::Data_X_CPU = NULL;
#endif

MCMC::MCMC() {
#if _CUDA_
    mat_Y_GPU = NULL;
    Data_Y_CPU = NULL;
#endif

    k_prior_=0.0;
    nY=0;
    pY=0;
    mat_Y = NULL;
    resumeSweep_=0;
    nExtSweeps_ = 0;
    n_top_models_=0;
    seed_=0;
    nConfounders_=0;
    maxPX_=0;
    n_chains_=0;
    n_sweeps_=0;
    Gibbs_n_batch_=0;
    sweep_ = 0;
    cum_g_=0.0;
    count_g_=0;
    g_=0.0;
    timeLimit_ = -1;

    MyPerm_ = NULL;

    allexchangemove_ = new AllExchange();
    delayedrejectionmove_ = new DelayedRejection();
    crossovermove_ = new Crossover();
    temperaturetuning_ = new TemperatureTuning();
    adaptivemh_ = new AdaptiveMH();
    mcmcMoveMonitor_ = new MoveMonitor();
    vect_RMSE_ = NULL;

    if (Settings.moveLog) {
	fsmhlog_.nb_model_tot=0;
	fsmhlog_.nb_sweep=0;
	fsmhlog_.nb_model_0_1=0;
	fsmhlog_.nb_model_1_0=0;
	fsmhlog_.nb_accept_tot=0;
	fsmhlog_.nb_accept_0_1=0;
	fsmhlog_.nb_accept_1_0=0;
	
	gibbslog_.nb_sweep=0;
	gibbslog_.nb_model=0;
	gibbslog_.nb_0_1=0;
	gibbslog_.nb_1_0=0;
	gibbslog_.move_history.resize(4);
    }
}

MCMC::~MCMC() {
    // TODO Delete references
    //gsl_matrix_free(mat_X);

    gsl_matrix_free(mat_Y);
    gsl_permutation_free(MyPerm_);
    chain_idx_.clear();
    n_Models_visited_.clear();
    gsl_vector_free(vect_RMSE_);
    shuffleYIndex_.clear();

    delete allexchangemove_;
    delete delayedrejectionmove_;
    delete crossovermove_;
    delete temperaturetuning_;
    delete adaptivemh_;
    delete mcmcMoveMonitor_;

#if _CUDA_
    if (GlobalVariables::GlobalFlags.cudaFlag)  {
	clog << "Freeing GPU memory... " << endl;
	cudaFree(mat_X_GPU);
    }
    if (GlobalVariables::GlobalFlags.cudaFlag)  {
	clog << "Freeing GPU memory... " << endl;
	cudaFree(mat_Y_GPU);
    }
#endif
}

//Initialisation functions

int MCMC::initializeRandomNumberGenerator(int MY_SEED)
{
    MCMC::RandomNumberGenerator = gsl_rng_alloc( gsl_rng_mt19937 );
    if(MY_SEED<0)
    {
	MY_SEED=(long)time(0);
    }
    gsl_rng_set(MCMC::RandomNumberGenerator, (long)(MY_SEED));
    return MY_SEED;
}

void MCMC::setCumulativeG(double cumg, unsigned int countg)
{
    cum_g_=cumg;
    count_g_ = countg;
}

void MCMC::initialize_g(double g_init)
{
    if(!(Settings.resumeRun || Settings.extendRun))
    {
	if(!Settings.gSampleFlag)
	{
	    g_=g_init;
	}
	else
	{
	    g_=pow((double)(pX),2);
	}
    }
}

void MCMC::initializeFromRead(unsigned int n_sweeps,
			      unsigned int burn_in,
			      unsigned int n_top_models_from_read,
			      unsigned int nConfounders,
			      unsigned int nExtSweeps,
			      unsigned int nb_chains,
			      unsigned int Gibbs_n_batch,
			      unsigned int maxPX,
			      double g_init,
			      double timeLimit,
			      int MY_SEED)
{
    Gibbs_n_batch_ = Gibbs_n_batch;
    maxPX_=maxPX;
    n_chains_ = nb_chains;
    n_sweeps_ = n_sweeps;
    burn_in_ = burn_in;
    n_top_models_ = n_top_models_from_read;
    nConfounders_ = nConfounders;
    nExtSweeps_ = nExtSweeps;
    seed_ = MY_SEED;
    timeLimit_=timeLimit;
    initialize_g(g_init);
    delayedrejectionmove_->set(n_chains_);
    allexchangemove_->set(n_chains_);
    initializeChains();
    initializeModelsVisited();
}

void MCMC::createChainsfromRegression()
{
    vector < vector <unsigned int> > Gam_step_regr;
    Gam_step_regr.resize(pY);
    unsigned int maxPGamma = maxPX_;
    vect_RMSE_ = gsl_vector_calloc(pY);
    // memory allocation for matrices and vector variables

    Matrix<double> Gam_step_regr_pvals;
    Gam_step_regr_pvals.allocate(pY,pX);

    Matrix<double> Gam_step_regr_SE;
    Gam_step_regr_SE.allocate(pY,pX);

    Matrix<double> Gam_step_regr_beta;
    Gam_step_regr_beta.allocate(pY,pX);

    double tolerance= 6.6835e-14;

    gsl_vector *current_outcome =gsl_vector_calloc(nX);
    gsl_vector *vect_residuals=gsl_vector_calloc(nX);
    gsl_vector *vect_p_value=gsl_vector_calloc(pX);
    gsl_vector *vect_beta_full=gsl_vector_calloc(pX);
    gsl_vector *vect_SE_full=gsl_vector_calloc(pX);

    for(unsigned int outcome=0;outcome<pY;outcome++)
    {
	// for each outcome in matrix Y

	vector < unsigned int > list_columns_X_gam;
	vector < unsigned int > list_columns_X_gam_bar;
	vector < bool > is_var_in;

	is_var_in.resize(pX);

	for(unsigned int jj=0;jj<nConfounders_;jj++)
	{
	    // Set up so confounders are always in
	    is_var_in[jj]=1;
	}

	gsl_matrix_get_col(current_outcome,
			   mat_Y,
			   outcome);

	int stop=0;
	int loop=0;
	int n_loop_max=100;

	//real regression loop
	while(stop==0)
	{
	    //create a gamma vector with the current var_in variables
	    MatrixManipulation::get_list_var_in_and_out(list_columns_X_gam,
							list_columns_X_gam_bar,
							is_var_in);

	    //Splitting X in two parts in the following two calls:
	    // getting only the var_in columns of X
	    gsl_matrix *mat_X_gam=get_X_reduced_and_constant(list_columns_X_gam);

	    // getting the rest of columns of X
	    gsl_matrix *mat_X_gam_bar= MatrixManipulation::get_X_reduced(list_columns_X_gam_bar,MCMC::mat_X);

	    //Calculating p-values for all variables
	    Regression::get_full_pvalues_and_beta(vect_p_value,
						  vect_beta_full,
						  vect_SE_full, //standard errors
						  mat_X_gam,
						  mat_X_gam_bar,
						  current_outcome, //current Y
						  vect_residuals,
						  vect_RMSE_, // if resuming
						  tolerance, // constant
						  list_columns_X_gam,
						  list_columns_X_gam_bar,
						  outcome);

	    //Updating the list of var in
	    stop = Regression::update_is_var_in(is_var_in, //selection of X columns
						list_columns_X_gam,
						list_columns_X_gam_bar,
						vect_p_value,
						loop,
						n_loop_max,
						nConfounders_);
	    gsl_matrix_free(mat_X_gam);
	    gsl_matrix_free(mat_X_gam_bar);

	    ++loop;
	    list_columns_X_gam.clear();
	    list_columns_X_gam_bar.clear();

	    if(stop==1)
	    {
		MatrixManipulation::get_list_var_in_and_out(list_columns_X_gam,
							    list_columns_X_gam_bar,
							    is_var_in);
	    }
	}//end of while (Initial Regression)

	//Filling the output file for the regression for each outcome of Y
	Regression::store_model_per_outcome(Gam_step_regr,
					    list_columns_X_gam,
					    vect_p_value,
					    vect_beta_full,
					    vect_SE_full,
					    Gam_step_regr_pvals,
					    Gam_step_regr_SE,
					    Gam_step_regr_beta,
					    outcome);

	list_columns_X_gam.clear();
	is_var_in.clear();
    }// end of regression for each outcome in matrix Y

    //clog << "Result From Step-Wise Regression" << endl;
    // CCS
    //MatrixManipulation::display_matrix_var_dim(Gam_step_regr);

    unsigned int n_vars_in=0;
    if(!Settings.noTemperature)
    {
	for(unsigned int chain=0;chain<n_chains_;chain++)
	{
	    // Vector to hold gammas of each chain
	    vector<bool> vect_gam;
	    vect_gam.resize(pX);

	    for(unsigned int row=0;row<Gam_step_regr.size();row++)
	    {
		for(unsigned int col=0;col<Gam_step_regr[row].size();col++)
		{
		    unsigned int temp_pos=Gam_step_regr[row][col];
		    vect_gam[temp_pos]=1;
		    if(chain==0)
		    {
			n_vars_in++;
		    }
		}
	    }

	    addChain(vect_gam);
	    vect_gam.clear();
	}
    }
    else
    {
	unsigned int *source_list= new unsigned int [pX];
	vector<bool> vect_gam;
	vect_gam.resize(pX);

	for(unsigned int row=0;row<Gam_step_regr.size();row++)
	{
	    for(unsigned int col=0;col<Gam_step_regr[row].size();col++)
	    {
		unsigned int temp_pos=Gam_step_regr[row][col];
		vect_gam[temp_pos]=1;
		n_vars_in++;
		source_list[temp_pos]=temp_pos;
	    }
	}

	addChain(vect_gam);
	vect_gam.clear();

	//Filling the other chains randomly
	//Case 1: No vars in: sample one var for chains #2 to C
	if(n_vars_in==0)
	{
	    for(unsigned int chain=1;chain<pX;chain++)
	    {
		unsigned int *list_sample = new unsigned int [1];
		gsl_ran_choose(MCMC::RandomNumberGenerator,
			       list_sample,
			       1,
			       source_list,
			       chainsVector_[0].getCurrentGammaVectorSize(),
			       sizeof(unsigned int));

		unsigned int curr_pos=list_sample[0];
		vect_gam[curr_pos]=1;
		addChain(vect_gam);
		vect_gam.clear();
		delete [] list_sample;
	    }
	}
	else
	{
	    //if n_vars_in>0: sample n_vars in for each chain #2 to C
	    for(unsigned int chain=1;chain<n_chains_;chain++)
	    {
		unsigned int *list_sample = new unsigned int [n_vars_in];
		gsl_ran_choose(MCMC::RandomNumberGenerator,
			       list_sample,
			       n_vars_in,
			       source_list,
			       chainsVector_[0].getCurrentGammaVectorSize(),
			       sizeof(unsigned int));

		for(unsigned int curr_var=0;curr_var<n_vars_in;curr_var++)
		{
		    unsigned int curr_pos=list_sample[curr_var];
		    vect_gam[curr_pos]=1;
		}
		addChain(vect_gam);
		vect_gam.clear();
		delete [] list_sample;
	    }
	}

	delete [] source_list;
    }

    // Now check that there are not too many variables in and if so,
    // randomly remove some
    if(n_vars_in>maxPGamma)
    {
	unsigned int *toRemove = new unsigned int[n_vars_in-maxPGamma];
	unsigned int *varIn = new unsigned int[n_vars_in];
	for(unsigned int i=0;i<n_vars_in;i++)
	{
	    varIn[i]=i;
	}

	gsl_ran_choose(MCMC::RandomNumberGenerator,
		       toRemove,
		       n_vars_in-maxPGamma,
		       varIn,
		       n_vars_in,
		       sizeof(unsigned int));

	for(unsigned int chain=0;chain<n_chains_;chain++)
	{
	    chainsVector_[chain].reduceGammaVector(toRemove);
	}

	delete [] varIn;
	delete [] toRemove;
    }
    // clearing memory
    gsl_vector_free(vect_residuals);
    gsl_vector_free(current_outcome);
    gsl_vector_free(vect_p_value);
    gsl_vector_free(vect_beta_full);
    gsl_vector_free(vect_SE_full);

    Gam_step_regr.clear();
    Gam_step_regr_pvals.free();
    Gam_step_regr_SE.free();
    Gam_step_regr_beta.free();
}


void MCMC::createChainsfromSimple() {

    // For multivariate Y, we perform simple regression against each Y in turn
    // The variable X goes into the initial model if the p-value is below a threshold
    // for any one outcome/tissue Y
    
    gsl_vector *currOutcome = gsl_vector_calloc(nX);
    gsl_vector *currVar = gsl_vector_calloc(nX);
    vect_RMSE_ = gsl_vector_calloc(pY);
    
    vector<vector<double> > pValues(MCMC::pX);
    for (int j = 0; j < pValues.size(); j++)
	pValues[j].resize(pY);

    for (unsigned int m = 0; m < pY; m++) {
	double rmse = 0;
	for(unsigned int j = nConfounders_; j < MCMC::pX; j++) {
	    // Regression: Output vector ~ SNP vector
	    gsl_matrix_get_col(currVar, MCMC::mat_X, j);
	    gsl_matrix_get_col(currOutcome, mat_Y, m);
	    
	    double c0, c1, cov00, cov01, cov11, sumsq;
	    gsl_fit_linear(currVar->data, 1, currOutcome->data, 1, nX, &c0, &c1, &cov00, &cov01, &cov11, &sumsq);
	    
	    // Standard error of the slope
	    cov11 = sqrt(cov11);
	    double tscore = fabs(c1 / cov11);
	    pValues[j][m] = 2 * (1 - gsl_cdf_tdist_P(tscore, nX-2));

	    if (std::isnan(pValues[j][m]))
		pValues[j][m] = 1;

	    rmse += sumsq;
	}
	rmse = sqrt(rmse / ( pX * pY));
	gsl_vector_set(vect_RMSE_, m, rmse);
    }

    vector<bool> model(MCMC::pX);

    // Threshold and select model
    double threshold = 0.05/MCMC::pX;
    int modelCount = 0;
    for (unsigned int j = 0; j < nConfounders_; j++) {
	// Confounders are always in the model
	model[j] = true;
	modelCount++;
    }
    for (unsigned int j = nConfounders_; j < MCMC::pX; j++) {
	bool inModel = true;
	for (unsigned int m = 0; m < pY; m++) {
	    // Only include a variable when it is below the threshold for all outcomes
	    if (pValues[j][m] >= threshold) {
		inModel = false;
		break;
	    }
	}
	if (inModel) {
	    model[j] = true;
	    modelCount++;
	}
    }

    // Add model to chains
    for (unsigned int chain = 0; chain < n_chains_; chain++) {
	addChain(model);
    }

    gsl_vector_free(currOutcome);
    gsl_vector_free(currVar);
}


void MCMC::createChainsfromFixed()
{
    vect_RMSE_ = gsl_vector_calloc(pY);
    vector<unsigned int>initGam;
    //Reading File

    unsigned int initSize;
    Settings.initGammaFile >> initSize;
    initGam.resize(initSize);

    for(unsigned int i=0;i<initSize;i++)
    {
	Settings.initGammaFile >> initGam[i];
    }
    Settings.initGammaFile.close();

    clog << "********************************************************" << endl
	 << "***************** Initial indices entered **************" << endl;

    for(unsigned int j=0;j<initGam.size();j++)
    {
	clog << initGam[j] << " ";
    }
    clog << endl;
    clog << "********************************************************" << endl
	 << "********************************************************" << endl;

    // Need to get the RMSE for prior estimate of k
    MatrixManipulation::standardize_matrix_gsl(MCMC::mat_X);
    gsl_vector *current_outcome =gsl_vector_calloc(MCMC::nX);

    vector < unsigned int > list_columns_X_gam;
    vector < bool > is_var_in(MCMC::pX);

    unsigned int k=0;

    for(unsigned int j=0;j<MCMC::pX;j++)
    {
	// Set up so confounders are always in
	if(j<nConfounders_)
	{
	    is_var_in[j]=1;
	}
	else if(j==initGam[k])
	{
	    ++k;
	    is_var_in[j]=1;
	}
	else
	{
	    is_var_in[j]=0;
	}
    }

    MatrixManipulation::get_list_var_in(list_columns_X_gam,is_var_in);

    gsl_matrix* mat_X_gam=get_X_reduced_and_constant(list_columns_X_gam);

    double tolerance= 6.6835e-14;

    for(unsigned int outcome=0;outcome<MCMC::pY;outcome++)
    {
	// get root mean squared error (RMSE) for each outcome
	gsl_matrix_get_col(current_outcome,MCMC::mat_Y,outcome);
	Regression::getEstimateRMSE(mat_X_gam,
				    current_outcome,
				    outcome,
				    vect_RMSE_,
				    tolerance);
    }

    gsl_matrix_free(mat_X_gam);
    gsl_vector_free(current_outcome);

    // Creating Chains

    for(unsigned int chain=0;chain<n_chains_;chain++)
    {
	vector<bool> vect_gam;
	vect_gam.resize(pX);
	unsigned int k=0;
	for(unsigned int j=0;j<pX;j++)
	{
	    if(j<nConfounders_)
	    {
		vect_gam[j]=1;
	    }
	    else if(j==initGam[k])
	    {
		++k;
		vect_gam[j]=1;
	    }
	    else
	    {
		vect_gam[j]=0;
	    }
	}
	addChain(vect_gam);
	vect_gam.clear();
    }
}

void MCMC::createChainsfromResume()
{
    vector<vector<unsigned int> > resumeDRAccepted;
    vector<vector<unsigned int> > resumeDRProposed;
    vector<vector<unsigned int> > resumeGam;
    vector<unsigned int> resumeChainIndex;
    vector<double> resumeT;

    double resumeCountG;
    double resumeCumG;
    double resumeBT;
    double resumeLS;
    unsigned int resumeDRNCalls;
    unsigned int resumeDRNCallsAdj;
    vect_RMSE_ = gsl_vector_calloc(pY);

    double resumeG;
    std::fstream f_resume;
    f_resume.open(GlobalVariables::InputOutputFileNames.resume.c_str(),std::ios::in);
    // Get the current sweep
    f_resume >> resumeSweep_;
    f_resume >> resumeG;
    FILE *f_rng;
    f_rng=fopen(GlobalVariables::InputOutputFileNames.rng.c_str(),"rb");
    // Need to read in the state of random number generator from file
    gsl_rng_fread(f_rng,MCMC::RandomNumberGenerator);
    fclose(f_rng);

    if(Settings.postProcOnly)
    {
	if(resumeSweep_ < burn_in_)
	{
	    clog << "Post processing cannot be applied because current number of sweeps less than burn in -- stopping run" << endl;
#if _CUDA_
	    stopCula();
#endif
	    exit(-1);
	}
    }

    if(Settings.resumeRun || Settings.extendRun)
    {
	g_=resumeG;
    }

    // Read the last state in from file
    f_resume >> resumeCumG;
    f_resume >> resumeCountG;
    setCumulativeG(resumeCumG,resumeCountG);

    for(unsigned int j=0;j<pY;j++)
    {
	f_resume >> vect_RMSE_->data[j];
    }
    resumeT.resize(n_chains_);
    for(unsigned int j=0;j<n_chains_;j++)
    {
	f_resume >> resumeT[j];
    }
    f_resume >> resumeBT;
    f_resume >> resumeLS;
    resumeDRAccepted.resize(n_chains_);
    resumeDRProposed.resize(n_chains_);
    f_resume >> resumeDRNCalls;
    f_resume >> resumeDRNCallsAdj;

    for(unsigned int j=0;j<n_chains_;j++)
    {
	resumeDRProposed[j].resize(n_chains_);
	for(unsigned int k=0;k<n_chains_;k++)
	{
	    f_resume >> resumeDRProposed[j][k];
	}
    }

    for(unsigned int j=0;j<n_chains_;j++)
    {
	resumeDRAccepted[j].resize(n_chains_);
	for(unsigned int k=0;k<n_chains_;k++)
	{
	    f_resume >> resumeDRAccepted[j][k];
	}
    }

    resumeGam.resize(n_chains_);
    resumeChainIndex.resize(n_chains_);
    for(unsigned int j=0;j<n_chains_;j++)
    {
	unsigned int gamSize;
	f_resume >> gamSize;
	f_resume >> resumeChainIndex[j];
	resumeGam[resumeChainIndex[j]].resize(gamSize);

	for(unsigned int k=0;k<gamSize;k++)
	{
	    f_resume >> resumeGam[resumeChainIndex[j]][k];
	}
    }

    if(Settings.resumeRun || Settings.extendRun)
    {
	sweep_ = resumeSweep_;
	for(unsigned int c=0;c<n_chains_;c++)
	{
	    chain_idx_[c]=resumeChainIndex[c];
	}
    }

    f_resume.close();

    for(unsigned int chain=0;chain<n_chains_;chain++)
    {
	vector<bool> vect_gam;
	vect_gam.resize(pX);
	unsigned int k=0;
	for(unsigned int j=0;j<pX;j++)
	{
	    if(resumeGam[chain].size()>0)
	    {
		if(j<nConfounders_)
		{
		    vect_gam[j]=1;
		}
		else if(j==resumeGam[chain][k])
		{
		    ++k;
		    vect_gam[j]=1;
		}
		else
		{
		    vect_gam[j]=0;
		}
	    }
	    else
	    {
		if(j<nConfounders_)
		{
		    vect_gam[j]=1;
		}
		else
		{
		    vect_gam[j]=0;
		}
	    }
	}
	addChain(vect_gam);
	vect_gam.clear();
    }

    // setting up resume parameters for global moves
    if(Settings.resumeRun || Settings.extendRun)
    {
	adaptivemh_->ls=resumeLS;
    }

    initializeDelayedRejection(resumeDRNCalls,
			       resumeDRNCallsAdj,
			       resumeDRAccepted,
			       resumeDRProposed);

    if(Settings.resumeRun || Settings.extendRun)
    {
	for(unsigned int j=0;j<n_chains_;j++)
	{
	    chainsVector_[chain_idx_[j]].setCurrentTemperature(resumeT[j]);
	}
	temperaturetuning_->b_t=resumeBT;
    }
}

//Move Functions

void MCMC::firstSweep()
{

    for(unsigned int chain=0;chain<n_chains_;chain++)
    {
	scoreUpdating(chain_idx_[chain]);

	
	//clog << endl << "**************Results, chain " << chain << " -- sweep " << sweep_ << "***************" << endl;
	//clog << endl << "Results, chain " << chain << " -- sweep " << sweep_ << endl;
	//clog << "\tlog_marg " << chainsVector_[chain_idx_[chain]].getLogMarginalForSweep(sweep_) << endl
	//     << "\tlog_cond_post " << chainsVector_[chain_idx_[chain]].getLogCondPostForSweep(sweep_) << endl;
	//clog << "********************************************************" << endl;
	
	chainsVector_[chain_idx_[chain]].gammaPropCount.resize(pX);
	chainsVector_[chain_idx_[chain]].gammaPropAddCount.resize(pX);
    }

    //clog << "***************************************" << endl
    //	 << "          END OF FIRST SWEEP" << endl
    //	 <<  "***************************************" << endl << endl;

    //update log of move monitor object
    if (Settings.moveLog)
	mcmcMoveMonitor_->set(fsmhlog_,
			      crossovermove_->log_,
			      delayedrejectionmove_->log_,
			      allexchangemove_->log_,
			      adaptivemh_->log_,
			      gibbslog_,
			      temperaturetuning_->log_);

    // Calculate correlation, init-ed to large value for min calculations
    vector<double> correlation(pX, 1e100);
    // Set correlation of confounders to be 1. This way, they will stay at the front of the sorted vector
    for (unsigned int j = 0; j < nConfounders_; j++)
	correlation[j] = 1;

    for (unsigned int j = nConfounders_; j < pX; j++) {
	// There is no easy way to extract matrix columns, and in any case would
	// require copying all the elements

	// Pointer arithmetic to get the start of the j-th column. (Note: gsl_matrix is row-major)
	double *xcol = mat_X->data + j;
	for (int m = 0; m < pY; m++) {
	    // Pointer to start of m-th column of Y.
	    double *ycol = mat_Y->data + m;
	    
	    // For multiple Y, use the min correlation value
	    // The stride is the number of elements per row. This way, we stepping down the 
	    // columns of each matrix.
	    correlation[j] = std::min(correlation[j], pow(gsl_stats_correlation(xcol, pX, ycol, pY, nX), 2));
	}
    }

    // Populate vector with ints 0, ..., n-1
    vector<unsigned> corrSortedInd(pX);
    iota(corrSortedInd.begin(), corrSortedInd.end(), 0);

    // Sort the indices, using a lambda function to sort based on correlation
    // Stable_sort guarantees that the order of equal elements is preserved (for any confounders)
    std::stable_sort(corrSortedInd.begin(), corrSortedInd.end(), 
    	      [&correlation](size_t el1, size_t el2) { return correlation[el1] > correlation[el2]; } );

    corrList.assign(corrSortedInd.begin(), corrSortedInd.end());
}


void MCMC::print_main_results_per_sweep()
{
    unsigned int pos_chain=chain_idx_[0];
    unsigned int n_vars_in=chainsVector_[pos_chain].getVariablesIncluded();

    GlobalVariables::OutputFileStreams.f_out << sweep_ << "\t"<< n_vars_in << "\t";
    GlobalVariables::OutputFileStreams.f_out << std::setprecision(13) << chainsVector_[pos_chain].getLogMarginalForSweep(sweep_) << "\t";
    GlobalVariables::OutputFileStreams.f_out << std::setprecision(13) << chainsVector_[pos_chain].getLogCondPostForSweep(sweep_) << "\t\t";

    vector<bool> currentVec =  chainsVector_[pos_chain].getGammaVector();

    for(unsigned int var=0;var<pX;var++)
    {
	if(currentVec[var]==1)
	{
	    GlobalVariables::OutputFileStreams.f_out << var+1 << " ";
	}
    }

    currentVec.clear();

    GlobalVariables::OutputFileStreams.f_out << endl;
}

void MCMC::Gibbs_move()
{
    unsigned int pos_current_chain=chain_idx_[0];
    unsigned int count_0_1=0;
    unsigned int count_1_0=0;
    unsigned int count_unchanged=0;
    if (Settings.moveLog) {
	gibbslog_.nb_sweep++;
	gibbslog_.move_history[0].push_back(sweep_);
    }

#if _CUDA_
    
#else
    float *mat_Y_GPU = NULL;
#endif 
	
#if DEBUG  
    //double ts = timestamp();  
#endif	
	
    chainsVector_[pos_current_chain].Gibbs(nConfounders_,
						  maxPX_,
						  count_0_1,
						  count_1_0,
						  count_unchanged,
						  g_,
						  MyPerm_,
						  MCMC::RandomNumberGenerator,
						  mat_Y,
						  mat_Y_GPU,
						  k_prior_);

#if DEBUG	  
    //double mid = timestamp() - ts;
#endif
	
#if DEBUG	
    //clog << "Gibbs time: " << mid << " seconds" << endl; 
#endif
	
    if (Settings.moveLog) {
	gibbslog_.nb_0_1+=count_0_1;
	gibbslog_.nb_1_0+=count_1_0;
	gibbslog_.move_history[1].push_back(count_0_1);
	gibbslog_.move_history[2].push_back(count_1_0);
	gibbslog_.move_history[3].push_back(count_unchanged);
    }
    n_Models_visited_[sweep_]+=pX;
}

void MCMC::covar_gamma_move() {
    for(unsigned int current_chain=0;current_chain<n_chains_;current_chain++)
    {
	unsigned int pos_current_chain=chain_idx_[current_chain];

	if (Settings.verbose)
	    clog << "Chain " << pos_current_chain << ": ";
	
	chainsVector_[pos_current_chain].HESS_prop(g_, MCMC::RandomNumberGenerator, mat_Y, k_prior_, corrList);
    }
}

void MCMC::writeGammaProp() {
    
    for (unsigned snp = 0; snp < pX; snp++) {
	int sum = 0;
	int addSum = 0;

	for (unsigned currChain = 0; currChain < n_chains_; currChain++) {
	    sum += chainsVector_[currChain].gammaPropCount[snp];
	    addSum += chainsVector_[currChain].gammaPropAddCount[snp];
	}
	
	Settings.out.gammaProp << sum << " ";
	Settings.out.gammaPropAdd << addSum << " ";
    }
    Settings.out.gammaProp << endl;
    Settings.out.gammaPropAdd << endl;

    long addAccept = 0;
    long addTotal = 0;
    long delAccept = 0;
    long delTotal = 0;
    long swapAccept = 0;
    long swapTotal = 0;

    for (unsigned currChain = 0; currChain < n_chains_; currChain++) {
	addAccept += chainsVector_[currChain].addAccept;
	addTotal += chainsVector_[currChain].addTotal;
	delAccept += chainsVector_[currChain].delAccept;
	delTotal += chainsVector_[currChain].delTotal;
	swapAccept += chainsVector_[currChain].swapAccept;
	swapTotal += chainsVector_[currChain].swapTotal;
    }
}

void MCMC::updateAvgAcceptance(unsigned long *acceptCount, unsigned long *rejectCount) {
    for (unsigned currChain = 0; currChain < n_chains_; currChain++) {
	*acceptCount += chainsVector_[currChain].acceptCount;
	*rejectCount += chainsVector_[currChain].rejectCount;
    }
}

void MCMC::FSMH_move()
{

#if _CUDA_

#else
    float *mat_Y_GPU = NULL;
#endif 

    unsigned int count_nb_model=0;
    unsigned int count_nb_accept=0;

    unsigned int count_nb_model_01=0;
    unsigned int count_nb_accept_01=0;

    unsigned int count_nb_model_10=0;
    unsigned int count_nb_accept_10=0;

    for(unsigned int current_chain=0;current_chain<n_chains_;current_chain++)
    {
	unsigned int pos_current_chain=chain_idx_[current_chain];
#if DEBUG  
	//double ts = timestamp();  
#endif	
	unsigned int currentModels = chainsVector_[pos_current_chain].FSMH(nConfounders_,
										  maxPX_,
										  count_nb_model_01,
										  count_nb_accept_01,
										  count_nb_model_10,
										  count_nb_accept_10,
										  g_,
										  MyPerm_,
										  MCMC::RandomNumberGenerator,
										  mat_Y,
										  mat_Y_GPU,
										  k_prior_);
		
			
#if DEBUG	  
	//double mid = timestamp() - ts;
	//clog << "FSMH time: " << mid << " seconds" << endl; 
#endif

	n_Models_visited_[sweep_]+=currentModels;
    }//end of for chain

    count_nb_model=count_nb_model_01+count_nb_model_10;
    count_nb_accept=count_nb_accept_01+count_nb_accept_10;
    //Storing summary in monitor
    if (Settings.moveLog) {
	fsmhlog_.nb_sweep++;
	fsmhlog_.nb_model_tot+=count_nb_model;
	fsmhlog_.nb_model_0_1+=count_nb_model_01;
	fsmhlog_.nb_model_1_0+=count_nb_model_10;
	fsmhlog_.nb_accept_tot+=count_nb_accept;
	fsmhlog_.nb_accept_0_1+=count_nb_accept_01;
	fsmhlog_.nb_accept_1_0+=count_nb_accept_10;
	
	fsmhlog_.list_sweep.push_back(sweep_);
	fsmhlog_.nb_model_per_sweep.push_back(count_nb_model);
	fsmhlog_.nb_model_per_sweep_0_1.push_back(count_nb_model_01);
	fsmhlog_.nb_model_per_sweep_1_0.push_back(count_nb_model_10);
	fsmhlog_.nb_accept_per_sweep.push_back(count_nb_accept);
	fsmhlog_.nb_accept_per_sweep_0_1.push_back(count_nb_accept_01);
	fsmhlog_.nb_accept_per_sweep_1_0.push_back(count_nb_accept_10);
    }
    
    if (Settings.outFlags.fsmhAccept) {
	Settings.fsmhAcceptLine[2*yIndex] = count_nb_model;
	Settings.fsmhAcceptLine[2*yIndex + 1] = count_nb_accept;
    }
}

void MCMC::initializeModelsVisited()
{
    if(Settings.postProcOnly)
    {
	n_Models_visited_.assign(resumeSweep_+1,0);
    }
    else
    {
	n_Models_visited_.assign(n_sweeps_+1,0);
    }

    if(Settings.resumeRun||Settings.postProcOnly||Settings.extendRun)
    {
	past_models_.resize(resumeSweep_+1);
	pastNModelsVisited_.assign(resumeSweep_+1,0);

	// Remove the first line
	std::string strtmp;
	for(unsigned int i=0;i<5;i++)
	{
	    GlobalVariables::InputFileStreams.f_in >> strtmp;
	}

	for(unsigned int i=0;i<resumeSweep_+1;i++)
	{
	    unsigned int tmp,modelSize;
	    double tmp1;
	    GlobalVariables::InputFileStreams.f_in >> tmp;
	    GlobalVariables::InputFileStreams.f_in >> modelSize;
	    GlobalVariables::InputFileStreams.f_in >> tmp1;
	    GlobalVariables::InputFileStreams.f_in >> tmp1;
	    past_models_[i].resize(modelSize+1);
	    past_models_[i][0]=modelSize;

	    for(unsigned int j=0;j<modelSize;j++)
	    {
		GlobalVariables::InputFileStreams.f_in >> tmp;
		past_models_[i][j+1]=tmp-1;
	    }
	}

	GlobalVariables::InputFileStreams.f_in_n_models_visited >> strtmp;
	GlobalVariables::InputFileStreams.f_in_n_models_visited >> strtmp;
	for(unsigned int i=1;i<resumeSweep_+1;i++)
	{
	    unsigned int tmp;
	    GlobalVariables::InputFileStreams.f_in_n_models_visited >> tmp;
	    GlobalVariables::InputFileStreams.f_in_n_models_visited >> pastNModelsVisited_[i];
	}
	GlobalVariables::InputFileStreams.f_in_n_models_visited.close();

	GlobalVariables::InputFileStreams.f_in.close();

	if(resumeSweep_>burn_in_)
	{
	    list_Models_.resize(resumeSweep_-burn_in_);
	}
	for(unsigned int i=0;i<resumeSweep_+1;i++)
	{
	    n_Models_visited_[i]=pastNModelsVisited_[i];
	    if(i>burn_in_)
	    {
		unsigned int tmp = past_models_[i][0];
		list_Models_[i-1-burn_in_].resize(tmp+1);
		list_Models_[i-1-burn_in_][0]=tmp;
		for(unsigned int j=0;j<tmp;j++)
		{
		    list_Models_[i-1-burn_in_][j+1]=past_models_[i][j+1];
		}
	    }
	}
    }
}

void MCMC::update()
{
    // Reset the permutation object
    gsl_permutation_init(MyPerm_);

    n_Models_visited_[sweep_]=n_Models_visited_[sweep_-1];

    ////////////////////////////////////////////////////
    /////////////////// Local Moves  ///////////////////
    ////////////////////////////////////////////////////

    //Gibbs Moves
    if(sweep_%Gibbs_n_batch_==0)
    {
	if (Settings.verbose)
	    clog << "Move: Gibbs; ";

    	Gibbs_move();
    }

    ////Fast Scan Metropolis Hastings (FSMH)
    double local_move_rand=gsl_rng_uniform(MCMC::RandomNumberGenerator);
    if(n_chains_==1)
    {
    	local_move_rand=0.0;
    }

    bool covarGammaFlag = false;
    if(local_move_rand<Prior::Prob_mut)
    {
	if(Settings.gammaUpdateMove) {
	    double doCovar = gsl_rng_uniform(MCMC::RandomNumberGenerator);
	    if (doCovar < Settings.gammaUpdateMoveProb) {
		if (Settings.verbose)
		    clog << "Move: Gamma update\n";
		covar_gamma_move();
		covarGammaFlag = true;
	    } else {
		if (Settings.verbose)
		    clog << "Move: FSMH; ";
		FSMH_move();
	    }
		
	} else {
	    if(Settings.verbose)
		clog << "Move: FSMH; ";
	    FSMH_move();
	}
    }
    else
    {
    	///////////////////////////////////////////////////////
    	/////////////////////// CM Moves  /////////////////////
    	///////////////////////////////////////////////////////

    	//Defining the number of CO move to simulate
    	if(Settings.verbose)
	    clog << "Move: CM; ";

    	crossovermove_->execute(chainsVector_,
				mat_X,
				mat_Y,
				chain_idx_,
				sweep_,
				n_Models_visited_,
				maxPX_,
				g_,
				k_prior_,
				MCMC::RandomNumberGenerator);
    }

    ///////////////////////////////////////////////////////
    ///////////////////// Global Moves  ///////////////////
    ///////////////////////////////////////////////////////
    if(n_chains_>1)
    {
    	double global_move_rand=gsl_rng_uniform(MCMC::RandomNumberGenerator);
    	if(sweep_<=burn_in_)
    	{
	    global_move_rand=0.0;//during burn-in, DR is the only global move
    	}

    	if(global_move_rand<Prior::Prob_DR)
    	{
	    if(Settings.verbose)
		clog << "Move: DR; ";

	    delayedrejectionmove_->execute(chainsVector_,
					   chain_idx_,
					   sweep_,
					   MCMC::RandomNumberGenerator);
    	}
    	else
    	{
	    if(Settings.verbose)
		clog << "Move: AE; ";

	    allexchangemove_->execute(chainsVector_,
				      chain_idx_,
				      sweep_,
				      MCMC::RandomNumberGenerator);
    	}
    }

    ///////////////////////////////////////////////////
    ///////////////// Temp placement //////////////////
    ///////////////////////////////////////////////////
    if(n_chains_>1)
    {
    	if(sweep_<=burn_in_)
    	{
	    if((delayedrejectionmove_->nb_calls_adj==
		temperaturetuning_->nbatch) ||
	       (delayedrejectionmove_->nb_calls==
		5*temperaturetuning_->nbatch)){

		unsigned int n_vars_in_last_chain=chainsVector_[chain_idx_[n_chains_-1]].getVariablesIncluded();

		temperaturetuning_->execute(delayedrejectionmove_,
					    chainsVector_,
					    chain_idx_,
					    sweep_,
					    n_vars_in_last_chain,
					    nX);
	    }
    	}
    }

    if(GlobalVariables::GlobalFlags.Log_Flag)
    {
    	clog << "Sweep\tTime\t#models\tTime/model" << endl;
        clog << sweep_ << "\t"
	    //    << time_taken << "\t"
             << n_Models_visited_[sweep_]-n_Models_visited_[sweep_-1] << "\t"
	    //    << time_taken/(double)(n_Models_visited_[sweep_]-n_Models_visited_[sweep_-1])
	     <<  endl;
    }

    if(sweep_>burn_in_)
    {
    	cum_g_+=g_;
    	count_g_++;
    }

    //update log of move monitor object
    /*
      mcmcMoveMonitor_->set(fsmhlog_,
      crossovermove_->log_,
      delayedrejectionmove_->log_,
      allexchangemove_->log_,
      adaptivemh_->log_,
      gibbslog_,
      temperaturetuning_->log_);
    */
}

void MCMC::print_and_save_main_results_per_sweep_to_file()
{
    unsigned int pos_chain=chain_idx_[0];

    unsigned int n_vars_in=chainsVector_[pos_chain].getVariablesIncluded();

    if(GlobalVariables::GlobalFlags.HistoryFlag)
    {
	GlobalVariables::OutputFileStreams.f_out << sweep_ << "\t"
						 << n_vars_in << "\t";
	GlobalVariables::OutputFileStreams.f_out << std::setprecision(13) << chainsVector_[pos_chain].getLogMarginalForSweep(sweep_) << "\t";
	GlobalVariables::OutputFileStreams.f_out << std::setprecision(13) <<chainsVector_[pos_chain].getLogCondPostForSweep(sweep_) << "\t";
    }

    if(sweep_>burn_in_)
    {
	list_Models_.push_back(vector<unsigned int>());
	unsigned int last_pos_in_List=list_Models_.size()-1;
	list_Models_[last_pos_in_List].push_back(0);//room for the #of variables in
    }
    unsigned int count_n_vars_in=0;

    for(unsigned int var=0;var<pX;var++)
    {
	if(chainsVector_[pos_chain].getGammaForVariable(var)==1)
	{
	    if(GlobalVariables::GlobalFlags.HistoryFlag)
	    {
		GlobalVariables::OutputFileStreams.f_out << var+1 << " ";
	    }

	    if(sweep_>burn_in_)
	    {
		unsigned int last_pos_in_List=list_Models_.size()-1;
		list_Models_[last_pos_in_List].push_back(var);
		count_n_vars_in++;
	    }
	}
    }

    if(sweep_>burn_in_)
    {
	unsigned int last_pos_in_List=list_Models_.size()-1;
	list_Models_[last_pos_in_List][0]=count_n_vars_in;
    }
    if(GlobalVariables::GlobalFlags.HistoryFlag)
    {
	GlobalVariables::OutputFileStreams.f_out << endl;
	GlobalVariables::OutputFileStreams.f_out_log_cond_post_per_chain << sweep_ << "\t";
	GlobalVariables::OutputFileStreams.f_out_n_vars_in << sweep_ << "\t";
	GlobalVariables::OutputFileStreams.f_out_n_models_visited << sweep_ << "\t" << n_Models_visited_[sweep_] << endl;
	for(unsigned int chain=0;chain<n_chains_;chain++)
	{
	    unsigned int current_chain=chain_idx_[chain];
	    unsigned int n_vars_in_per_chain=chainsVector_[current_chain].getVariablesIncluded();

	    GlobalVariables::OutputFileStreams.f_out_n_vars_in << n_vars_in_per_chain << "\t";
	    GlobalVariables::OutputFileStreams.f_out_log_cond_post_per_chain << std::setprecision(13) << chainsVector_[current_chain].getLogCondPostForSweep(sweep_) << "\t";
	}

	GlobalVariables::OutputFileStreams.f_out_n_vars_in << endl;
	GlobalVariables::OutputFileStreams.f_out_log_cond_post_per_chain << endl;
    }
}


void MCMC::display_summary_result_per_sweep()
{
    for(unsigned int chain=0;chain<n_chains_;chain++)
    {
	unsigned int pos_chain=chain_idx_[chain];

	unsigned int n_vars_in=chainsVector_[pos_chain].getVariablesIncluded()-nConfounders_;

	clog << "Chain #" << chain+1
	     << " -- position: " << pos_chain+1
	     << " -- log_marg " << chainsVector_[pos_chain].getLogMarginalForSweep(sweep_)
	     << " -- log_cond_post " << chainsVector_[pos_chain].getLogCondPostForSweep(sweep_)
	     << " -- n_vars_in " << n_vars_in
	     << " -- temperature " << chainsVector_[pos_chain].getCurrentTemperature()
	     << endl;
    }
}

void MCMC::print_and_save_main_results_per_sweep_to_string()
{
    unsigned int pos_chain=chain_idx_[0];
    unsigned int n_vars_in=chainsVector_[pos_chain].getVariablesIncluded()-nConfounders_;

    if(GlobalVariables::GlobalFlags.HistoryFlag)
    {
	GlobalVariables::OutputStringStreams.strStrOut << sweep_ << "\t"<< n_vars_in << "\t";
	GlobalVariables::OutputStringStreams.strStrOut << std::setprecision(13) << chainsVector_[pos_chain].getLogMarginalForSweep(sweep_) << "\t";
	GlobalVariables::OutputStringStreams.strStrOut << std::setprecision(13) << chainsVector_[pos_chain].getLogCondPostForSweep(sweep_) << "\t";
    }

    if(sweep_>burn_in_)
    {
	list_Models_.push_back(vector<unsigned int>());
	unsigned int last_pos_in_List=list_Models_.size()-1;
	list_Models_[last_pos_in_List].push_back(0);//room for the #of variables in
    }
    unsigned int count_n_vars_in=0;

    for(unsigned int var=0;var<pX;var++){
	if(chainsVector_[pos_chain].getGammaForVariable(var)==1)
	{
	    if(GlobalVariables::GlobalFlags.HistoryFlag)
	    {
		GlobalVariables::OutputStringStreams.strStrOut << var+1 << " ";
	    }
	    if(sweep_>burn_in_)
	    {
		unsigned int last_pos_in_List=list_Models_.size()-1;
		list_Models_[last_pos_in_List].push_back(var);
		count_n_vars_in++;
	    }
	}
    }
    if(sweep_>burn_in_)
    {
	unsigned int last_pos_in_List=list_Models_.size()-1;
	list_Models_[last_pos_in_List][0]=count_n_vars_in;
    }
    if(GlobalVariables::GlobalFlags.HistoryFlag){
	GlobalVariables::OutputStringStreams.strStrOut << endl;
	GlobalVariables::OutputStringStreams.strStrOutLogCondPostPerChain << sweep_<< "\t";
	GlobalVariables::OutputStringStreams.strStrOutNVarsIn << sweep_ << "\t";
	GlobalVariables::OutputStringStreams.strStrOutNModelsVisited << sweep_ << "\t" << n_Models_visited_[sweep_] << endl;
	for(unsigned int chain=0;chain<n_chains_;chain++)
	{
	    unsigned int current_chain=chain_idx_[chain];
	    unsigned int n_vars_in_per_chain=chainsVector_[current_chain].getVariablesIncluded()-nConfounders_;
	    GlobalVariables::OutputStringStreams.strStrOutNVarsIn << n_vars_in_per_chain << "\t";
	    GlobalVariables::OutputStringStreams.strStrOutLogCondPostPerChain << std::setprecision(13) << chainsVector_[current_chain].getLogCondPostForSweep(sweep_)<< "\t";
	}
	GlobalVariables::OutputStringStreams.strStrOutNVarsIn << endl;
	GlobalVariables::OutputStringStreams.strStrOutLogCondPostPerChain << endl;
    }
}

void MCMC::saveResumeFile()
{
    std::fstream fResume;
    FILE * fRNG;

    fResume.open(GlobalVariables::InputOutputFileNames.resume.c_str(),std::ios::out);
    fRNG=fopen(GlobalVariables::InputOutputFileNames.rng.c_str(),"wb");

    double gLs = adaptivemh_->ls;
    // Store the random number state
    gsl_rng_fwrite(fRNG,MCMC::RandomNumberGenerator);
    fResume << sweep_ << endl;
    fResume << setiosflags(std::ios::fixed) << std::setprecision(10) << g_ << endl;

    for(unsigned int i=0;i<nY;i++)
    {
	fResume << shuffleYIndex_[i] << endl;
    }

    fResume << cum_g_ << endl;
    fResume << count_g_ << endl;
    for(unsigned int j=0;j<pY;j++)
    {
	fResume << vect_RMSE_->data[j] << endl;
    }

    for(unsigned int j=0;j<n_chains_;j++)
    {
	fResume << setiosflags(std::ios::fixed) << std::setprecision(10) << chainsVector_[chain_idx_[j]].getCurrentTemperature() << endl;
    }

    fResume << setiosflags(std::ios::fixed) << std::setprecision(10) << temperaturetuning_->b_t << endl;
    fResume << setiosflags(std::ios::fixed) << std::setprecision(10) << gLs << endl;

    fResume << delayedrejectionmove_->nb_calls << endl;
    fResume << delayedrejectionmove_->nb_calls_adj << endl;

    for(unsigned int j=0;j<n_chains_;j++)
    {
	for(unsigned int k=0;k<n_chains_;k++)
	{
	    fResume << delayedrejectionmove_->mat_moves_proposed[j][k] << endl;
	}
    }

    for(unsigned int j=0;j<n_chains_;j++)
    {
	for(unsigned int k=0;k<n_chains_;k++)
	{
	    fResume << delayedrejectionmove_->mat_moves_accepted[j][k] << endl;
	}
    }

    for(unsigned int c=0;c<n_chains_;c++)
    {
	vector<unsigned int> tmpVec;
	for(unsigned int j=0;j<pX;j++)
	{
	    if(j<nConfounders_)
	    {
		continue;
	    }

	    if(chainsVector_[chain_idx_[c]].getGammaForVariable(j)==1)
	    {
		tmpVec.push_back(j);
	    }
	}

	fResume << tmpVec.size() << endl;
	fResume << chain_idx_[c] << endl;

	for(unsigned int j=0;j<tmpVec.size();j++)
	{
	    fResume << tmpVec[j] << endl;
	}
    }
    fclose(fRNG);
    fResume.close();
}

//Utility Functions

void MCMC::readMatrixX()
{
    gsl_matrix_free(mat_X);

    std::fstream f_X;
    f_X.open(filename_in_mat_X_,std::ios::in);
    readMatrixX(f_X);
    f_X.close();
}

void MCMC::readMatrixX(std::istream &f) {

    f >> nX;    // Number of observations
    f >> pX;    // Number of variables
    
    std::string line;
    getline(f, line);  // Eat trailing newline

    mat_X = gsl_matrix_alloc(nX,pX);

    for (unsigned int i = 0; i < nX; i++) {
	if (! getline(f, line))
	    exitWithError("X data file does not contain " + std::to_string(nX) + " observations");
	
	std::stringstream ss(line);
	double val;

	for (unsigned int j = 0; j < pX; j++) {
	    if (! (ss >> val))
		exitWithError("Reading X data: Invalid observation at line " + std::to_string(i));
	    
	    gsl_matrix_set(mat_X, i, j, val);
	}
    }
 
    MatrixManipulation::center_matrix_gsl(mat_X);
    if(Settings.standardiseX)
	MatrixManipulation::standardize_matrix_gsl(mat_X);

#if _CUDA_
    if (GlobalVariables::GlobalFlags.cudaFlag) {
	clog << "Writing X data to GPU memory..." << endl;
	cudaMalloc((float**) &mat_X_GPU, nX * pX * sizeof(float));
	Data_X_CPU = (float*) malloc(nX*pX*sizeof(float));
	MatrixManipulation::Row2Col(mat_X,Data_X_CPU,nX,pX);
	cudaThreadSynchronize();
	cudaDeviceSynchronize();
	cudaMemcpy(mat_X_GPU, Data_X_CPU, nX * pX * sizeof(float), cudaMemcpyHostToDevice);		
	cudaDeviceSynchronize();
	cudaThreadSynchronize();
	cudaError_t err = cudaGetLastError();
	if (err != cudaSuccess) {
	    clog << "Error: " + cudaGetErrorString(err) + "\n";	
	    cublasShutdown();
	    culaShutdown();
	    free(Data_X_CPU);
	    exit(-1);
	}
    }

    free(Data_X_CPU);
#endif
}

void MCMC::setMatrixFiles(char* filename_in_mat_X,char* filename_in_mat_Y)
{
    filename_in_mat_X_=filename_in_mat_X;
    filename_in_mat_Y_=filename_in_mat_Y;
}

void MCMC::readMatrixY()
{
    gsl_matrix_free(mat_Y);

    std::fstream f_Y;
    f_Y.open(filename_in_mat_Y_,std::ios::in);
    f_Y >> nY;
    f_Y >> pY;
   
    initializeShuffleIndex();

    mat_Y=gsl_matrix_alloc(nY,pY);

    for(unsigned int i=0;i<nY;i++)
    {
	for(unsigned int j=0;j<pY;j++)
	{
	    double tmp;
	    f_Y >> tmp;
	    gsl_matrix_set(mat_Y,i,j,tmp);
	}
    }
    f_Y.close();

    MatrixManipulation::center_matrix_gsl(mat_Y);

    //Testing the number of variables in Y
    if(nX<pY)
    {
	clog << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl
	     << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl
	     << "There are too many outcomes ("<< pY
	     << ") compared to the number of observations (" << nX
	     << "), run stopped" << endl;
	clog << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl
	     << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
#if _CUDA_
	if(GlobalVariables::GlobalFlags.cudaFlag)
	{
	    cublasShutdown();
	    culaShutdown();
	}
#endif
	exit(-1);
    }

#if _CUDA_
    if (GlobalVariables::GlobalFlags.cudaFlag) 
    {
	readMatrixYGPU();
    }

#endif
}
#if _CUDA_
void MCMC::readMatrixYGPU(){

    clog << "Writing Y data to GPU memory..." << endl;
    Data_Y_CPU =(float*) malloc((nY*pY)*sizeof(float));
    cudaMalloc((float**) &mat_Y_GPU, (nY*pY) * sizeof(float));
    MatrixManipulation::Row2Col(mat_Y,Data_Y_CPU,nY,pY);
    cudaThreadSynchronize();
    cudaDeviceSynchronize();
    cudaMemcpy(mat_Y_GPU, Data_Y_CPU, nY * pY * sizeof(float),cudaMemcpyHostToDevice);	
    cudaDeviceSynchronize();
    cudaThreadSynchronize();
    cudaError_t err = cudaGetLastError();
    if (err != cudaSuccess) {
	printf("Error: %s\n", cudaGetErrorString(err));		
	cublasShutdown();
	culaShutdown();
	free(Data_Y_CPU);
	exit(-1);
    }
	
    free(Data_Y_CPU);	
    clog << "Finished writing Y data to GPU memory" << endl<< endl;
	
}
#endif
gsl_matrix* MCMC::get_X_gam(vector <unsigned int> &list_columns_var_in)
{
    unsigned int n_vars_in=list_columns_var_in.size();
    unsigned int nX=mat_X->size1;
    gsl_matrix *X_gam=gsl_matrix_alloc(nX,n_vars_in);
    for(unsigned int col=0;col<n_vars_in;col++){
	//Copying the the col^th variable (at position list_columns_var_in[col] in mat_X)
	gsl_vector_view current_col = gsl_matrix_column (mat_X,list_columns_var_in[col]);
	//Setting the col^th column of X_gam
	gsl_matrix_set_col (X_gam,col,&current_col.vector);
    }
    return X_gam;
}

gsl_matrix* MCMC::get_X_reduced_and_constant(vector <unsigned int> &list_columns_var)
{
    unsigned int n_vars=list_columns_var.size();
    gsl_matrix *X_red=gsl_matrix_alloc(nX,(n_vars)+1);

    //The first column is set to 1: the constant term of the regression
    gsl_vector *temp_vector=gsl_vector_alloc(nX);
    gsl_vector_set_all(temp_vector,1.0);
    gsl_matrix_set_col (X_red,0,temp_vector);

    gsl_vector_free(temp_vector);

    //Setting the other columns to the list of vars in
    for(unsigned int col=0;col<n_vars;col++){
	//Copying the the col^th variable (at position list_columns_var_in[col] in mat_X)
	gsl_vector_view current_col = gsl_matrix_column (mat_X,list_columns_var[col]);
	//Setting the col^th column of X_red
	gsl_matrix_set_col (X_red,col+1,&current_col.vector);
    }
    return X_red;
}

void MCMC::get_X_reduced(vector <unsigned int> &list_columns_var,gsl_matrix* X_reduced)
{
    unsigned int n_vars=list_columns_var.size();
    gsl_matrix* X_red=gsl_matrix_alloc(nX,n_vars);
    //Setting the other columns to the list of vars in
    for(unsigned int col=0;col<n_vars;col++){
	//Copying the the col^th variable (at position list_columns_var_in[col] in mat_X)
	gsl_vector_view current_col = gsl_matrix_column (mat_X,list_columns_var[col]);
	//Setting the col^th column of X_red
	gsl_matrix_set_col (X_red,col,&current_col.vector);
    }
    gsl_matrix_memcpy(X_reduced,X_red);
    gsl_matrix_free(X_red);
}

//PRIVATE METHODS
void MCMC::addChain(vector<bool> &vect_gam)
{
    Chain newChain(vect_gam);
    newChain.yIndex = yIndex;
    newChain.setScorePY(pY);
    newChain.initialize(n_sweeps_+1,chainsVector_.size(),resumeSweep_, nConfounders_);
    chainsVector_.push_back(newChain);
}

void MCMC::scoreUpdating(unsigned int chain)
{
    //This function aims in creating a reduced X matrix and running the score calculation
    //function of the specific chain that is included as an argument.

#if _CUDA_
    if (GlobalVariables::GlobalFlags.cudaFlag)
	chainsVector_[chain].calculateScore(g_,mat_Y,k_prior_,mat_Y_GPU);
    else
	chainsVector_[chain].calculateScore(g_,mat_Y,k_prior_);
#else
    chainsVector_[chain].calculateScore(g_,mat_Y,k_prior_);
#endif
}

void MCMC::scoreUpdatingSGamma(unsigned int chain, gsl_matrix* sgamma) {
    chainsVector_[chain].calculateScoreSGamma(g_,mat_Y,k_prior_,sgamma);
}

void MCMC::getUniqueList() {
    PostProcessing::getUniqueList(unique_list_models_,
						 list_Models_,
						 n_Models_visited_,
						 burn_in_,
						 pX,
						 nConfounders_);
}

void MCMC::runPostProcessing()
{
    //Step1: Calculating E(g);
    double mean_g=cum_g_/(double)(count_g_);

    //Step2: Get the Unique list of models and integrate log posterior
    vector< vector<double> >vect_marg_log_post;
    int pos_null_model;

    pos_null_model=PostProcessing::getUniqueList(unique_list_models_,
						 list_Models_,
						 n_Models_visited_,
						 burn_in_,
						 pX,
						 nConfounders_);
	
#if _CUDA_
#else
    float *mat_Y_GPU = NULL;
#endif 
	
    PostProcessing::getLogPost(vect_marg_log_post,
			       unique_list_models_,
			       mean_g,
			       mat_Y,
			       mat_Y_GPU,
			       k_prior_);

    //Step4: Get the posterior of the model
    unsigned int n_unique = unique_list_models_.size();
    gsl_permutation *idx_post_gam_sort=gsl_permutation_calloc(vect_marg_log_post.size());
    gsl_vector *vect_post_gam = gsl_vector_calloc(vect_marg_log_post.size());

    unsigned int n_retained_models=std::min(n_unique,n_top_models_);

    PostProcessing::getAndSortPostGam(vect_post_gam,
				      idx_post_gam_sort,
				      vect_marg_log_post);

    PostProcessing::combineAndPrintBestModel(idx_post_gam_sort,
					     vect_post_gam,
					     vect_marg_log_post,
					     unique_list_models_,
					     n_retained_models,
					     pos_null_model,
					     nConfounders_);

    PostProcessing::getAndPrintMargGam(unique_list_models_,
				       vect_post_gam,
				       pX,
				       nConfounders_);

    // Clear and free variables
    gsl_permutation_free(idx_post_gam_sort);
    gsl_vector_free(vect_post_gam);

    for(unsigned int line=0;line<list_Models_.size();line++)
    {
	list_Models_[line].clear();
    }
    list_Models_.clear();

    for(unsigned int line=0;line<unique_list_models_.size();line++){
	unique_list_models_[line].clear();
	vect_marg_log_post[line].clear();
    }

    unique_list_models_.clear();
}

void MCMC::initializeAdaptiveMH(unsigned int n_batch_from_read,
				double g_AdMH_optimal_from_read,
				double g_AdMH_ls_from_read,
				double g_M_min_input,
				double g_M_max_input) {

    if(!Settings.postProcOnly) {
	adaptivemh_->set(n_batch_from_read, g_AdMH_optimal_from_read,
			 g_AdMH_ls_from_read, pX, burn_in_,
			 g_M_min_input, g_M_max_input);
    }
}

void MCMC::initializeDelayedRejection(unsigned int resumeDRNCalls,
				      unsigned int resumeDRNCallsAdj,
				      vector< vector < unsigned int > > resumeDRAccepted,
				      vector< vector < unsigned int > > resumeDRProposed)
{
    //////////////////////////////////
    //  Setting up DR parameters
    //////////////////////////////////

    if(!Settings.postProcOnly)
    {
	if(Settings.resumeRun || Settings.extendRun)
	{
	    delayedrejectionmove_->nb_calls=resumeDRNCalls;
	    delayedrejectionmove_->nb_calls_adj=resumeDRNCallsAdj;
	    for(unsigned int j=0;j<n_chains_;j++)
	    {
		for(unsigned int k=0;k<n_chains_;k++)
		{
		    delayedrejectionmove_->mat_moves_accepted[j][k]=resumeDRAccepted[j][k];
		    delayedrejectionmove_->mat_moves_proposed[j][k]=resumeDRProposed[j][k];
		}
	    }
	}
    }
}

void MCMC::initializeCrossover(unsigned int k_max_from_read) {

    vector <unsigned int > list_CM_moves_enabled_from_read;

    if(!Settings.postProcOnly) {
	list_CM_moves_enabled_from_read.push_back(1);
	list_CM_moves_enabled_from_read.push_back(2);

	crossovermove_->set(k_max_from_read, list_CM_moves_enabled_from_read);
    }
}

void MCMC::initializeChains()
{
    //////////////////////////////////
    //   Initializing the chains
    //////////////////////////////////

    if(!Settings.postProcOnly)
    {
	if(Settings.extendRun)
	{
	    n_sweeps_+=nExtSweeps_;
	}

	//clog << "Initialising chains" << endl;

	chain_idx_.resize(n_chains_);

	for(unsigned int curr_chain=0;curr_chain<n_chains_;curr_chain++)
	{
	    chain_idx_[curr_chain]=curr_chain;
	}

	MyPerm_ = gsl_permutation_calloc(pX);

	if(n_sweeps_==0 || burn_in_==0)
	{
	    clog << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl
		 << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl
		 << "The Number of sweeps and/or the burn-in has not been specified" << endl
		 << "Use -iter and/or -burn-in option(s) in the command line" << endl
		 << "Run stopped" << endl
		 << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl
		 << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
#if _CUDA_
	    stopCula();
#endif
	    exit(-1);
	}

	if(n_sweeps_ <= burn_in_)
	{
	    clog << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl
		 << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl
		 << "The Number of sweeps: " << n_sweeps_ << " is lower than " << endl
		 << "(or equal to) the burn-in: " << burn_in_ << " -- Run stopped" << endl
		 << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl
		 << "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
#if _CUDA_
	    stopCula();
#endif
	    exit(-1);
	}
    }
}

void MCMC::initializeTemperature(double b_t_input, double a_t_den_inf_5k,
				 double a_t_den_5_10k, double a_t_den_sup_10k,
				 unsigned int temp_n_batch, vector < double > &M_input,
				 double temp_optimal_input) {
    if(! Settings.postProcOnly)
	temperaturetuning_->set(chainsVector_, chain_idx_, n_chains_, 
				pX, b_t_input, a_t_den_inf_5k,
				a_t_den_5_10k, a_t_den_sup_10k, temp_n_batch,
				M_input, burn_in_, temp_optimal_input);
}

void MCMC::run()
{
#if DEBUG  
    //double ts = timestamp();  
#endif	

    adaptivemh_->display();
    delayedrejectionmove_->display();
    crossovermove_->display();
    temperaturetuning_->display();
    
    for(sweep_=resumeSweep_+1;sweep_<n_sweeps_+1;sweep_++)
    {
	clog<< "Sweep " << sweep_ << endl;
		
        GlobalVariables::Time.start=clock();

        for(unsigned int chain=0;chain<n_chains_;chain++)
        {
	    //initialize new sweep
	    chainsVector_[chain_idx_[chain]].newSweep();
        }

        //Main updating move of the MCMC where all the logic is held.
#if DEBUG  
	//double ts = timestamp();  
#endif	
	
        update();
		
        runAdaptiveMH();

#if DEBUG	  
	//double mid = timestamp() - ts;
	//clog << "Update time: " << mid << " seconds" << endl; 
	//clog << mid << endl; 
#endif	

        if(GlobalVariables::GlobalFlags.Log_Flag)
        {
	    display_summary_result_per_sweep();
        }

        if(timeLimit_>0)
        {
            print_and_save_main_results_per_sweep_to_file();

	    cerr << "testing history: " << GlobalVariables::GlobalFlags.HistoryFlag << endl;

            if(GlobalVariables::GlobalFlags.HistoryFlag && Settings.moveLog)
            {
            	mcmcMoveMonitor_->print_move_monitor_per_sweep_to_file(sweep_,n_chains_);
            }
        }
        else
        {
	    print_and_save_main_results_per_sweep_to_string();

	    if(GlobalVariables::GlobalFlags.HistoryFlag && Settings.moveLog)
	    {
		mcmcMoveMonitor_->print_move_monitor_per_sweep_to_string(sweep_,n_chains_);
	    }
        }

        if(timeLimit_>0)
        {
	    saveResumeFile();
        }

        GlobalVariables::Time.end=clock();
        double time_taken=((double)GlobalVariables::Time.end-GlobalVariables::Time.start)/CLOCKS_PER_SEC;

    	if(GlobalVariables::GlobalFlags.Time_monitorFlag)
    	{
	    if(timeLimit_>0)
	    {
		GlobalVariables::OutputFileStreams.f_out_time << sweep_ << "\t" << time_taken << "\t"
							      << time_taken/(double)(n_Models_visited_[sweep_]-n_Models_visited_[sweep_-1]) << endl;
	    }
	    else
	    {
		GlobalVariables::OutputStringStreams.strStrOutTime << sweep_ << "\t" << time_taken << "\t"
								   << time_taken/(double)(n_Models_visited_[sweep_]-n_Models_visited_[sweep_-1]) << endl;
	    }
    	}
	GlobalVariables::Time.current = time(NULL);
	double timeElapsed=((double)GlobalVariables::Time.current-GlobalVariables::Time.begin)/3600;

	if(GlobalVariables::GlobalFlags.Time_monitorFlag)
	{
	    clog << "Time elapsed: " << timeElapsed << endl;
	}

	if(timeLimit_>0&&timeElapsed>timeLimit_)
	{
	    // Time has passed the limit so we need to stop
	    if(GlobalVariables::GlobalFlags.HistoryFlag)
	    {
		GlobalVariables::OutputFileStreams.f_out.close();
		GlobalVariables::OutputFileStreams.f_out_n_vars_in.close();
		GlobalVariables::OutputFileStreams.f_out_log_cond_post_per_chain.close();
		GlobalVariables::OutputFileStreams.f_out_n_models_visited.close();
		GlobalVariables::OutputFileStreams.f_out_FSMH.close();
		GlobalVariables::OutputFileStreams.f_out_CM.close();
		GlobalVariables::OutputFileStreams.f_out_AE.close();
		GlobalVariables::OutputFileStreams.f_out_DR.close();
		if(Settings.gSampleFlag)
		{
		    GlobalVariables::OutputFileStreams.f_out_g.close();
		    GlobalVariables::OutputFileStreams.f_out_g_adapt.close();
		}

		GlobalVariables::OutputFileStreams.f_out_Gibbs.close();
		if(Settings.noTemperature==false)
		{
		    GlobalVariables::OutputFileStreams.f_out_t_tun.close();
		}
	    }

	    if(GlobalVariables::GlobalFlags.Time_monitorFlag)
	    {
		GlobalVariables::OutputFileStreams.f_out_time.close();
	    }

#if _CUDA_
	    stopCula();
#endif
	    GlobalVariables::OutputFileStreams.f_out_features << "last_sweep\t" << sweep_ << endl;
	    GlobalVariables::OutputFileStreams.f_out_features << "run_finished\t" << GlobalVariables::GlobalFlags.run_finished << endl;

	    GlobalVariables::OutputFileStreams.f_out_features.close();
	    clog << "Run curtailed as time limit exceeded. Please run with -resume flag." << endl;
	    exit(0);
	}// end of time limit reached
    }//end of for sweep
		
    // Now if we weren't writing as we went along, write the output
    if(timeLimit_<0)
    {
	if(GlobalVariables::GlobalFlags.HistoryFlag)
	{
	    GlobalVariables::OutputFileStreams.f_out << GlobalVariables::OutputStringStreams.strStrOut.str();
	    GlobalVariables::OutputFileStreams.f_out_n_vars_in << GlobalVariables::OutputStringStreams.strStrOutNVarsIn.str();
	    GlobalVariables::OutputFileStreams.f_out_log_cond_post_per_chain << GlobalVariables::OutputStringStreams.strStrOutLogCondPostPerChain.str();
	    GlobalVariables::OutputFileStreams.f_out_n_models_visited << GlobalVariables::OutputStringStreams.strStrOutNModelsVisited.str();
	    GlobalVariables::OutputFileStreams.f_out_Gibbs << GlobalVariables::OutputStringStreams.strStrOutGibbs.str();
	    GlobalVariables::OutputFileStreams.f_out_FSMH << GlobalVariables::OutputStringStreams.strStrOutFSMH.str();
	    GlobalVariables::OutputFileStreams.f_out_CM << GlobalVariables::OutputStringStreams.strStrOutCM.str();
	    GlobalVariables::OutputFileStreams.f_out_AE << GlobalVariables::OutputStringStreams.strStrOutAE.str();
	    GlobalVariables::OutputFileStreams.f_out_DR << GlobalVariables::OutputStringStreams.strStrOutDR.str();
	    if(Settings.gSampleFlag)
	    {
		GlobalVariables::OutputFileStreams.f_out_g << GlobalVariables::OutputStringStreams.strStrOutG.str();
		GlobalVariables::OutputFileStreams.f_out_g_adapt << GlobalVariables::OutputStringStreams.strStrOutGAdapt.str();
	    }

	    if(!Settings.noTemperature)
	    {
		GlobalVariables::OutputFileStreams.f_out_t_tun << GlobalVariables::OutputStringStreams.strStrOutTTun.str();
	    }

	    if(GlobalVariables::GlobalFlags.Time_monitorFlag)
	    {
		GlobalVariables::OutputFileStreams.f_out_time << GlobalVariables::OutputStringStreams.strStrOutTime.str();
	    }
	}
    }

    if(GlobalVariables::GlobalFlags.HistoryFlag)
    {
	GlobalVariables::OutputFileStreams.f_out.close();
	GlobalVariables::OutputFileStreams.f_out_n_vars_in.close();
	GlobalVariables::OutputFileStreams.f_out_log_cond_post_per_chain.close();
	GlobalVariables::OutputFileStreams.f_out_n_models_visited.close();
	GlobalVariables::OutputFileStreams.f_out_FSMH.close();
	GlobalVariables::OutputFileStreams.f_out_CM.close();
	GlobalVariables::OutputFileStreams.f_out_AE.close();
	GlobalVariables::OutputFileStreams.f_out_DR.close();
	if(Settings.gSampleFlag)
	{
	    GlobalVariables::OutputFileStreams.f_out_g.close();
	    GlobalVariables::OutputFileStreams.f_out_g_adapt.close();
	}
	GlobalVariables::OutputFileStreams.f_out_Gibbs.close();

	if(!Settings.noTemperature)
	{
	    GlobalVariables::OutputFileStreams.f_out_t_tun.close();
	}
    }

    if(GlobalVariables::GlobalFlags.Time_monitorFlag)
    {
	GlobalVariables::OutputFileStreams.f_out_time.close();
    }

    clog << "***************************************" << endl
	 << "***************************************" << endl
	 << "           END OF SWEEPS" << endl
	 << "       # models evaluated: " << n_Models_visited_[n_sweeps_] << endl
	 << "***************************************" << endl
	 <<  "***************************************" << endl << endl;

    GlobalVariables::OutputFileStreams.f_out_features << "last_sweep\t" << sweep_-1 << endl;
	  
#if DEBUG	  
    //double mid = timestamp() - ts;
    //clog << "Update time: " << mid << " seconds" << endl; 
    //clog << mid << endl; 
#endif	
}

void MCMC::saveModelPerSweep()
{
    // FOR THE MOMENT, THIS FUNCTION IS ONLY USED IN HESS.
    // NEED TO BE CAREFUL BEFORE USING IT IN ESS

    // We save both the model, and its posterior probability conditional on Omega and g,
    // evaluated at the current sweep.

    /*
      ########################################################################
      0)   PRELIMINARIES
      ########################################################################
    */

    unsigned int pos_chain=chain_idx_[0];

    list_Models_.push_back(vector<unsigned int>());

    unsigned int last_pos_in_List=list_Models_.size()-1;

    /*
      ########################################################################
      1)   SAVE MODEL
      ########################################################################
    */

    list_Models_[last_pos_in_List].push_back(0);//room for the #of variables in

    unsigned int count_n_vars_in=0;

    for(unsigned int var=0;var<pX;var++)
    {
        if(chainsVector_[pos_chain].getGammaForVariable(var)==1)
        {
            //unsigned int last_pos_in_List=List_Models.size()-1;
	    list_Models_[last_pos_in_List].push_back(var);
            count_n_vars_in++;
        }
    }
    //unsigned int last_pos_in_List=List_Models.size()-1;
    list_Models_[last_pos_in_List][0]=count_n_vars_in;

    /*
      ########################################################################
      2)   SAVE...
      ########################################################################
    */

}

void MCMC::initializeShuffleIndex()
{
    shuffleYIndex_.resize(nY);

    if(Settings.resumeRun||Settings.postProcOnly)
    {
	std::fstream f_resume;
	f_resume.open(GlobalVariables::InputOutputFileNames.resume.c_str(),std::ios::in);

	for(unsigned int i=0;i<nY;i++)
	{
	    f_resume >> shuffleYIndex_[i];
	}
	f_resume.close();
    }
    else
    {
	for(unsigned int i=0;i<nY;i++)
	{
	    shuffleYIndex_[i]=i;
	}
	if(GlobalVariables::GlobalFlags.doYShuffle)
	{
	    gsl_ran_shuffle(MCMC::RandomNumberGenerator,&shuffleYIndex_,nY,sizeof(unsigned int));
	}
    }
}

void MCMC::set_g(double new_g)
{
    //Set new g and update the score of all chains
    if (g_!=new_g)
    {
	g_ = new_g;

	for(unsigned int chain=0;chain<n_chains_;chain++)
	{
			
#if _CUDA_
	    if (GlobalVariables::GlobalFlags.cudaFlag)
		chainsVector_[chain_idx_[chain]].calculateScore(new_g,mat_Y,k_prior_,mat_Y_GPU);
	    else
		chainsVector_[chain_idx_[chain]].calculateScore(new_g,mat_Y,k_prior_);
#else
	    chainsVector_[chain_idx_[chain]].calculateScore(new_g,mat_Y,k_prior_);
#endif
			
	    //chainsVector_[chain_idx_[chain]].calculateScore(new_g,mat_Y,k_prior_);
			
	    //chainsVector_[chain_idx_[chain]].setLogCondPostForSweep(adaptivemh_->store_log_cond_post[chain],sweep_);
	    //chainsVector_[chain_idx_[chain]].setLogMarginalForSweep(adaptivemh_->store_log_marg[chain],sweep_);
	}
    }
}


void MCMC::runAdaptiveMH()
{
    /////////////////////////////////////////////////////
    ///////////////////// Sampling g  ///////////////////
    /////////////////////////////////////////////////////

    if(Settings.gSampleFlag)
    {
	adaptivemh_->execute(chainsVector_,mat_Y,
			     g_,
			     k_prior_,
			     sweep_,
			     chain_idx_,
			     n_Models_visited_,
			     MCMC::RandomNumberGenerator);
	//if(GlobalVariables::GlobalFlags.Log_Flag)
	//{
	//    clog << "g = " << g_ << endl;
	//}
    }
}

void MCMC::updateAllScores()
{
    for(unsigned int chain=0;chain<n_chains_;chain++)
    {
	scoreUpdating(chain_idx_[chain]);
    }
}

void MCMC::updateAllScoresSGamma(gsl_matrix* sgamma) {
    scoreUpdatingSGamma(chain_idx_[0], sgamma);
    for (unsigned int chain=1;chain<n_chains_;chain++) {
	scoreUpdating(chain_idx_[chain]);
    }
}

#if _CUDA_
void startCula()
{
    cublasStatus_t stat;
    if (GlobalVariables::GlobalFlags.cudaFlag)
    {
	clog << endl << "Initializing GPU..." << endl;

	int nDevices;
	culaStatus culaStat;
	culaStat = culaGetDeviceCount(&nDevices);
	if(culaStat!=culaNoError)
	{
	    clog << "Error detecting how many devices" << endl;
	    exit(-1);
	}
	else
	{
	    clog<< "Detected " << nDevices << " gpu devices" << endl;
	}

	//cudaThreadExit();
	for(int i=0;i<nDevices;i++)
	{

	    // CCS: TEMPORARY: SET GPU NUM 1 FOR SCHMIDT
	    i=1;
	    
	    culaStat=culaSelectDevice(i);
	    if(culaStat!=culaNoError)
	    {
		clog << culaGetStatusString(culaStat) << endl;
		clog << culaGetErrorInfo() << endl;
		cudaThreadExit();
		continue;
	    }

	    culaStat=culaInitialize();
	    if(culaStat!=culaNoError)
	    {
		clog << culaGetStatusString(culaStat) << endl;
		clog << culaGetErrorInfo() << endl;
		cublasShutdown();
		culaShutdown();
		cudaThreadExit();
		continue;
	    }

	    break;
	}

	if(culaStat!=culaNoError)
	{
	    clog << "Unable to initialise GPU" << endl;
	    cublasShutdown();
	    culaShutdown();
	    exit(1);
	}
	else
	{
	    int device;
	    culaGetExecutingDevice(&device);
	    clog << "Successfully initialised GPU" << endl;
	    clog << "Using device " << device << endl;
	}

	stat = cublasCreate(&GlobalVariables::CudaOpts.handle);
    }
}

void stopCula()
{
    if(GlobalVariables::GlobalFlags.cudaFlag)
    {
	cublasDestroy(GlobalVariables::CudaOpts.handle);
	cublasShutdown();
	culaFreeBuffers();
	culaShutdown();
	cudaDeviceReset();
	clog << "GPU reset finished" << endl << endl;
    }
}
#endif

