/* This file is part of ESS-OO.
 *      Copyright (c) Marc Chadeau-Hyam (m.chadeau@imperial.ac.uk)
 *                    Leonardo Bottolo (l.bottolo@imperial.ac.uk)
 *                    David Hastie (d.hastie@imperial.ac.uk)
 *      2014
 *
 * Software designed and restructured by Loizos Markides (lm1011@ic.ac.uk)
 * ESS-OO is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ESS-OO is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ESS-OO.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef MCMC_H_
#define MCMC_H_

#include "Regression.h"
#include "Chain.h"
#include "Definitions.h"
#include "../UtilityClasses/GlobalVariables.h"
#include "../UtilityClasses/MatrixManipulation.h"
#include "../GlobalMoves/AllGlobalMovesDefinitions.h"
#include "MoveMonitor.h"
#include "PostProcessing.h"

#if _CUDA_
//CULA includes
#include "../ScoreStrategies/timestamp.h"
#include <cuda.h>
#include <cuda_runtime_api.h>
#include <cublas.h>
#include <cula.h>
#include <cula_lapack_device.h>
#include <cula_lapack.h>
#include <cuda_runtime.h>
#include "cublas_v2.h"
#include "../ScoreStrategies/Print.h"
#endif

#if _CUDA_
#else
#include <sys/time.h>
double timestamp ();
#endif

class MCMC {
public:
    gsl_matrix* mat_Y;
    static unsigned int nX;
    static gsl_matrix* mat_X;

#if _CUDA_
    static float *mat_X_GPU;
    static float *Data_X_CPU;
    float *mat_Y_GPU;
    float *Data_Y_CPU;
    void readMatrixYGPU();
#endif

    static unsigned int pX;
    unsigned int nY;
    unsigned int pY;

    static gsl_rng *RandomNumberGenerator;

    TemperatureTuning* temperaturetuning_;
    AdaptiveMH* adaptivemh_;
    AllExchange* allexchangemove_;
    DelayedRejection* delayedrejectionmove_;
    Crossover* crossovermove_;
    MoveMonitor* mcmcMoveMonitor_;

    FSMHlog fsmhlog_;
    GibbsLog gibbslog_;

    MCMC();
    virtual ~MCMC();

    //Initialization functions
    void initializeFromRead(unsigned int n_sweeps,
			    unsigned int burn_in,
			    unsigned int n_top_models_from_read,
			    unsigned int nConfounders,
			    unsigned int nExtSweeps,
			    unsigned int nb_chains,
			    unsigned int Gibbs_n_batch,
			    unsigned int maxPX_,
			    double g,
			    double timeLimit,
			    int MY_SEED);
    void initializeAdaptiveMH(unsigned int n_batch_from_read,
			      double g_AdMH_optimal_from_read,
			      double g_AdMH_ls_from_read,
			      double g_M_min_input,
			      double g_M_max_input);
    void initializeDelayedRejection(unsigned int resumeDRNCalls,
				    unsigned int resumeDRNCallsAdj,
				    std::vector< std::vector < unsigned int > > resumeDRAccepted,
				    std::vector< std::vector < unsigned int > > resumeDRProposed);
    void initializeCrossover(unsigned int k_max_from_read);
    void initializeTemperature(double b_t_input,
			       double a_t_den_inf_5k,
			       double a_t_den_5_10k,
			       double a_t_den_sup_10k,
			       unsigned int temp_n_batch,
			       std::vector < double > &M_input,
			       double temp_optimal_input);
    void initializeChains();
    void runAdaptiveMH();
    void initializeModelsVisited();
    static int initializeRandomNumberGenerator(int seed);

    void createChainsfromRegression();
    void createChainsfromSimple();
    void createChainsfromFixed();
    void createChainsfromResume();

    //Running functions
    void firstSweep();
    void run();
    void runPostProcessing();
    void updateAllScores();
    void updateAllScoresSGamma(gsl_matrix* sgamma);

    //Setter functions
    void setSweepForResume(unsigned int currentSweep,std::vector<unsigned int> resumeChainIndex);
    void setCumulativeG(double cumg, unsigned int countg);
    static void setMatrixFiles(char* filename_in_mat_X,char* filename_in_mat_Y);

    //Printing functions
    void print_main_results_per_sweep();
    void display_summary_result_per_sweep();
    void print_and_save_main_results_per_sweep_to_file();
    void print_and_save_main_results_per_sweep_to_string();
    void saveResumeFile();
    void saveModelPerSweep();
    void getUniqueList();

    //Utility Functions
    void readMatrixY();
    static void readMatrixX(std::istream &f);
    static void readMatrixX();
    gsl_matrix* get_X_gam(std::vector <unsigned int> &list_columns_var_in);
    gsl_matrix* get_X_reduced_and_constant(std::vector <unsigned int> &list_columns_var);
    static void get_X_reduced(std::vector <unsigned int> &list_columns_var,gsl_matrix* X_reduced);
    void set_prior_k (double k_prior) {k_prior_ = k_prior;}

    //Access functions
    unsigned int n_top_models() {return n_top_models_;}
    unsigned int nConfounders(){return nConfounders_;}
    unsigned int nExtSweeps(){return nExtSweeps_;}
    unsigned int seed(){return seed_;}
    unsigned int n_chains(){return n_chains_;}
    unsigned int sweep(){return sweep_;}
    unsigned int n_sweeps(){return n_sweeps_;}
    unsigned int Gibbs_n_batch(){return Gibbs_n_batch_;}
    unsigned int resumeSweep(){return resumeSweep_;}
    static unsigned int burn_in(){return burn_in_;}
    unsigned int maxPX(){return maxPX_;}
    std::vector <unsigned int> ModelsVisited(){return n_Models_visited_;}
    gsl_vector* vect_RMSE(){return vect_RMSE_;}
    virtual void initialize_g(double g_init);
    void set_g(double new_g);
    static unsigned int burn_in_;

    void writeGammaProp();
    void updateAvgAcceptance(unsigned long *acceptCount, unsigned long *rejectCount);

protected:
    void initializeShuffleIndex();
    virtual void addChain(std::vector<bool> &vect_gam);
    void scoreUpdating(unsigned int chain);
    void scoreUpdatingSGamma(unsigned int chain, gsl_matrix* sgamma);
    void update();
    void Gibbs_move();
    void FSMH_move();
    void covar_gamma_move();
    
    unsigned int n_top_models_;
    unsigned int nConfounders_;
    unsigned int nExtSweeps_;
    unsigned int seed_;
    unsigned int n_chains_;
    unsigned int sweep_;
    unsigned int n_sweeps_;
    unsigned int Gibbs_n_batch_;
    unsigned int resumeSweep_;

    unsigned int maxPX_;

    double timeLimit_;

    Chain &chain(int n) { return chainsVector_[chain_idx_[n]]; }

    std::vector < Chain > chainsVector_;
    std::vector < unsigned int > chain_idx_;

    gsl_matrix* getSGamma() { return chain(0).sgamma(); }

    double cum_g_;
    unsigned int count_g_;

    static char* filename_in_mat_X_;
    static char* filename_in_mat_Y_;

    double g_;
    double k_prior_;

    gsl_permutation* MyPerm_;
    gsl_vector *vect_RMSE_;
    std::vector <unsigned int> shuffleYIndex_;
    std::vector <unsigned int> n_Models_visited_;
    std::vector <std:: vector <unsigned int> > list_Models_;
    std::vector < std::vector <unsigned int> > unique_list_models_;
    std::vector<std::vector<unsigned int> > past_models_;
    std::vector<unsigned int> pastNModelsVisited_;

    std::list<unsigned> corrList;

    int yIndex = -1; // Index of corresponding y variable (HESS only)

};

#if _CUDA_
void startCula();
void stopCula();
#endif
#endif /* MCMC_H_ */
