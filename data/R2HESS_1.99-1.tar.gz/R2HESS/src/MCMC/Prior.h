/* This file is part of ESS-OO.
 *      Copyright (c) Marc Chadeau-Hyam (m.chadeau@imperial.ac.uk)
 *                    Leonardo Bottolo (l.bottolo@imperial.ac.uk)
 *                    David Hastie (d.hastie@imperial.ac.uk)
 *      2014
 *
 * Software designed and restructured by Loizos Markides (lm1011@ic.ac.uk)
 * ESS-OO is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ESS-OO is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ESS-OO.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef PRIOR_H_
#define PRIOR_H_

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <vector>
#include <math.h>

#include <gsl/gsl_vector.h>
#include <gsl/gsl_sort_vector.h>
#include <gsl/gsl_statistics_double.h>

class Prior {
public:
    Prior(){}
    virtual ~Prior(){}

    static double E_p_gam;
    static double Sd_p_gam;
    static double a;
    static double b;
    static double a_pi;
    static double b_pi;
    static std::vector<double> w;
    static double k;
    static double alpha;
    static double beta;

    static double Prob_mut;
    static double Prob_sel;
    static double Prob_crsv_r;
    static double Prob_DR;

    static void set(double E_p_gam_from_read,
		    double Sd_p_gam_from_read,
		    unsigned int pX,
		    unsigned int pY,
		    unsigned int nX,
		    double lambda,
		    double P_mutation_from_read,
		    double Prob_sel_from_read,
		    double P_crsv_r_from_read,
		    double P_DR_from_read);

    static void updateKwithRMSE(gsl_vector *vect_RMSE);

    static void display();
    static double get_delta();
private:
    static double delta;
};

#endif /* PRIOR_H_ */
