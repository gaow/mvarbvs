/* This file is part of ESS-OO.
 *      Copyright (c) Marc Chadeau-Hyam (m.chadeau@imperial.ac.uk)
 *                    Leonardo Bottolo (l.bottolo@imperial.ac.uk)
 *                    David Hastie (d.hastie@imperial.ac.uk)
 *      2014
 *
 * Software designed and restructured by Loizos Markides (lm1011@ic.ac.uk)
 * ESS-OO is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * ESS-OO is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with ESS-OO.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef DEFINITIONS_H_
#define DEFINITIONS_H_

#if _CUDA_
#include <cuda.h>
#include <cuda_runtime_api.h>
#include <cublas.h>
#include <cula.h>
#include <cuda_runtime.h>
#include "cublas_v2.h"
#endif

#include <cstddef>
#include <iostream>
#include <vector>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <iterator>
#include <string>
#include <gsl/gsl_fit.h>
#include <gsl/gsl_multifit.h>
#include <gsl/gsl_cdf.h>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_sort.h>
#include <gsl/gsl_sort_vector.h>
#include <gsl/gsl_permutation.h>
#include <gsl/gsl_linalg.h>
#include <gsl/gsl_blas.h>

//Enumeration Types Definitions

//enum ScoreLikelihoodStrategyType { Linear, GLM, Survival };

//enum ScorePenalizationStrategyType
//{
//    wmegaFixed, wmegaBetaBinomial, wmegaBernoulli
//};

//enum ScorePriorFlag
//{
    // If gPriorFlag we are using g-priors otherwise powered priors
    // If indepPriorFlag we are using independent priors
    // Even though g prior and independent prior are special cases of powered
    // priors, computations can be done more cheaply in those special cases
//    gPrior, Independent, Power
//};

#if _CUDA_

struct CUDAoptions
{
    cublasHandle_t handle;		// NULL
    unsigned int pXGam_threshold_low;	// 20
    unsigned int pXGam_threshold_high;	// 100
};

#endif

struct FSMHlog
{
    //Monitoring FSMH Moves

    unsigned int nb_model_tot;
    unsigned int nb_sweep;
    unsigned int nb_model_0_1;
    unsigned int nb_model_1_0;

    unsigned int nb_accept_tot;
    unsigned int nb_accept_0_1;
    unsigned int nb_accept_1_0;

    std::vector < unsigned int > list_sweep;
    std::vector < unsigned int > nb_model_per_sweep;
    std::vector < unsigned int > nb_model_per_sweep_0_1;
    std::vector < unsigned int > nb_model_per_sweep_1_0;
    std::vector < unsigned int > nb_accept_per_sweep;
    std::vector < unsigned int > nb_accept_per_sweep_0_1;
    std::vector < unsigned int > nb_accept_per_sweep_1_0;
};

struct AllExchangeLog
{
    //Monitoring All Exchange Moves
    unsigned int nb_sweep;
    std::vector <unsigned int> freq;
    unsigned int n_accept;
    std::vector < std::vector < unsigned int > > move_history;
};

struct DelayedRejectionLog
{
    //Monitoring DR Moves
    unsigned int nb_sweep;
    std::vector < unsigned int > freq;
    unsigned int n_accept;
    std::vector < std::vector < unsigned int > > move_history;
};

struct AdaptiveMHLog
{
    //Monitoring the sampling of g
    unsigned int nb_sweep;
    unsigned int nb_accept;
    std::vector < double > sample_history;
    std::vector < std::vector < double > > adapt_history;
};

struct GibbsLog
{
    //Monitoring Gibbs Moves

    unsigned int nb_sweep;
    unsigned int nb_model;
    unsigned int nb_0_1;
    unsigned int nb_1_0;
    std::vector < std::vector < unsigned int > > move_history;
};

struct CrossoverLog
{
    //Monitoring Crossover Moves
    unsigned int nb_sweep;
    unsigned int nb_model;
    unsigned int nb_accept;
    std::vector < unsigned int > n_nb_sweep_per_CM_move;
    std::vector < unsigned int > n_nb_accept_per_CM_move;
    std::vector < std::vector < unsigned int > > history;
};

struct TemperatureLog
{
    //Monitoring Temperature
    std::vector < std::vector < double > > history;
};

struct Timing{
    time_t begin;
    time_t current;
    clock_t start;
    clock_t end;
} ;

struct flags{
    // If gSampleFlag we are also sampling g
    bool gSampleFlag;	// true
    bool gInitFlag;	// false
    int priorType;	// gPrior
    int LikelihoodType; // Linear
    int PenalizationType;  // wmegaFixed
    bool standardizeFlag;  // true
    bool resumeRun;	// This and all following: false
    bool extendRun;	
    bool HistoryFlag;	
    bool Time_monitorFlag; 
    bool Out_full_Flag;
    bool Log_Flag;
    bool iso_T_Flag;
    bool cudaFlag;
    bool fixInit;
    bool postProcessOnly;
    bool run_finished;
    bool CMD_set_E_gam;
    bool CMD_set_S_gam;
    bool CMD_set_N_chain;
    bool EigenstorageFlag;
    bool includeSingleModels;  // true
    bool doYShuffle;	// false
};

struct OFS{
    std::ofstream f_out_FSMH;
    std::ofstream f_out_n_models_visited;
    std::ofstream f_out;
    std::ofstream f_out_n_vars_in;
    std::ofstream f_out_log_cond_post_per_chain;
    std::ofstream f_out_CM;
    std::ofstream f_out_AE;
    std::ofstream f_out_DR;
    std::ofstream f_out_g;
    std::ofstream f_out_g_adapt;
    std::ofstream f_out_Gibbs;
    std::ofstream f_out_t_tun;
    std::ofstream f_out_time;
    std::ofstream f_out_best_models;
    std::ofstream f_out_features;
    std::ofstream f_out_marg_gam;
};

struct SSS{
    std::ostringstream strStrOutFSMH;
    std::ostringstream strStrOut;
    std::ostringstream strStrOutNVarsIn;
    std::ostringstream strStrOutNModelsVisited;
    std::ostringstream strStrOutLogCondPostPerChain;
    std::ostringstream strStrOutCM;
    std::ostringstream strStrOutAE;
    std::ostringstream strStrOutDR;
    std::ostringstream strStrOutG;
    std::ostringstream strStrOutGAdapt;
    std::ostringstream strStrOutGibbs;
    std::ostringstream strStrOutTTun;
    std::ostringstream strStrOutTime;
};

struct IFS{
    std::fstream f_in;
    std::fstream f_in_n_models_visited;
    std::ifstream inputFile;
};

struct IOFN{// Files that need to be reopened either for input or output
    std::string resume;
    std::string rng;
};

#endif /* DEFINITIONS_H_ */
