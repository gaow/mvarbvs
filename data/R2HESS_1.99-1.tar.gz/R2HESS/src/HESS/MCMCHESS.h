/* This file is part of HESS-OO.
 *      Copyright (c) Habib Saadi (h.saadi@imperial.ac.uk)
 *                    Marc Chadeau-Hyam (m.chadeau@imperial.ac.uk)
 *                    Leonardo Bottolo (l.bottolo@imperial.ac.uk)
 *                    David Hastie (d.hastie@imperial.ac.uk)
 *      2014
 * Designed and restructured by Loizos Markides (lm1011@imperial.ac.uk)
 * HESS-OO is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * HESS-OO is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with HESS-OO.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef MCMCHESS_H_
#define MCMCHESS_H_

#include <vector>
#include "../MCMC/MCMC.h"
#include "ChainHESS.h"
#include "GlobalVariablesHESS.h"

#include <gsl/gsl_matrix.h>
#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_blas.h>
#include <gsl/gsl_linalg.h>
#include <gsl/gsl_statistics.h>

#include <gsl/gsl_math.h>
#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_blas.h>
#include <gsl/gsl_linalg.h>
#include <gsl/gsl_statistics.h>

class MCMCHESS: public MCMC {
public:
    
    friend class MCMCVector;
    
    MCMCHESS();
    virtual ~MCMCHESS();
    MCMCHESS(const MCMCHESS& copy);
    
    static double a_om_k_;
    static double b_om_k_;
    
    //Overloaded functions
    virtual void initialize_g(double g_init);
    
    void newSweep();
    void readMatrixY();

    //Initializers
    void initialize_k_prior();
    void initialize_HESS_Omega(unsigned int nBatch, double optimal, double ls, double omega_kmmin, double omega_kmmax, double omega_delta_n);
    void  Sample_Omega_k(std::vector < std::vector < double > > &Rho_PerCol,
			 std::vector < std::vector < double > > &Omega_PerLine,
			 unsigned int Response,
			 gsl_rng* RandomNumberGenerator);
    void update_average_omega(unsigned int idx,double new_omega,double coeff1,double coeff2);

    //Getters and setters
    void increase_count_visits_gamma(unsigned int var){Count_Visits_Gamma_kj_[var]++;}
    double get_chain_temperature(unsigned int chain_position);
    void get_gamma_vector_of_chain(std::vector < bool >* gam, unsigned int chain_position);
    Chain& get_chain(unsigned int chain){return chainsVector_[chain_idx_[chain]];}

    void initializeYTY();
void betaDraw(gsl_rng* rng, std::vector<gsl_matrix *> betaMean, std::vector<gsl_matrix*> betaMax, std::vector<gsl_matrix*> betaMin, std::vector<gsl_matrix*> betaCount, unsigned k);
    void invWishartDraw(gsl_rng *rng, gsl_matrix *draw, unsigned v, gsl_matrix *S);
    
protected:
    virtual void addChain(std::vector<bool> &vect_gam);
    double Logistic_Trans(double Omega);
    double Logistic_Trans_Inv(double sample_tmp);
    double Log_Pr_Omega_k(double x,
			  unsigned int Chain,
			  unsigned int Response);

    // Adaptation for Omega_k, need a matrix of AdMH objects
    std::vector < AdaptiveMH * > Omega_k_AdMH_;
    //vector < double > History_Omega_;
    std::vector < double > Average_Omega_k_j_;
    std::vector < unsigned int > Count_Visits_Gamma_kj_;

    gsl_matrix *YTY;
};

#endif /* MCMCHESS_H_ */
