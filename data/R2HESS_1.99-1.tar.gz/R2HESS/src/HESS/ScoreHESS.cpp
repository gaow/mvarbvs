/* This file is part of HESS-OO.
 *      Copyright (c) Habib Saadi (h.saadi@imperial.ac.uk)
 *                    Marc Chadeau-Hyam (m.chadeau@imperial.ac.uk)
 *                    Leonardo Bottolo (l.bottolo@imperial.ac.uk)
 *                    David Hastie (d.hastie@imperial.ac.uk)
 *      2014
 * Designed and restructured by Loizos Markides (lm1011@imperial.ac.uk)
 * HESS-OO is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * HESS-OO is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with HESS-OO.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "ScoreHESS.h"
#include "GlobalVariablesHESS.h"


ScoreHESS::ScoreHESS() {
    // TODO Auto-generated constructor stub
}

ScoreHESS::~ScoreHESS() {
    // TODO Auto-generated destructor stub
}

ScoreHESS *ScoreHESS::clone() {
    return new ScoreHESS(*this);
}

double ScoreHESS::PostProcessing_Marginal_wGprior(std::vector <unsigned int> &gamma_list_vars, // New algorithm
						  gsl_matrix * R2_Mat_GPriors,
						  gsl_matrix *matYTY,
						  gsl_matrix *mat_X,
						  double g,
						  double omega_k,
						  std::vector<double> &rho_j_V,
						  double log_omega_k,
						  std::vector<double> &log_rho_j_V,
						  std::vector<double> &log_1_omega_k_rho_j_V,
						  double Total,
						  double prior_k)
{
    //This funciton is used only when we run prostprocessing in HESS in order to
    //speed up the calculation of the score for all the unique models.
    // We compute p(Y|...)p(gamma|Omega)

    double log_posterior_term=0;
    double logMargLik=0;

    //*********************************
    //  Compute p(gamma|Omega)
    //*********************************

    double logPGam=0;
    unsigned int pXGam=0;
    pXGam=gamma_list_vars.size(); // number of variables in the model
    // New algorithm
    if(Settings.slowPostProc)
    {
        //Total is the sum of the logarithms
        logPGam=Total;
    }
    else
    {
        //Total is the sum of the rho_j's
        logPGam=-omega_k*Total;
    }

    //for (unsigned int j=0;j<pX;j++) //Old algorithm: we loop through all the vector
    // New loop: only the variables in are visited
    if (pXGam>0)
    {
        for (unsigned int count=0;count<pXGam;count++)
        {
            unsigned int j=gamma_list_vars[count];
	    
            // 1) Additive term
            // ****************
            if (Settings.memLimited)
            {
                logPGam=logPGam + log(omega_k * rho_j_V[j]);
            }
            else
            {
                // When we use pre-computed logs, we may run onto memory problems if p is very large...
                logPGam=logPGam + log_omega_k + log_rho_j_V[j];
            }
	    
            // 2) Substracted term
            // *******************
            if (Settings.slowPostProc) // Exact computations
            {
                if (Settings.memLimited)
                {
                    // Old algorithm
                    //logPGam=logPGam + log(1-omega_k * rho_j_V[j]);
		    
                    // New algorithm: substract from the whole total
                    logPGam=logPGam - log(1-omega_k * rho_j_V[j]);
                }
                else
                {
                    // Old algorithm
                    //logPGam=logPGam + log_1_omega_k_rho_j_V[j];
                    // New algorithm: substract from the whole total
                    logPGam=logPGam - log_1_omega_k_rho_j_V[j];
                }
            }
            else // Approximation log(1+u)=u+o(u) to speed up computations
            {
                // Old algorithm
                //logPGam=logPGam - omega_k * rho_j_V[j];

                // New algorithm: substract from the whole total
                logPGam=logPGam + omega_k * rho_j_V[j];
            }
        }
    }

    //*************************************************
    //  Compute the marginal likelihood: p(Y|...)
    //*************************************************
    logMargLik=Score::likelihoodStrategy_->getMarginalLikelihoodwGPrior(g,
									gamma_list_vars,
									matYTY,
									prior_k,
									R2_Mat_GPriors);

    //*********************************
    //  Gather results
    //*********************************
    log_posterior_term=logMargLik+logPGam;
    return log_posterior_term;
}


double ScoreHESS::getPriorGam(std::vector<unsigned int> &listVarsIn,
			      unsigned int pX)
{
    //Overloaded function that is used only in HESS
    double logPGam=0;

    std::vector<unsigned int> Gamma;
    Gamma.resize(pX);

    for (unsigned int j=0;j<listVarsIn.size();j++)
    {
    	Gamma[listVarsIn[j]] = 1;
    }

    for (unsigned int j=0;j<pX;j++)
    {
        if (Gamma[j]==1)
            logPGam=logPGam + log(omega_k_ * Rho_V_[j]);
        else
            logPGam=logPGam + log(1-omega_k_ * Rho_V_[j]);
    }

    return logPGam;
}
