/* This file is part of HESS-OO.
 *      Copyright (c) Habib Saadi (h.saadi@imperial.ac.uk)
 *                    Marc Chadeau-Hyam (m.chadeau@imperial.ac.uk)
 *                    Leonardo Bottolo (l.bottolo@imperial.ac.uk)
 *                    David Hastie (d.hastie@imperial.ac.uk)
 *      2014
 * Designed and restructured by Loizos Markides (lm1011@imperial.ac.uk)
 * HESS-OO is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * HESS-OO is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with HESS-OO.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <fstream>
#include <numeric>
#include "MCMCVector.h"
#include "AdaptiveMHHESS.h"
#include "../UtilityClasses/Settings.hpp"

double MCMCVector::c_rh_j_=0.0;
double MCMCVector::d_rh_j_=0.0;

using std::vector;

#define DEBUG 0

void MCMCVector::readData() {
    MCMCHESS::readMatrixX(Settings.Xfile);
    Settings.Xfile.close();
    Settings.nX = MCMCHESS::nX;
    Settings.pX = MCMCHESS::pX;

    readDataY(Settings.Yfile);
    Settings.Yfile.close();

    if (Settings.nX != Settings.nY)
	exitWithError("X and Y data files do not contain the same number of observations");
}

void MCMCVector::readDataY(std::istream &f) {
    unsigned long n = 0, rq = 0;
    std::string line;

    f >> n;   // Number of rows
    f >> rq;  // Number of columns

    // Eat the trailing newline
    getline(f, line);

    // Line containing list of number of conditions/tissues for each response
    unsigned int numCols = 0;
    vector <unsigned int > numConditions;

    getline(f, line);
    std::stringstream ss(line);

    int next_r;	  // Number of conditions for each response
    while(ss >> next_r) {
	numConditions.push_back(next_r);
	numCols += next_r;
    }

    // These tests catch most errors caused by non-positive integers or non-numeric chars.
    // Any non-numeric chars after the correct number of integers are ignored
    // and the program continues as normal
    if (numCols != rq || numConditions.size() > rq)
	exitWithError("Reading Y data: The sum of variables per response does not add up to the total number of variables. Check the first 3 lines of the Y data file.");

    n_responses_ = numConditions.size();
    Settings.nY = n;
    Settings.qY = n_responses_;

    // Initialise vector of MCMC objects
    mcmcVector_.resize(n_responses_);
    for (unsigned int k = 0; k < n_responses_; k++) {
	mcmcVector_[k].mat_Y = gsl_matrix_alloc(n, numConditions[k]);
	mcmcVector_[k].nY = n;
	mcmcVector_[k].pY = numConditions[k];
    }

    // Read the rest of the file
    for(unsigned int i = 0; i < n; i++) {
	if (! getline(f, line))
	    exitWithError("Y data file does not contain " + std::to_string(n) + " observations");

	std::stringstream ss(line);
	double val;
	
	for (unsigned int k = 0; k < n_responses_; k++)
	    for (unsigned int m = 0; m < numConditions[k]; m++) {
		
		if (! (ss >> val)) {
		    // Error reading value
		    if (ss.eof())
			exitWithError("Reading Y data: Observation " + std::to_string(i+1)
				       + " does not contain " + std::to_string(rq) + " elements");
		    else if (ss.bad())
			exitWithError("Unable to read from Y data file");
		    else
			exitWithError("Reading Y data: Invalid value at observation " + std::to_string(i+1)
				      + " response " + std::to_string(k+1) + " condition " + std::to_string(m+1));
		}
		gsl_matrix_set(mcmcVector_[k].mat_Y, i, m, val);
	    }
    }

    // Centre Y data
    for (unsigned int k = 0; k < n_responses_; k++)
      	MatrixManipulation::center_matrix_gsl(mcmcVector_[k].mat_Y);
    
#if _CUDA_
    for (unsigned int k = 0; k < n_responses_; k++)
	if (GlobalVariables::GlobalFlags.cudaFlag) 
	    mcmcVector_[k].readMatrixYGPU();
#endif
    
    Settings.rFirst = numConditions[0];

}

void MCMCVector::initialise() {

    Settings.seed = MCMC::initializeRandomNumberGenerator(Settings.seed);

    Score::setLikelihoodStrategy(Settings.likelihoodType);
    Score::setPenalizationStrategy(Settings.penalisationType);

    if (Settings.adaptiveWeightsFn == Settings.avgModelSize)
	getResponseWeights = &MCMCVector::avgModelSize;
    else if (Settings.adaptiveWeightsFn == Settings.avgR2)
	getResponseWeights = &MCMCVector::avgR2;
    else
	exitWithError("Programmer error: Invalid value of Settings.adaptiveWeightsFn");

    // TODO
    // We ignore user-supplied Egam/Sgam
    /*
    Settings.Egam = Settings.pX * 0.0025 + Settings.nConfounders;
    if (Settings.Egam < 1)
	Settings.Egam = 1;
    Settings.Sgam = Settings.pX * 0.0025;
    */    
    Settings.maxPGamma = Settings.Egam + Settings.Sgam * Settings.maxPGammaFactor;
    
    if(Settings.maxPGamma > MCMCHESS::nX)
	Settings.maxPGamma = MCMCHESS::nX;

    if (Settings.gSampleFlag & ! Settings.gInitFlag)
	// If we sample g, we ignore any gInit value
	Settings.gInit = Settings.nX;

    Prop_Active_ = Settings.activeY;
    n_chains_ = Settings.nChains;
    n_sweeps_ = Settings.numSweeps;

    Omega_PerLine_.resize(n_chains_);
    Rho_PerCol_.resize(n_chains_);
    r_square.resize(n_responses_);
    tailProbCounts.resize(MCMC::pX);
    count_visits.resize(n_responses_);
    for (auto &inner : count_visits)
	inner.resize(MCMC::pX);
    count_visits_active.resize(n_responses_);
    for (auto &inner : count_visits_active)
	inner.resize(MCMC::pX);

    if (Settings.outFlags.cbAccept)
	Settings.cbAcceptLine.resize(n_responses_ * n_chains_);
    if (Settings.outFlags.fsmhAccept)
	Settings.fsmhAcceptLine.resize(n_responses_ * 2);

    if(Settings.adaptiveSelection) {
	batchHistory.resize(n_responses_);
	for (unsigned int k = 0; k < n_responses_; k++)
	    batchHistory[k].resize(n_sweeps_);
    } else {
	// Indices to shuffle, for randomly selecting active transcripts
	activeYkInds_.resize(n_responses_);
	std::iota(activeYkInds_.begin(), activeYkInds_.end(), 0);
	
	// Set fixed size of active transcripts
	Active_Yk_.resize(floor(n_responses_ * Prop_Active_));
    }

    //if (Settings.outFlags.mpiSimple)
    //	activeTranscriptCounts.resize(n_responses_);

    // Main initialisation of MCMCHESS objects
    initialiseRhoAdMH();
    initialiseMCMCs();
    initialisePriors();
  
    Regression::Pvalue_enter = 1 - pow((1 - Settings.regrNpEnter), (1.0/MCMCHESS::pX));
    Regression::Pvalue_remove = 1 - pow((1 - Settings.regrNpRemove), (1.0/MCMCHESS::pX));

    // Calculate sum of squares for R^2 calculation
    totalSumOfSquares.resize(n_responses_);
    for (int i = 0; i < n_responses_; i++) {
	double mean = 0;
	double meanSSD = 0;
	MCMCHESS &currY = mcmcVector_[i];
	gsl_matrix* matY = currY.mat_Y;

	// Iterate over outcomes in this response
	for (int outcome = 0; outcome < currY.pY; outcome++) {
	    for (int j = 0; j < currY.nY; j++)
		mean += gsl_matrix_get(matY, j, outcome);
	    mean /= currY.nY;
	    
	    double sum = 0;
	    for (int j = 0; j < currY.nY; j++)
		sum += pow(gsl_matrix_get(matY, j, outcome) - mean, 2);

	    // SSD for this outcome
	    meanSSD += sum;
	}
	// In the multi-outcome case, we store the average SSD over all outcomes
	totalSumOfSquares[i] = meanSSD / currY.pY;
    }
}

void MCMCVector::initialiseRhoAdMH() {
    double Rho_M_min = -log(MCMC::pX) / (2*log(10));
    double Rho_M_max = log(MCMC::pX) / (2*log(10));
    double Rho_ls = Settings.gAdMH_ls;
    double Rho_delta_n = std::max(fabs(Rho_M_min - Rho_ls), fabs(Rho_M_max - Rho_ls));
    Rho_delta_n = Rho_delta_n / (MCMC::burn_in() / (double) Settings.gNBatch);

    Rho_j_AdMH_.resize(MCMC::pX);
    for (unsigned int j = 0; j < MCMC::pX; j++) {
        Rho_j_AdMH_[j].resize(n_chains_);
        for (unsigned int c = 0; c < n_chains_; c++) {
            Rho_j_AdMH_[j][c].n_batch = Settings.gNBatch;
            Rho_j_AdMH_[j][c].optimal = Settings.gAdMH_optimal;
            Rho_j_AdMH_[j][c].ls = Settings.gAdMH_ls;
            Rho_j_AdMH_[j][c].M[0] = Rho_M_min;
            Rho_j_AdMH_[j][c].M[1] = Rho_M_max;
            Rho_j_AdMH_[j][c].delta_n = Rho_delta_n;
        }
    }
}

void MCMCVector::initialiseMCMCs() {

    MCMC::burn_in_ = Settings.burnIn;

    double Omega_k_M_min = -log(n_responses_) / (2*log(10));
    double Omega_k_M_max = log(n_responses_) / (2*log(10));
    double Omega_k_ls = Settings.gAdMH_ls;
    double Omega_k_delta_n = std::max(fabs(Omega_k_M_min - Omega_k_ls), fabs(Omega_k_M_max - Omega_k_ls));

    for (unsigned int k = 0; k < n_responses_; k++) {
	mcmcVector_[k].yIndex = k;
	mcmcVector_[k].initializeFromRead(Settings.numSweeps, Settings.burnIn,
					  Settings.topNModels, Settings.nConfounders,
					  Settings.extendRun, Settings.nChains,
					  Settings.gibbsNbatch, Settings.maxPGamma,
					  Settings.gInit, -1, // time limit is ignored for HESS
					  Settings.seed);

	mcmcVector_[k].initialize_HESS_Omega(Settings.gNBatch, Settings.gAdMH_optimal, 
					     Settings.gAdMH_ls, Omega_k_M_min, 
					     Omega_k_M_max, Omega_k_delta_n);

	mcmcVector_[k].initializeAdaptiveMH(Settings.gNBatch, Settings.gAdMH_optimal,
					    Settings.gAdMH_ls, Settings.gMmin, Settings.gMmax);

	mcmcVector_[k].initializeCrossover(Settings.crossoverKmax);

	// Note: Both the 'initialise from file' and 'initialise from resume' options 
	// have yet to be implemented in HESS
	if(! Settings.initGamma) {
	    if (Settings.initRegression == GlobalSettings::simple) {
		mcmcVector_[k].createChainsfromSimple();
	    } else if (Settings.initRegression == GlobalSettings::stepwise) {
		mcmcVector_[k].createChainsfromRegression();
	    }
	} else {
	    // if initGamma is set then we don't do regression, but read from input instead
	    mcmcVector_[k].createChainsfromFixed();
	}

	mcmcVector_[k].initializeYTY();

	// Print initial gammas to file. All chains have the same initial gamma.
	const vector<bool> &gam = mcmcVector_[k].chainsVector_[0].gammas_;
	for (auto val : gam)
	    Settings.out.initGamma << val << " ";
	Settings.out.initGamma << endl;

	mcmcVector_[k].initializeTemperature(Settings.bt, Settings.at_under5k,
					     Settings.at_5k10k, Settings.at_over10k,
					     Settings.tempNbatch, Settings.mInput,
					     Settings.tempOptimal);

    	//History_g_[k][0] = mcmcVector_[k].g_;
    }

    if (Settings.initOmega == false) {
	// Set initial random omega values
	for (unsigned int c = 0; c < n_chains_; c++) {
	    Omega_PerLine_[c].resize(n_responses_);
	    for (unsigned int k = 0; k < n_responses_; k++) {
		double new_Omega = gsl_rng_uniform(MCMC::RandomNumberGenerator);
		Omega_PerLine_[c][k] = new_Omega;
		mcmcVector_[k].chainsVector_[c].score_->omega_k_ = new_Omega;
	    }
	}
    } else {
	// Read omega values from file
	vector < double > init_omega_k;
	std::ifstream inputFile(Settings.initOmegaName);
	if(! inputFile.is_open()) 
	    exitWithError("Input file for Omega_k not found");

	MatrixManipulation::Read_File_Double(inputFile, init_omega_k);
	inputFile.close();

	for (unsigned int c = 0; c < n_chains_; c++) {
	    Omega_PerLine_[c] = init_omega_k;
	    for (unsigned int k = 0; k < n_responses_; k++) 
		mcmcVector_[k].chainsVector_[c].score_->omega_k_ = init_omega_k[k];
	}
    }

    if (Settings.initRho == false) {
	// Set random initial rho vlaues
	for (unsigned int c = 0; c < n_chains_; c++) {
	    Rho_PerCol_[c].resize(MCMC::pX);
	    for (unsigned int j = 0; j < MCMC::pX; j++) {
		double new_Rho = gsl_rng_uniform(MCMC::RandomNumberGenerator);
		Rho_PerCol_[c][j] = new_Rho;
	    }
	}
    } else {
	// Read rho values from file
	vector < double > init_rho_j;
	std::ifstream inputFile(Settings.initRhoName);
	if(! inputFile.is_open()) 
	    exitWithError("Input file for Rho_j not found");

	MatrixManipulation::Read_File_Double(inputFile, init_rho_j);
	inputFile.close();

	for (unsigned int c = 0; c < n_chains_; c++)
	    Rho_PerCol_[c] = init_rho_j;
    }

    for (unsigned int k = 0; k < n_responses_; k++) {
	for (unsigned int c = 0; c < n_chains_; c++) {
	    mcmcVector_[k].chainsVector_[c].score_->Rho_V_.resize(MCMCHESS::pX);
	    copy(Rho_PerCol_[c].begin(), Rho_PerCol_[c].end(), 
		 mcmcVector_[k].chainsVector_[c].score_->Rho_V_.begin());
	}
    }

    // Write initial values to file
    if (Settings.outFlags.avMatrixOmega)
	Save_Average_Omega_k_j(0);
    if (Settings.outFlags.historyRho)
	Save_Rho_History();
    if (Settings.outFlags.historyOmega)
	Save_Omega_History();
    if (Settings.outFlags.historyG)
	Save_G_History();
}


// Priors for omega
void MCMCVector::initialisePriors() {
    // We just reuse the code, we are going to use only 2 parameters namely a_pi and b_pi,
    // from the Priors, that do not depend on PY or the regression vector
    // and which depend on E_p_gam_from_read and Sd_p_gam_from_read
    Prior::set(Settings.Egam, Settings.Sgam, MCMC::pX, 1, MCMC::nX, Score::lambda, Settings.pMutation, Settings.pSel, Settings.pCsrv, Settings.pDR);

    if (Settings.omegak_a < 0)
	MCMCHESS::a_om_k_ = Prior::a_pi;
    else 
	MCMCHESS::a_om_k_ = Settings.omegak_a;
    
    if (Settings.omegak_b < 0)
	MCMCHESS::b_om_k_ = Prior::b_pi;
    else
	MCMCHESS::b_om_k_ = Settings.omegak_b;

    c_rh_j_ = Settings.rhoj_c;
    d_rh_j_ = Settings.rhoj_d;

    for (unsigned int k = 0; k < n_responses_; k++)
    	mcmcVector_[k].initialize_k_prior();

    if (Settings.priorGalpha >= 0)
	// If value is not negative, it was set by the user at runtime
    	Prior::alpha = Settings.priorGalpha;
    else
    	if (Settings.singleG)
	    Prior::alpha = 0.5 * n_responses_ + n_responses_ - 1;
    	else
	    Prior::alpha = 0.5;
    
    if (Settings.priorGbeta >= 0)
    	Prior::beta = Settings.priorGbeta;
    else
    	if (Settings.singleG)
	    Prior::beta = 0.5 * mcmcVector_[0].nY * n_responses_;
    	else
	    Prior::beta = 0.5 * mcmcVector_[0].nY;

    if(! Settings.postProcOnly) {
	Prior::display();
	
	clog << "Omega parameters" << endl
	     << "\ta_om_k = " << MCMCHESS::a_om_k_ << endl
	     << "\tb_om_k = " << MCMCHESS::b_om_k_ << endl
	     << "\tc_rh_j = " << c_rh_j_ << endl
	     << "\td_rh_j = " << d_rh_j_ << endl;
	clog << endl << "g parameters" << endl
	     << "\tPr.g.a = " << Prior::alpha << endl
	     << "\tPr.g.b = " << Prior::beta << endl;
	clog << endl;
    }
}


void gslPrint(gsl_matrix* mat) {
    for (unsigned i = 0; i < mat->size1; i++)
	for (unsigned j = 0; j < mat->size2; j++)
	    Settings.out.mtBeta << gsl_matrix_get(mat, i, j) << " ";
}

void MCMCVector::run()
{
    clog << "**************** Begin MCMC loop ****************" << endl << endl;
   
    for (unsigned int k = 0; k < n_responses_; k++)
	mcmcVector_[k].firstSweep();

    if(Settings.adaptiveSelection)
	Update_Active_Adaptive_Scan(MCMC::RandomNumberGenerator, batchHistory, 0);
    
    // Iterate from 1, so periodic updates match user's 1-based perspective
    for (unsigned int sweep = 1; sweep < n_sweeps_ + 1; sweep++) {

	// Clear output data buffers
	if (Settings.outFlags.cbAccept)
	    std::fill(Settings.cbAcceptLine.begin(), Settings.cbAcceptLine.end(), 0);
	if (Settings.outFlags.fsmhAccept)
	    std::fill(Settings.fsmhAcceptLine.begin(), Settings.fsmhAcceptLine.end(), 0);
	
	// Update selection of transcripts
	if (! Settings.adaptiveSelection)
	    Update_Active_Yk(MCMC::RandomNumberGenerator);
	else
	    if (sweep % Settings.adaptBatchSize == 0)
		Update_Active_Adaptive_Scan(MCMC::RandomNumberGenerator, batchHistory, sweep);
	
	// 'Set up' the new sweep
	for (unsigned int k = 0; k < n_responses_; k++)
	    mcmcVector_[k].newSweep();
	
	// Update gammas
	for (unsigned int count=0; count < Active_Yk_.size(); count++) {
	    unsigned int k = Active_Yk_[count];
	    
	    if (Settings.verbose)
		clog << "Response " << k << ": ";
	    
	    mcmcVector_[k].update();
	    
	    if (Settings.verbose)
		clog << endl;
	    
	    for (unsigned int c = 0; c < n_chains_; c++) 
		mcmcVector_[k].get_chain(c).score_->set_omega_and_rho(Omega_PerLine_[c][k], Rho_PerCol_[c]);
	}

	// Update G parameter
	if(Settings.gSampleFlag) {
	    AdaptiveMHHESS::g_prop = 0.0;
	    AdaptiveMHHESS::run_test = false;
	    AdaptiveMHHESS::single_g_changed = false;

	    for (unsigned int k = 0; k < n_responses_; k++)
		mcmcVector_[k].runAdaptiveMH();

	    if(Settings.singleG) {
		AdaptiveMHHESS::run_test = true;
		mcmcVector_[0].runAdaptiveMH();
		//normalize g's for both active and non-active responses
		if (AdaptiveMHHESS::single_g_changed)
		    for (unsigned int k = 0; k < n_responses_; k++)
			mcmcVector_[k].set_g(AdaptiveMHHESS::g_prop);
	    }
	}

	// Update omega
	if(! Settings.fixOmega)
	    for (unsigned int k = 0; k < n_responses_; k++)
		mcmcVector_[k].Sample_Omega_k(Rho_PerCol_, Omega_PerLine_, k, MCMC::RandomNumberGenerator);

	// Update rho
	if(! Settings.fixRho)
	    Sample_Rho_j(sweep, MCMC::RandomNumberGenerator);

	// Propogate to chains
	if (Settings.fixOmega == false || Settings.fixRho == false)
	    for (unsigned int k = 0; k < n_responses_; k++)
		for (unsigned int c = 0; c < n_chains_; c++)
		    mcmcVector_[k].chain(c).score_->set_omega_and_rho(Omega_PerLine_[c][k], Rho_PerCol_[c]);
	
	// Sigma/beta for multiple tissues
	// (rFirst is number of tissues)
	if (Settings.rFirst > 1 && Settings.outFlags.mtBeta) {

	    vector<gsl_matrix*> betaMean(Settings.rFirst);
	    vector<gsl_matrix*> betaMax(Settings.rFirst);
	    vector<gsl_matrix*> betaMin(Settings.rFirst);
	    vector<gsl_matrix*> betaCount(Settings.rFirst);
	    for (unsigned i = 0; i < Settings.rFirst; i++) {
		betaMean[i] = gsl_matrix_alloc(Settings.pX, Settings.qY);
		betaMax[i] = gsl_matrix_alloc(Settings.pX, Settings.qY);
		betaMin[i] = gsl_matrix_alloc(Settings.pX, Settings.qY);
		betaCount[i] = gsl_matrix_alloc(Settings.pX, Settings.qY);

		gsl_matrix_set_zero(betaMean[i]);
		gsl_matrix_set_all(betaMax[i], -999);
		gsl_matrix_set_all(betaMin[i], 999);
		gsl_matrix_set_zero(betaCount[i]);
	    }
	    
	    for (unsigned int k = 0; k < n_responses_; k++)
		mcmcVector_[k].betaDraw(MCMC::RandomNumberGenerator, betaMean, betaMax, betaMin, betaCount, k);

	    for (unsigned i = 0; i < Settings.rFirst; i++) {
		gsl_matrix_div_elements(betaMean[i], betaCount[i]); 
		gslPrint(betaMean[i]);
		gslPrint(betaMax[i]);
		gslPrint(betaMin[i]);
		Settings.out.mtBeta << endl;
	    }
	    
	    
	    for (unsigned i = 0; i < Settings.rFirst; i++) {
		gsl_matrix_free(betaMean[i]);
		gsl_matrix_free(betaMax[i]);
		gsl_matrix_free(betaMin[i]);
		gsl_matrix_free(betaCount[i]);
	    }
	    
	}
	// Update scores
	for (unsigned int k = 0; k < n_responses_; k++)
	    mcmcVector_[k].updateAllScores();

	// Use sgamma to calculate R^2
	// For ease of coding, we output sgamma (an intermediate value) at this point
	if ((Settings.adaptiveSelection && Settings.adaptiveWeightsFn == Settings.avgR2)
	    || Settings.outFlags.rsquare || Settings.outFlags.sgamma) {
	
	    for (unsigned int k = 0; k < n_responses_; k++) {
		gsl_matrix* sgamma = mcmcVector_[k].getSGamma();
		double residualSumOfSquares = 0;

		// Mean of the diagonal of the sgamma matrix
		for (int outcome = 0; outcome < mcmcVector_[k].pY; outcome++)
		    residualSumOfSquares += gsl_matrix_get(sgamma, outcome, outcome);
		residualSumOfSquares /= mcmcVector_[k].pY;

		r_square[k] = 1 - residualSumOfSquares / totalSumOfSquares[k];

		if (Settings.outFlags.sgamma)
		    Settings.out.sgamma << residualSumOfSquares << " "; 
	    }

	    if (Settings.outFlags.sgamma)
		Settings.out.sgamma << endl;
	}

	// For adaptive transcript selection, record any necessary info for each iteration
	if (Settings.adaptiveSelection)
	    if (Settings.adaptiveWeightsFn == Settings.avgModelSize)
		updateHistory(batchHistory, sweep);
	    else if (Settings.adaptiveWeightsFn == Settings.avgR2)
		updateHistoryR2(batchHistory, sweep, r_square);

	// Write to file
	writeOutputPerIteration(sweep);
    }
}


void MCMCVector::writeOutputPerIteration(unsigned int sweep) {
    // Selected (active) transcripts
    if (Settings.outFlags.activeY) {
	int active = 0;
	for (int k = 0; k < n_responses_; k++) {
	    if (active < Active_Yk_.size() && Active_Yk_[active] == k) {
		Settings.out.activeY << "1 ";
		active++;
	    } else
		Settings.out.activeY << "0 ";
	}
	Settings.out.activeY << endl;
    }
    
    if (Settings.outFlags.avMatrixOmega && sweep > MCMC::burn_in())
	Save_Average_Omega_k_j(sweep);

    // Settings.out.adaptBatchWeights: Printed in the adaptive update function
    
    if (Settings.outFlags.cbAccept) {
	for (auto i : Settings.cbAcceptLine)
	    Settings.out.cbAccept << i << " ";
	Settings.out.cbAccept << endl;
    }

    if (Settings.outFlags.fsmhAccept) {
	for (auto i : Settings.fsmhAcceptLine)
	    Settings.out.fsmhAccept << i << " ";
	Settings.out.fsmhAccept << endl;
    }

    // Store gamma counts for output, only after burn_in
    if (Settings.outFlags.gammaCounts && sweep > MCMC::burn_in()) {
	for (unsigned int k = 0; k < n_responses_; k++) {
	    vector<unsigned int> gamma = mcmcVector_[k].chain(0).gammaVars();
	    for (auto var : gamma)
		count_visits[k][var]++;
	}
    }

    if (Settings.outFlags.gammaActiveCounts && sweep > MCMC::burn_in()) {
	for (auto k : Active_Yk_) {
	    vector<unsigned int> gamma = mcmcVector_[k].chain(0).gammaVars();
	    for (auto var : gamma)
		count_visits_active[k][var]++;
	}
    }

    if (Settings.outFlags.historyG)
	Save_G_History();
    
    if (Settings.outFlags.historyOmega)
	Save_Omega_History();
    
    if (Settings.outFlags.historyRho)
	Save_Rho_History();

    // Omega and rho ls values are written to file in the functions that calculate the values
    // We assume that all chains have the same, fixed, n_batch value
    if (Settings.outFlags.ls && sweep % Settings.gNBatch == 0)
	Settings.out.lsOmega << endl;

    // Print full models
    // Note: This file ignores counfounding variables in both the variable indices
    // and the total model size. So an 'empty' model will show size=0, not size=nConfounders.
    if (Settings.outFlags.modelsFull && sweep > MCMC::burn_in()) {
	for (unsigned int k = 0; k < n_responses_; k++) {
	    // Print number of vars, then the vars. 
	    // One line per sweep, so all transcripts are on one line.
	    vector<unsigned int> gamma = mcmcVector_[k].chain(0).gammaVars();
	    Settings.out.modelsFull << gamma.size() - Settings.nConfounders << " ";
	    for (unsigned j = Settings.nConfounders; j < gamma.size(); j++)
		Settings.out.modelsFull << gamma[j] << " ";
	}
	Settings.out.modelsFull << endl;
    }

    //if (Settings.outFlags.mpiSimple && sweep > MCMC::burn_in()) {
    //  for (auto k : Active_Yk_) 
    //	    activeTranscriptCounts[k]++;
    //}

    if (Settings.outFlags.mpiUnique && sweep > MCMC::burn_in()) {
	for (unsigned int k = 0; k < n_responses_; k++)
	    mcmcVector_[k].saveModelPerSweep();
    }

    // Note: This file ignores confounding variables in the model sizes.
    if (Settings.outFlags.modelSizes) {
	for (int k = 0; k < n_responses_; k++)
	    Settings.out.modelSizes << std::setw(3) << std::left << mcmcVector_[k].chain(0).modelSize() - Settings.nConfounders << " ";
	Settings.out.modelSizes << endl;
    }

    if (Settings.outFlags.rsquare) {
	for (unsigned int k = 0; k < n_responses_; k++)
	    Settings.out.rsquare << r_square[k] << " ";
	Settings.out.rsquare << endl;
    }

    // Tail probabilities
    if (Settings.outFlags.tailProbs && sweep > MCMC::burn_in()) {
	double thresh = 1.0;
	for (unsigned int j = 0; j < MCMC::pX; j++)
	    if (Rho_PerCol_[0][j] > thresh)
		tailProbCounts[j]++;
    }

    if (sweep % Settings.gammaCountInterval == 0)
	writePeriodicOutput(sweep);
    
    clock_t PreviousEnd= GlobalVariablesHESS::Time.end;
    GlobalVariablesHESS::Time.end = clock();
    double Elapsed = (GlobalVariablesHESS::Time.end-GlobalVariablesHESS::hesstime.Loop_Start_Time)/(double)(CLOCKS_PER_SEC);
    double remainingTime=((double) n_sweeps_-(double)sweep)/((double) sweep)*Elapsed;
    double durationSweep=(GlobalVariablesHESS::Time.end-PreviousEnd)/(double)(CLOCKS_PER_SEC);
    
    clog << "End of sweep " << sweep << "/" << n_sweeps_ << endl;
    clog << "Lasted " << Show_Time(durationSweep) << endl;
    clog << "Estimated Remaining Time: " << Show_Time(remainingTime) << endl << endl;
}

void MCMCVector::writePeriodicOutput(unsigned int sweep) {

    if (Settings.out.avMatrixOmega && sweep > MCMC::burn_in()) {
	Settings.out.avMatrixOmega << std::fixed << std::setprecision(6);
	Settings.out.avMatrixOmega << "Sweep " << sweep << endl;
	vector < vector < double > > omega_kj;
	for (unsigned int k = 0; k < n_responses_; k++)
	    omega_kj.push_back(mcmcVector_[k].Average_Omega_k_j_);
	MatrixManipulation::Write_Matrix(Settings.out.avMatrixOmega, omega_kj, "\t");
	// Reset to beginning so next write overwrites existing file
	Settings.out.avMatrixOmega.seekp(std::ios::beg);
    }

    if (Settings.outFlags.gammaCounts && sweep > MCMC::burn_in()) {
	Settings.out.gammaCounts << "Sweep " << sweep << endl;
	MatrixManipulation::Write_Matrix(Settings.out.gammaCounts, count_visits, "\t");
	Settings.out.gammaCounts.seekp(std::ios::beg);
    }

    if (Settings.outFlags.gammaActiveCounts && sweep > MCMC::burn_in()) {
	Settings.out.gammaActiveCounts << "Sweep " << sweep << endl;
	MatrixManipulation::Write_Matrix(Settings.out.gammaActiveCounts, count_visits_active, "\t");
	Settings.out.gammaActiveCounts.seekp(std::ios::beg);
    }

    if (Settings.outFlags.gammaProp) {
	Settings.out.gammaProp << "Sweep " << sweep << endl;
	Settings.out.gammaPropAdd << "Sweep " << sweep << endl;
	unsigned long acceptCount = 0;
	unsigned long rejectCount = 0;
	for (unsigned int k = 0; k < n_responses_; k++)
	    mcmcVector_[k].writeGammaProp();
	Settings.out.gammaProp.seekp(std::ios::beg);
	Settings.out.gammaPropAdd.seekp(std::ios::beg);
	// As the data in these files is additive, they won't reduce in size
    }

    if (Settings.gammaUpdateMove) {
	unsigned long acceptCount = 0, rejectCount = 0;
	for (unsigned int k = 0; k < n_responses_; k++)
	    mcmcVector_[k].updateAvgAcceptance(&acceptCount, &rejectCount);
	clog << "Gamma update move:\nTotal accepted: " << acceptCount << "; rejected: " << rejectCount << "; Acceptance proportion " << acceptCount / (double) (acceptCount + rejectCount) << endl;
    }

    if (Settings.outFlags.mpiSimple && sweep > MCMC::burn_in()) {
	Settings.out.mpiSimple << "Sweep " << sweep << endl;
	for (unsigned k = 0; k < n_responses_; k++) {
	    for (unsigned j = 0; j < Settings.pX; j++) 
		Settings.out.mpiSimple << std::fixed << std::setprecision(4) << count_visits[k][j] / (double) (sweep - MCMC::burn_in()) << "\t";
	    Settings.out.mpiSimple << endl;
	}
	Settings.out.mpiSimple.seekp(std::ios::beg);
    }

    if (Settings.outFlags.tailProbs && sweep > MCMC::burn_in()) {
	vector<double> tailProbs(MCMC::pX);
	Settings.out.tailProbs << "Sweep " << sweep << endl;
	for (unsigned int j = 0; j < MCMC::pX; j++)
	    tailProbs[j] = tailProbCounts[j] / (double) (sweep - MCMC::burn_in());
	for (auto prob : tailProbs)
	    Settings.out.tailProbs << std::fixed << std::setprecision(6) << prob << endl;
	Settings.out.tailProbs.seekp(std::ios::beg);
    }
}


void MCMCVector::writeFinalOutput() {

    writePeriodicOutput(Settings.numSweeps);

    // It is trivial to calculate these after the run, so we don't worry about
    // writing intermediate results during the simulation
    if (Settings.outFlags.historyOmega) {
	vector<vector<double> > History_Omega;
	MatrixManipulation::Read_File_Double(Settings.out.historyOmega, History_Omega);

	vector<double> Average_Omega_k;
	Average_Omega_k.resize(n_responses_);
	Compute_Average_Omega_History(Average_Omega_k, History_Omega);

	MatrixManipulation::Write_Vector(Settings.out.avOmegaK, Average_Omega_k);
    }

    if (Settings.outFlags.historyRho) {
	vector<vector<double> > History_Rho;
	MatrixManipulation::Read_File_Double(Settings.out.historyRho, History_Rho);

	vector<double> Average_Rho_j;
	Average_Rho_j.resize(MCMC::pX);
	Compute_Average_Rho_History(Average_Rho_j,
				    History_Rho,
				    MCMC::burn_in());
	MatrixManipulation::Write_Vector(Settings.out.avRhoJ, Average_Rho_j);
    }

    if (Settings.outFlags.mpiUnique) {
	// Compute simple marginal probabilities of inclusion
	vector<vector<double> > Simple_Marg_Prob;
	Simple_Marg_Prob.resize(n_responses_);
	for (unsigned int k = 0; k < n_responses_; k++) {
	    Simple_Marg_Prob[k].resize(MCMC::pX, 0);

	    mcmcVector_[k].getUniqueList();
	    int modelsize = mcmcVector_[k].list_Models_.size();
	    unsigned int nUniqueModels = mcmcVector_[k].unique_list_models_.size();

	    for (unsigned int model = 0; model < nUniqueModels; model++) {
		unsigned int nVarsIn = mcmcVector_[k].unique_list_models_[model][3];
		unsigned int offset = 4;
		if (nVarsIn > 0) {
		    for (unsigned int currVar = offset; currVar < nVarsIn + offset; currVar++) {
			unsigned int Name_Var = mcmcVector_[k].unique_list_models_[model][currVar];

			Simple_Marg_Prob[k][Name_Var]++;
		    }
		    
		}
	    }
	}
	MatrixManipulation::Write_Matrix(Settings.out.mpiUnique, Simple_Marg_Prob, "\t");
    }   
}

// Select transcripts at random
void MCMCVector::Update_Active_Yk(gsl_rng* rng) {
    /*
    Active_Yk_.resize(0);
    for (unsigned int k = 0; k < n_responses_; k++) {
        double U = gsl_rng_uniform(rng);
        if (U<Prop_Active_) 
            Active_Yk_.push_back(k);
    }
    */
 
    gsl_ran_shuffle(rng, &activeYkInds_[0], activeYkInds_.size(), sizeof(unsigned int));
    std::copy(activeYkInds_.begin(), activeYkInds_.begin() + Active_Yk_.size(), Active_Yk_.begin());
    std::sort(Active_Yk_.begin(), Active_Yk_.end());
}


// Adaptive Scanning scheme for transcript selection
// From: Richardson Bottolo Rosenthal 2010: Bayesian Models for Sparse Regression Analysis of High Dimensional Data, p9-10

// Update the 'Batch History' struct, which stores whatever info is used to calculate transcript weights
void MCMCVector::updateHistory(BatchData &batchHistory, int sweep) {
    // Average model size, in chain 0
    for (unsigned int k = 0; k < n_responses_; k++)
	batchHistory[k][sweep] = mcmcVector_[k].get_chain(0).getVariablesIncluded();
}

void MCMCVector::updateHistoryR2(BatchData &batchHistory, int sweep, vector<double> &r_square) {
    // R-square value, already calculated
    for (unsigned int k = 0; k < n_responses_; k++)
	batchHistory[k][sweep] = r_square[k];
}

// Functions to calculate transcript weight
vector<double> MCMCVector::avgModelSize(BatchData &batchHistory, int start, int sweep) {

    vector<double> r(n_responses_);
    for (int k = 0; k < n_responses_; k++) {
	int sum = 0;
	for (int s = start; s < sweep; s++)
	    sum += batchHistory[k][s];
	r[k] = sum / (double) (sweep - start);
    }
    return r;
}

vector<double> MCMCVector::avgR2(BatchData &batchHistory, int start, int sweep) {

    vector<double> r(n_responses_);
    for (int k = 0; k < n_responses_; k++) {
	double sum = 0;
	for (int s = start; s < sweep; s++) {
	    sum += batchHistory[k][s];
	}
	r[k] = sum / (double) (sweep - start);
    }
    return r;
}

void MCMCVector::Update_Active_Adaptive_Scan(gsl_rng* rng, BatchData &batchHistory, int sweep) {

    clog << "Updating adaptive scan block" << endl;

    Active_Yk_.resize(0);
    int startIter = floor(sqrt(sweep));

    // Weights w
    vector<double> w(n_responses_, 1);
    
    // During burn-in, the response values R are ignored, and all responses
    // have equal probability    
    if (sweep > MCMC::burn_in()) {
    
	// Calculate epsilon, which decays to control the 'memory' of past batches
	double epsilon = (1 / Settings.adaptC) * (MCMC::burn_in() / sweep) + 1e-3;

	// Get the R values, a measure of the responses, from the 'user-provided' function
	vector<double> r = (this->*getResponseWeights)(batchHistory, startIter, sweep);

	for (int k = 0; k < n_responses_; k++)
	    w[k] = (1 - epsilon) * r[k] + epsilon;
    }
    
    // Renormalise and cumulative sum
    vector<double> cumul(n_responses_);
    double w_sum = 0;
    for (int k = 0; k < n_responses_; k++) {
	w_sum += w[k];
	cumul[k] = w_sum;
    }
    for (int k = 0; k < n_responses_; k++) {
	cumul[k] /= w_sum;
	w[k] /= w_sum;
    }

    // Select at random without replacement
    // (Not the most efficient algorithm, but sufficient)
    int nIncluded = 0;
    vector<bool> included(n_responses_, false);
    while (nIncluded < n_responses_ * Prop_Active_) {
	double randVal = gsl_rng_uniform(rng);

	// Find the value in the vector of cumulative weights
	auto lower = std::lower_bound(cumul.begin(), cumul.end(), randVal);

	// 'lower' is a vector iterator; we need to get index
	int index = lower - cumul.begin();
	if (! included[index]) {
	    Active_Yk_.push_back(index);
	    included[index] = true;
	    nIncluded++;
	}
    }

    std::sort(Active_Yk_.begin(), Active_Yk_.end());

    // Print weights to file
    if (Settings.outFlags.adaptBatchWeights) {
	for (auto weight : w)
	    Settings.out.adaptBatchWeights << weight << " ";
	Settings.out.adaptBatchWeights << endl;
    }
}



// ****************************************
// WARNING: FOLLOWING METHOD WILL NOT WORK DUE TO REMOVAL OF LIST_MODELS_ ETC
// FROM MEMORY
// ****************************************

void MCMCVector::computeMPPI()
{
    if (Settings.doPostProc)
    {

	exitWithError("computeMPPI() with Settings.doPostProc == true will not work. History_g_ must be read from output file.");


	// Reload History_Rho_ 
	// (The file read resizes the matrix as required)
	vector<vector<double> > History_Rho;
	vector<vector<double> > History_Omega;
	
	clog << "----------------\ncomputeMPPI\n";
	
	MatrixManipulation::Read_File_Double(Settings.out.historyRho, History_Rho);
	MatrixManipulation::Read_File_Double(Settings.out.historyOmega, History_Omega);

        // Steps:
        // 1) Find unique models
        // 2) For each model, loop through the iterations and compute the
        //    marginal likelihood.
        // 2')Compute normalising constant for each iteration
        // 3) Find best marginal model
        // 4) Compute frequencies...
        // 5) Probability of inclusion: Sum over all the visited models

        //***************************************************************************
        //
        //                           Find unique models
        //
        //***************************************************************************
        clog << "       Listing unique models..." << endl;

        for (unsigned int k=0;k<n_responses_;k++)
        {

	    PostProcessing::getUniqueList(mcmcVector_[k].unique_list_models_,
					  mcmcVector_[k].list_Models_,
					  mcmcVector_[k].n_Models_visited_,
					  MCMC::burn_in(),
					  MCMC::pX,
					  mcmcVector_[k].nConfounders());
        }

        // We can stop write here the list of unique models and stop the main program.
        // That file could then be read by the post-processing program.

        //***************************************************************************
        //
        //                      Compute marginal posterior probabilities,
        //                         including the normalising constant
        //
        //***************************************************************************

        // Try and parallelise over all responses the expensive computations in one go.
        Matrix_Mod_Marg_Post_Prob_.resize(n_responses_);

        vector < vector < unsigned int> > Best_Models_Marginal;
        Best_Models_Marginal.resize(n_responses_);
        vector < double> Prob_Best_Models_Marginal;
        Prob_Best_Models_Marginal.resize(n_responses_);

        clog << endl <<"Post-processing computations of the log-posterior:" << endl;

	//***************************************************************************
	//
	//                           Decide here subsampling strategy for
	//                                  MPPI computations
	//
	//***************************************************************************

	// This will impact all the code below


	//***************************************************************************
	//
	//                           Precompute logs (1)
	//
	//***************************************************************************

        vector <double> Total_for_logs;
        Total_for_logs.resize(0);

        if (! Settings.slowPostProc) // Approximate computation of the logs
        {
            // With the approximation, the sum can be computed once and for all

            for (unsigned int sweep=MCMC::burn_in();sweep<n_sweeps_+1;sweep++)
            {
                double tfl =0.0;
                for (unsigned int j=0;j<MCMC::pX;j++)
                {
		    tfl+=History_Rho[sweep][j];
                }
                Total_for_logs.push_back(tfl);

            }
        }
        vector < vector <double> > log_rho_j_M;
        log_rho_j_M.resize(0);
        clog << "Memory_Limited = " << Settings.memLimited << endl;

        if (! Settings.memLimited)
        {
            for (unsigned int sweep=MCMC::burn_in();sweep<n_sweeps_+1;sweep++)
            {
                vector<double > log_rho_M;
                log_rho_M.resize(0);

                for (unsigned int j=0;j<MCMC::pX;j++)
                {
                    log_rho_M.push_back(log(History_Rho[sweep][j]));
                }
                log_rho_j_M.push_back(log_rho_M);
            }
        }

        for (unsigned int k=0;k<n_responses_;k++)
        {
            clog << "Response " << k+1 << " / " << n_responses_ << " ..." << endl;

            //***************************************************************************
            //
            //                           Precompute logs  (2)
            //
            //***************************************************************************
            vector <double> log_omega_k_V;
            log_omega_k_V.resize(0);

            vector < vector <double> > log_1_omega_k_rho_j_M;
            log_1_omega_k_rho_j_M.resize(0);

            if (! Settings.memLimited)
            {
                for (unsigned int sweep=MCMC::burn_in();sweep<n_sweeps_+1;sweep++)
                {
                    log_omega_k_V.push_back(log(History_Omega[sweep][k]));
                }

                if (Settings.slowPostProc)
                {
                    for (unsigned int sweep=MCMC::burn_in();sweep<n_sweeps_+1;sweep++)
                    {
                    	vector<double> log_1_omega_k_rho;
                    	double tfl = 0.0;
                    	log_1_omega_k_rho.resize(MCMC::pX);

                        for (unsigned int j=0;j<MCMC::pX;j++)
                        {
			    log_1_omega_k_rho[j]=log(1-History_Omega[sweep][k] * History_Rho[sweep][j]);
                            tfl+=log_1_omega_k_rho[j];
                        }
                        log_1_omega_k_rho_j_M.push_back(log_1_omega_k_rho);
                        Total_for_logs.push_back(tfl);
                    }
                }
            }
            else // when Limited Memory, only compute the sum of logs
            {
                if (Settings.slowPostProc)
                {
                    unsigned int Record_index=0;  // not great implementation
                    for (unsigned int sweep=MCMC::burn_in();sweep<n_sweeps_+1;sweep++)
                    {
                        Total_for_logs[Record_index]=0.0;
                        for (unsigned int j=0;j<MCMC::pX;j++)
                        {
                            //log_1_omega_k_rho_j_M[Record_index][j]=log(1-History_Omega[sweep][k] * History_Rho[sweep][j]);
                            Total_for_logs[Record_index]=Total_for_logs[Record_index]+
				log(1-History_Omega[sweep][k] * History_Rho[sweep][j]);
                        }
                        Record_index=Record_index+1;
                    }
                }
            }

            //***************************************************************************
            //
            //          Introduce normalising constants for each MCMC iteration
            //
            //***************************************************************************

            vector < double > Normalising_Const_per_Iter;
            // Add Shift_Constants to help compute exponentials of small numbers
            vector < double > Shift_per_Iter_Max;

            //Initialise Shift_per_Iter_Max
            unsigned int Nb_Records=n_sweeps_-MCMC::burn_in()+1;

            Shift_per_Iter_Max.resize(Nb_Records);

            for(unsigned int Index_Record=0;Index_Record<Nb_Records;Index_Record++)
            {
                Shift_per_Iter_Max[Index_Record]=-1e10;
            }

            //gsl_matrix * Data_Y_k=Vector_Data_Y[k];

            unsigned int nUniqueModels=mcmcVector_[k].unique_list_models_.size();

            // For parallelisation:
            //vector < double> log_Post;

            //In the meantime:
            Matrix_Mod_Marg_Post_Prob_[k].resize(nUniqueModels);

            // Temporary matrix to store the logs before computing exponentials
            // and normalising constants
            vector < vector < double > > logPost_tmp_Mat;
            logPost_tmp_Mat.resize(nUniqueModels);

            //***************************************************************************
            //
            //                             LOOP 1:
            //
            //              For each model, compute its MC LOG-posterior
            //
            //  Preliminary:
            //  Compute Y'Y and store it
            //***************************************************************************

            unsigned int pY=mcmcVector_[k].mat_Y->size2;
            gsl_matrix * matYTY=gsl_matrix_calloc(pY,pY);
            gsl_blas_dgemm(CblasTrans,CblasNoTrans,1.0,mcmcVector_[k].mat_Y,
			   mcmcVector_[k].mat_Y,0.0,matYTY);

            // Memory LEAK IN THE FOLLOWING LOOP
            for(unsigned int model=0;model<nUniqueModels;model++)
            {
                //***************************************************************************
                //
                //                              Build Gamma
                //
                //***************************************************************************

                unsigned int nVarsIn,offset;

                nVarsIn=mcmcVector_[k].unique_list_models_[model][3];
                offset=4;

                vector < bool > gamma;
                vector < unsigned int > gamma_list_vars;
                gamma.resize(MCMC::pX);
                gamma_list_vars.resize(0);
                for (unsigned int j=0;j<gamma.size();j++)
                {
                    gamma[j]=0;
                }

                if(nVarsIn>0)
                {
		    for(unsigned int currVar=offset;currVar<nVarsIn+offset;currVar++)
		    {
			unsigned int Variable_Explicit=mcmcVector_[k].unique_list_models_[model][currVar];
			gamma[Variable_Explicit]=1;
			gamma_list_vars.push_back(Variable_Explicit);
		    }
                }

                //***************************************************************************
                //
                //          Store the R2 used in the marginal likelihood computations,
                //                                  as well as Y'Y
                //
                //***************************************************************************

                gsl_matrix * R2_Mat_GPriors=gsl_matrix_calloc(pY,pY);

                //clog << "Compute Residual Matrix..." << endl;
                Score::Get_R2_Mat_GPriors(R2_Mat_GPriors,
					  gamma,
					  MCMC::mat_X,
					  mcmcVector_[k].mat_Y);

                //clog << "Start Postprocessing MCMC Loop..." << endl;
                unsigned int Index_Record=0;
                // We run only after burnin
                for (unsigned int sweep=MCMC::burn_in();sweep<n_sweeps_+1;sweep++)
                {
                    Index_Record=sweep-MCMC::burn_in();

                    //***************************************************************************
                    //
                    //                  Compute p(Y|...).p(gamma|Omega)
                    //              For the moment, only coded for the g-priors
                    //
                    //***************************************************************************

		    double log_posterior_term=0.0;
		    // We precompute the sum of logs once and for all
		    double g_value;
		    // TODO: Read g from file
		    //g_value=History_g_[k][sweep];

		    log_posterior_term=ScoreHESS::PostProcessing_Marginal_wGprior(
				gamma_list_vars, // new algorithm
				R2_Mat_GPriors,
				matYTY,
				MCMC::mat_X,
				g_value,
				History_Omega[sweep][k],
				History_Rho[sweep],
				log_omega_k_V[Index_Record], // CAREFUL !
				log_rho_j_M[Index_Record], // CAREFUL !
				log_1_omega_k_rho_j_M[Index_Record], //CAREFUL !
				Total_for_logs[Index_Record],//CAREFUL !
				mcmcVector_[k].k_prior_);

		    logPost_tmp_Mat[model].push_back(log_posterior_term);
		    //Update the overall maximum
		    Shift_per_Iter_Max[Index_Record]=std::max(Shift_per_Iter_Max[Index_Record],
							 logPost_tmp_Mat[model][Index_Record]);

		    //clog << "Shift_per_Iter_Max[" << 0 << "] = " << Shift_per_Iter_Max[0] << endl;

                }// end for MCMC iterations
                //clog << "End Postprocessing MCMC Loop." << endl;
                gsl_matrix_free(R2_Mat_GPriors);
            }// end LOOP 1: we have computed all the marginal likelihood terms
            gsl_matrix_free(matYTY);

            //***************************************************************************
            //
            //                              LOOP 2:
            //
            //            For each MCMC iteration, compute the normalising constant,
            //               using the shift factor at the corresponding iteration.
            //
            //***************************************************************************

            Normalising_Const_per_Iter.resize(Nb_Records);
            for (unsigned int Record=0;Record<Nb_Records;Record++)
            {
                Normalising_Const_per_Iter[Record]=0.0;
                for(unsigned int model=0;model<nUniqueModels;model++)
                {
                    Normalising_Const_per_Iter[Record] += exp(logPost_tmp_Mat[model][Record]-Shift_per_Iter_Max[Record]);
                    //DEBUG
                    //clog << "Normalising_Const_per_Iter[" << Record << "] = " << Normalising_Const_per_Iter[Record] << endl;
                }
            }

            //***************************************************************************
            //
            //                                  LOOP 3:
            //
            //              For each model, compute its posterior probability,
            //             using the normalising constant AND the shift constant
            //                      also, find the Best marginal model
            //
            //***************************************************************************

            for(unsigned int model=0;model<nUniqueModels;model++)
            {
                double post_prob=0.0;
                for (unsigned int Record=0;Record<Nb_Records;Record++)
                {
                    post_prob=post_prob+
			(exp(logPost_tmp_Mat[model][Record]-Shift_per_Iter_Max[Record])
			 / Normalising_Const_per_Iter[Record]);
                    //DEBUG
                    //clog << "post_prob = " << post_prob << endl;
                }
                // MCMC average:
                post_prob=post_prob/((double)Nb_Records);

                Matrix_Mod_Marg_Post_Prob_[k][model]=post_prob;
            }

            // Find the best marginal model
            //*****************************
            unsigned int Best_Mod_Marg_ind=0;
            double Best_Prob=0.0;
            for (unsigned int model=0;model<nUniqueModels;model++)
            {
                if (Matrix_Mod_Marg_Post_Prob_[k][model]>Best_Prob)
                {
		    Best_Prob=Matrix_Mod_Marg_Post_Prob_[k][model];
		    Best_Mod_Marg_ind=model;
                }
            }

            //Save the best model:
            //*******************
            unsigned int nVarsIn=mcmcVector_[k].unique_list_models_[Best_Mod_Marg_ind][3];
            unsigned int offset=4;
            if(nVarsIn>0)
            {
                Best_Models_Marginal[k].resize(nVarsIn);

                for(unsigned int currVar=offset;currVar<nVarsIn+offset;currVar++)
                {
		    //Best_Models_Marginal[k][currVar-offset]=
		    //mcmcVector_[k].unique_list_models_[Best_Mod_Marg_ind][currVar];
		    
		    //CORRECTION:
		    Best_Models_Marginal[k][currVar-offset]=
			mcmcVector_[k].unique_list_models_[Best_Mod_Marg_ind][currVar]+1;

                }
            }

            Prob_Best_Models_Marginal[k]=Best_Prob;

        }// end for k

        //***************************************************************************
        //
        //              Compute frequencies. reweighted ?!?
        //              ...
        //
        //***************************************************************************


        //***************************************************************************
        //
        //                  Compute Marginal probabilities of inclusion
        //
        //***************************************************************************

        clog << endl << "Compute Marginal probabilities of inclusion..." << endl;

        vector < vector < double > > Marg_Prob_Inclusion;
        Marg_Prob_Inclusion.resize(n_responses_);
        for (unsigned int k=0;k<n_responses_;k++)
        {
            Marg_Prob_Inclusion[k].resize(MCMC::pX);
            for (unsigned int j=0;j<MCMC::pX;j++)
            {
                Marg_Prob_Inclusion[k][j]=0;
            }

            unsigned int nUniqueModels=mcmcVector_[k].unique_list_models_.size();

            for (unsigned int model=0;model<nUniqueModels;model++)
            {
                unsigned int nVarsIn=mcmcVector_[k].unique_list_models_[model][3];
                unsigned int offset=4;
                if(nVarsIn>0)
                {
                    for(unsigned int currVar=offset;currVar<nVarsIn+offset;currVar++)
                    {
                        unsigned int Name_Var=mcmcVector_[k].unique_list_models_[model][currVar];
                        Marg_Prob_Inclusion[k][Name_Var]=Marg_Prob_Inclusion[k][Name_Var]+
			    Matrix_Mod_Marg_Post_Prob_[k][model];
                    }
                }
            }
        }

       
	// Compute simple marginal probabilities of inclusion
	vector<vector<double> > Simple_Marg_Prob;
	Simple_Marg_Prob.resize(n_responses_);
	for (unsigned int k = 0; k < n_responses_; k++) {
	    Simple_Marg_Prob[k].resize(MCMC::pX, 0);

	    int modelsize = mcmcVector_[k].list_Models_.size();
	    unsigned int nUniqueModels = mcmcVector_[k].unique_list_models_.size();

	    for (unsigned int model = 0; model < nUniqueModels; model++) {
		unsigned int nVarsIn = mcmcVector_[k].unique_list_models_[model][3];
		unsigned int offset = 4;
		if (nVarsIn > 0) {
		    for (unsigned int currVar = offset; currVar < nVarsIn + offset; currVar++) {
			unsigned int Name_Var = mcmcVector_[k].unique_list_models_[model][currVar];

			Simple_Marg_Prob[k][Name_Var]++;
		    }
		    
		}
	    }
	}
	
	
        /*
	  ##############################################################################

	  Output MPPI

	  ##############################################################################
        */
        std::string Field_Separator="\t";

	clog << endl << "Writing post-processing output" << endl << endl;

	// Best model for each response (best in the marginal sense)
	if (Settings.outFlags.bestModels) {
	    MatrixManipulation::Write_Matrix(Settings.out.bestModels, Best_Models_Marginal, Field_Separator);

	// Posterior Probability for each the best model for each k
	    MatrixManipulation::Write_Vector(Settings.out.bestModelsProbs, Prob_Best_Models_Marginal);
	}

	// Marginal probability of inclusion for each gamma_kj
	if (Settings.outFlags.mpiComplex)
	    MatrixManipulation::Write_Matrix(Settings.out.mpiComplex, Marg_Prob_Inclusion,
					 Field_Separator);
	
	// Simple marginal probabilities
	if (Settings.outFlags.mpiSimple)
	    MatrixManipulation::Write_Matrix(Settings.out.mpiSimple, Simple_Marg_Prob, Field_Separator);

	//GlobalVariablesHESS::hessofs.Output_File_Best_Models_Marg.close();
	//GlobalVariablesHESS::hessofs.Output_File_Prob_Best_Models_Marg.close();
	//GlobalVariablesHESS::hessofs.Output_File_Marg_Prob_Incl.close();
	//GlobalVariablesHESS::hessofs.Output_File_Simple_MPI.close();
    }
}

void MCMCVector::outputPosterior()
{
    // Content of the file:
    // 1st column: index of the response
    // 2nd column: posterior probability of the model in question
    // other columns: list of variables in the model
    std::string Field_Separator="\t";

    for (unsigned int k=0;k<n_responses_;k++)
    {
	for(unsigned int model=0;model<mcmcVector_[k].unique_list_models_.size();model++)
	{
	    unsigned int nVarsIn,offset;

	    nVarsIn=mcmcVector_[k].unique_list_models_[model][3];
	    offset=4;

	    if (Settings.outFlags.modelPostProb) {

		Settings.out.modelPostProb << k+1 << Field_Separator << Matrix_Mod_Marg_Post_Prob_[k][model];
		
		if(nVarsIn>0)
		    {
			for(unsigned int currVar=offset;currVar<nVarsIn+offset;currVar++)
			    {
				Settings.out.modelPostProb << Field_Separator << mcmcVector_[k].unique_list_models_[model][currVar]+1;
			    }
		    }
		Settings.out.modelPostProb << endl;
	    }
	}
    }

    //GlobalVariablesHESS::hessofs.Output_File_Models_Prob.close();

}





void MCMCVector::Save_G_History() {
    if (Settings.singleG)
	// We only write the first value to file
	Settings.out.historyG << mcmcVector_[0].g_ << endl;
    else {
	for (unsigned int k = 0; k < n_responses_; k++)
	    Settings.out.historyG << mcmcVector_[k].g_ << " ";
	Settings.out.historyG << endl;
    }
}

void MCMCVector::Save_Rho_History() {
    // We save only the first chain
    MatrixManipulation::Write_Vector_Line(Settings.out.historyRho, Rho_PerCol_[0], "\t");
}

void MCMCVector::Save_Omega_History() {
    MatrixManipulation::Write_Vector_Line(Settings.out.historyOmega, Omega_PerLine_[0], "\t");
}

void MCMCVector::Save_Average_Omega_k_j(unsigned int sweep) {
    // We save only the first chain
    unsigned int Chain=0;

    unsigned int pX=Rho_PerCol_[Chain].size();
    unsigned int Nb_Resp=Omega_PerLine_[Chain].size();

    double N=(double) (sweep-MCMC::burn_in());
    double Coeff_1=N/(N+1);
    double Coeff_2=1.0/(N+1);

    for (unsigned int k=0;k<Nb_Resp;k++)
    {
        for (unsigned int j=0;j<pX;j++)
        {
            double New_Omega_kj=Omega_PerLine_[Chain][k]*Rho_PerCol_[Chain][j];

            mcmcVector_[k].update_average_omega(j,New_Omega_kj,Coeff_1,Coeff_2);
        }
    }
}

void MCMCVector::Compute_Average_Omega_History(vector<double> &average, vector<vector<double> > history) {
    average.resize(n_responses_);

    for (unsigned int j=0;j<n_responses_;j++)
    {
        average[j]=0.0;
        for (unsigned int sweep=MCMC::burn_in();sweep<n_sweeps_+1;sweep++)
        {
            average[j]=average[j] + history[sweep][j] /
		((double)(n_sweeps_+1-MCMC::burn_in()));
        }
    }
}


void MCMCVector::Sample_Rho_j(unsigned int sweep, gsl_rng* rng) {

    // Chains loop is outer, because chains are independent
    for (unsigned int c = 0; c < n_chains_; c++) {

	const vector<double> &omega_c = Omega_PerLine_[c];

	// Current rho
	vector<double> &curr_rho = Rho_PerCol_[c];
	vector<double> prop_rho(MCMC::pX);
	vector<bool> failed(MCMC::pX, false);

	// Calculate proposed Rho
	for (unsigned int j = 0; j < MCMC::pX; j++) {
	    double normMean = log(curr_rho[j]);
	    double normSD = exp(Rho_j_AdMH_[j][c].ls);
	    prop_rho[j] = exp(normMean + gsl_ran_gaussian(rng, normSD));

	    // Check for max omega > 1; proposal is rejected without calculating acceptance
	    for (unsigned int k = 0; k < n_responses_; k++)
		if (prop_rho[j] * omega_c[k] > 1) {
		    failed[j] = true;
		    break;
		}
	}

	// Calculate acceptance ratios
	vector<double> logPGamJ_curr(MCMC::pX, 0);
	vector<double> logPGamJ_prop(MCMC::pX, 0);
	for (unsigned int k = 0; k < n_responses_; k++) {
	    Chain &ch = mcmcVector_[k].get_chain(c);
	    double temp = ch.getCurrentTemperature();
	    for (unsigned int j = 0; j < MCMC::pX; j++) {
		if (failed[j])
		    continue;
		if (ch.gammas_[j]) {
		    logPGamJ_curr[j] += log(omega_c[k] * curr_rho[j]) / temp;
		    logPGamJ_prop[j] += log(omega_c[k] * prop_rho[j]) / temp;
		} else {
		    logPGamJ_curr[j] += log(1 - omega_c[k] * curr_rho[j]) / temp;
		    logPGamJ_prop[j] += log(1 - omega_c[k] * prop_rho[j]) / temp;
		}
	    }
	}

	for (unsigned int j = 0; j < MCMC::pX; j++) {
	    // Update sweep for all j, regardless of failure
	    Rho_j_AdMH_[j][c].G_tilda_n_sweep++;
	    Rho_j_AdMH_[j][c].G_tilda_n_sweep_ins++;

	    if (failed[j])
		continue;

	    double logJ_curr = log(curr_rho[j]);
	    double logJ_prop = log(prop_rho[j]);

	    double logPRhoJ_curr = (c_rh_j_ - 1) * logJ_curr - curr_rho[j] / d_rh_j_;
	    double logPRhoJ_prop = (c_rh_j_ - 1) * logJ_prop - prop_rho[j] / d_rh_j_;

	    double res_curr = logPGamJ_curr[j] + logPRhoJ_curr + logJ_curr;
	    double res_prop = logPGamJ_prop[j] + logPRhoJ_prop + logJ_prop;

	    //logPGamJ_curr[j] += (c_rh_j_ - 1) * logJ_curr - curr_rho[j] / d_rh_j_ + logJ_curr;
	    //logPGamJ_prop[j] += (c_rh_j_ - 1) * logJ_prop - prop_rho[j] / d_rh_j_ + logJ_prop;

	    double alpha_rho_j = exp(res_prop - res_curr);
	    
	    // Accept/reject
	    double U = gsl_rng_uniform(rng);

	    if (U > alpha_rho_j)
		// Fail; do nothing
		continue;
	
	    // Update
	    Rho_PerCol_[c][j] = prop_rho[j];
	    Rho_j_AdMH_[j][c].G_tilda_accept++;
	    Rho_j_AdMH_[j][c].G_tilda_accept_ins++;
	    
	}

	// Adapt AdMH for all vars
	for (unsigned int j = 0; j < MCMC::pX; j++)
	    if (sweep % Rho_j_AdMH_[j][c].n_batch == 0) {
		Rho_j_AdMH_[j][c].updateLS(sweep);
		if (Settings.outFlags.ls)
		    Settings.out.lsRho << Rho_j_AdMH_[j][c].ls << " ";
	    }
    }
 
    // Assumes that all chains have the same n_batch value
    if (sweep%Rho_j_AdMH_[0][0].n_batch==0)
	if (Settings.outFlags.ls)
	    Settings.out.lsRho << endl;   
}


#if 0
void  MCMCVector::Sample_Rho_j(unsigned int sweep, gsl_rng* RandomNumberGenerator)
{
    double Curr_Rho_j;
    double Prop_Rho_j;
    double norm_mean;
    double norm_sd;
    double sample_tmp;
    double Alpha_Rho_j;

    vector<double> * Omega_V;

    for (unsigned int Variable=0;Variable<MCMC::pX;Variable++)
    {
        for (unsigned int Chain=0;Chain<n_chains_;Chain++)
        {
            if (DEBUG)
            {
		clog << "Chain " << Chain << " and Variable " << Variable << endl;
	    }

	    // 1) For each chain and Covariate, propose a Rho. If violates conditions, reject it

            Curr_Rho_j=Rho_PerCol_[Chain][Variable];
            Omega_V=&(Omega_PerLine_[Chain]);

            norm_mean=log(Curr_Rho_j);
            norm_sd=exp(Rho_j_AdMH_[Variable][Chain].ls);

            sample_tmp=norm_mean +  gsl_ran_gaussian(RandomNumberGenerator, norm_sd );

            Prop_Rho_j=exp(sample_tmp);

            double Max_Omega=0;
            for (unsigned int k=0;k<n_responses_;k++)
            {
                Max_Omega=std::max(Max_Omega,Prop_Rho_j * (*Omega_V)[k]);
            }

            bool Failed=false;
            if (Max_Omega>1)
            {
                //Reject
                Failed=true;
            }

            if (DEBUG)
            {
                clog << "Failed=" << Failed << endl;
                clog << "Max_Omega=" << Max_Omega << endl;
                clog << "Prop_Rho_j=" << Prop_Rho_j << endl;
            }

            if (Failed==false)
            {
                // 2) Compute the acceptance probability
                double Log_P_Curr_Rj=Log_Pr_Rho_j(Curr_Rho_j,Omega_V,Chain,Variable);
                double Log_P_Prop_Rj=Log_Pr_Rho_j(Prop_Rho_j,Omega_V,Chain,Variable);

                Alpha_Rho_j=exp(Log_P_Prop_Rj-Log_P_Curr_Rj);
                Alpha_Rho_j=std::min(1.0,Alpha_Rho_j);

                // 3) Accept / Reject
                double U = 1;
                U = gsl_rng_uniform(RandomNumberGenerator);

                if (U>Alpha_Rho_j)
                {
                    Failed=true;
                }
            }

            if (DEBUG)
            {
		clog << "Alpha_Rho_j=" << Alpha_Rho_j << "   Prop_Rho_j="
		  << Prop_Rho_j << endl;
	    }

	    // 4) Update
            if (Failed==false)
            {
                Rho_PerCol_[Chain][Variable]=Prop_Rho_j;
		Rho_j_AdMH_[Variable][Chain].G_tilda_accept++;
		Rho_j_AdMH_[Variable][Chain].G_tilda_accept_ins++;
                if (DEBUG) {
		    clog << "Move accepted, New Rho=" << Rho_PerCol_[Chain][Variable] << endl;
		}
            }
            else
            {
		if (DEBUG) {
		    clog << "Move refused, New Rho=" << Rho_PerCol_[Chain][Variable] << endl;
		}
            }

	    Rho_j_AdMH_[Variable][Chain].G_tilda_n_sweep++;
	    Rho_j_AdMH_[Variable][Chain].G_tilda_n_sweep_ins++;

	    // 5) Adapt
            if (sweep%Rho_j_AdMH_[Variable][Chain].n_batch==0) {
		Rho_j_AdMH_[Variable][Chain].updateLS(sweep);
		if (Settings.outFlags.ls)
		    Settings.out.lsRho << Rho_j_AdMH_[Variable][Chain].ls << " ";
            }
        }
    }

    // Assumes that all chains have the same n_batch value
    if (sweep%Rho_j_AdMH_[0][0].n_batch==0)
	if (Settings.outFlags.ls)
	    Settings.out.lsRho << endl;
   
}
#endif

double MCMCVector::Log_Pr_Rho_j(double x,
				vector<double> * Omega_V,
				unsigned int chain,
				unsigned int Variable)
{
    if (x<0)
    {
        clog << "Error in Log_Pr_Rho_j, x outside range [0,infinity)" << endl;
        exit(-1);
    }

    double Omega_k;
    double Temp;
    unsigned int gamma_kj;
    double Log_P_Gam_j=0;
    for (unsigned int Response=0;Response<n_responses_;Response++)
    {
        Omega_k=(*Omega_V)[Response];

	Chain &currChainObj = mcmcVector_[Response].get_chain(chain);

	//gamma_kj= mcmcVector_[Response].get_chain(Chain).get()->gammas_[Variable];
	gamma_kj = currChainObj.gammas_[Variable];

	//Temp=mcmcVector_[Response].get_chain_temperature(Chain);
	Temp = currChainObj.getCurrentTemperature();

        if (gamma_kj==1)
        {
            Log_P_Gam_j=Log_P_Gam_j+log(Omega_k*x)/Temp;
        }
        else
        {
            Log_P_Gam_j=Log_P_Gam_j+log(1-Omega_k*x)/Temp;
        }
    }

    double Log_J=log(x);

    double Log_P_Rho_j=(c_rh_j_-1)*log(x)-x/d_rh_j_;
    //double Log_P_Rho_j=(c-1)*log(x)-x/d-gsl_sf_lngamma(c)-c*log(d);

    double Res=Log_P_Gam_j+Log_P_Rho_j+Log_J;

    return Res;
}

void MCMCVector::Compute_Average_Rho_History(vector<double> &Average,
					     vector< vector< double> > Histo,
					     unsigned int burn_in)
{
    // We save only the first chain

    unsigned int Nb_Values=Histo.size();
    unsigned int NCol=Histo[0].size();

    Average.resize(NCol); // should be done beforehand to avoid memory errors

    for (unsigned int j=0;j<NCol;j++)
    {
        Average[j]=0.0;

        for (unsigned int sweep=burn_in;sweep<Nb_Values;sweep++)
        {
            Average[j]=Average[j]+
		Histo[sweep][j]/((double)(Nb_Values-burn_in));
        }
    }
}
