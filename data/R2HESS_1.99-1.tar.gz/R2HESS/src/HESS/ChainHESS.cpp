/* This file is part of HESS-OO.
 *      Copyright (c) Habib Saadi (h.saadi@imperial.ac.uk)
 *                    Marc Chadeau-Hyam (m.chadeau@imperial.ac.uk)
 *                    Leonardo Bottolo (l.bottolo@imperial.ac.uk)
 *                    David Hastie (d.hastie@imperial.ac.uk)
 *      2014
 * Designed and restructured by Loizos Markides (lm1011@imperial.ac.uk)
 * HESS-OO is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * HESS-OO is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with HESS-OO.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "ChainHESS.h"

ChainHESS::ChainHESS() {
    // The Chain constructor is guaranteed to have been called, so score_ contains a 
    // valid ScoreESS object. Need to free to avoid memory leak.
    delete score_;
    score_ = new ScoreHESS();
}

ChainHESS::~ChainHESS() {
    // Deleting score_ happens in Chain destructor
}

ChainHESS::ChainHESS(std::vector<bool> &newGammas){
	//Overloaded constructor. It is essential to use this constructor in HESS
	//because it also initializes the Score function to the correct class
	current_sweep_=0;
	currentTemperature_=1.0;
	delete score_;
	score_ = new ScoreHESS();
	gammas_ = newGammas;
	updateListOfIncludedVariables();
}

// Copy constructor simply calls base class constructor
ChainHESS::ChainHESS(const ChainHESS& copy) 
    : Chain(copy)  { }

double ChainHESS::FSMH_updateTheta(unsigned int current_variable)
{
	//Overloaded function that updates the theta variable in HESS
	 return std::max(0.0,(score_->omega_k_) * (score_->Rho_V_[current_variable]));
}

