/* This file is part of HESS-OO.
 *      Copyright (c) Habib Saadi (h.saadi@imperial.ac.uk)
 *                    Marc Chadeau-Hyam (m.chadeau@imperial.ac.uk)
 *                    Leonardo Bottolo (l.bottolo@imperial.ac.uk)
 *                    David Hastie (d.hastie@imperial.ac.uk)
 *      2014
 * Designed and restructured by Loizos Markides (lm1011@imperial.ac.uk)
 * HESS-OO is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * HESS-OO is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with HESS-OO.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef SCOREHESS_H_
#define SCOREHESS_H_

#include "../MCMC/Score.h"
#include <vector>
#include <gsl/gsl_matrix.h>

class ScoreHESS :public Score {
public:
    ScoreHESS();
    virtual ~ScoreHESS();
    virtual ScoreHESS *clone();

    static double PostProcessing_Marginal_wGprior(std::vector <unsigned int> &gamma_list_vars, // New algorithm
						  gsl_matrix * R2_Mat_GPriors,
						  gsl_matrix *matYTY,
						  gsl_matrix *mat_X,
						  double g,
						  double omega_k,
						  std::vector<double> &rho_j_V,
						  double log_omega_k,
						  std::vector<double> &log_rho_j_V,
						  std::vector<double> &log_1_omega_k_rho_j_V,
						  double Total,
						  double prior_k);
    
    virtual double getPriorGam(std::vector<unsigned int> &Gamma,unsigned int pX);
};

#endif /* SCOREHESS_H_ */
