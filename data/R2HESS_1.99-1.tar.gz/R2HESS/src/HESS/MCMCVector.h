/* This file is part of HESS-OO.
 *      Copyright (c) Habib Saadi (h.saadi@imperial.ac.uk)
 *                    Marc Chadeau-Hyam (m.chadeau@imperial.ac.uk)
 *                    Leonardo Bottolo (l.bottolo@imperial.ac.uk)
 *                    David Hastie (d.hastie@imperial.ac.uk)
 *      2014
 * Designed and restructured by Loizos Markides (lm1011@imperial.ac.uk)
 * HESS-OO is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * HESS-OO is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with HESS-OO.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef MCMCVECTOR_H_
#define MCMCVECTOR_H_

#include <iostream>
#include <vector>

#include "MCMCHESS.h"
#include "../GlobalMoves/AdaptiveMH.h"

class MCMCVector {
 public:
    void readData();
    void readDataY(std::istream &f);

    void initialise();
    void initialiseRhoAdMH();
    void initialiseMCMCs();
    void initialisePriors();

    void run();
    void writeFinalOutput();
    void writeOutputPerIteration(unsigned int sweep);
    void writePeriodicOutput(unsigned int sweep);
    void runInterProcessing(int sweep);
    //void runPostprocessing();
    void computeMPPI();
    void outputPosterior();

    static double c_rh_j_;
    static double d_rh_j_;
  
    unsigned int n_responses(){return n_responses_;}
    std::vector < std::vector < double > > Rho_PerCol_;
    std::vector < std::vector < double > > Omega_PerLine_;

    typedef std::vector<std::vector<double> > BatchData;

private:

    void updateHistory(BatchData &batchHistory, int sweep);
    void updateHistoryR2(BatchData &batchHistory, int sweep, std::vector<double> &r_square);
    std::vector<double> avgModelSize(BatchData &batchHistory, int start, int sweep);
    std::vector<double> avgR2(BatchData &batchHistory, int start, int sweep);

    void Update_Active_Yk(gsl_rng* RandomNumberGenerator);
    void Update_Active_Adaptive_Scan(gsl_rng* RandomNumberGenerator, BatchData &batchHistory, int sweep); //, std::vector<double> (MCMCVector::*getResponseWeights)(BatchData &, int, int));

    void Save_G_History();
    void Save_Rho_History();
    void Save_Omega_History();
    void Save_Average_Omega_k_j(unsigned int sweep);
    void Sample_Rho_j(unsigned int sweep,gsl_rng* RandomNumberGenerator);
    void Compute_Average_Rho_History(std::vector<double> &Average,
				     std::vector< std::vector< double> > Histo,
				     unsigned int burn_in);
    void Compute_Average_Omega_History(std::vector<double> &average, std::vector<std::vector<double> > history);

    double Log_Pr_Rho_j(double x,
			std::vector<double> * Omega_V,
			unsigned int Chain,
			unsigned int Variable);

    std::vector < unsigned int > Active_Yk_; //Subset of responses to be visited
    std::vector<unsigned> activeYkInds_;

    // Adaptation for Rho_j, need a matrix of AdMH objects
    std::vector < std::vector < AdaptiveMH > > Rho_j_AdMH_;

    std::vector < std::vector <double> > Matrix_Mod_Marg_Post_Prob_;

    std::vector<double> r_square;

    // std::vector < std::vector < double > > History_g_;
    std::vector < MCMCHESS > mcmcVector_;

    std::vector<double> activeWeights;

    // CCS
    std::vector<std::vector<double> > weightsHistory;
    
    std::vector<double> totalSumOfSquares;
    
    // Running count of tail probabilities
    std::vector<long int> tailProbCounts;



    // Adaptive transcript selection
    BatchData batchHistory;
    // Pointer to update function
    std::vector<double> (MCMCVector::*getResponseWeights)(BatchData &, int, int);

    unsigned int n_chains_;
    unsigned int n_responses_;
    unsigned int n_sweeps_;

    std::vector < std::vector < unsigned int > > count_visits;
    std::vector<std::vector<unsigned>> count_visits_active;
    std::vector<unsigned> activeTranscriptCounts;

    double Prop_Active_;
};

#endif /* MCMCHESS_H_ */
