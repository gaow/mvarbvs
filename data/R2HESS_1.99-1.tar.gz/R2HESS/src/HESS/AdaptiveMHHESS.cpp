/* This file is part of HESS-OO.
 *      Copyright (c) Habib Saadi (h.saadi@imperial.ac.uk)
 *                    Marc Chadeau-Hyam (m.chadeau@imperial.ac.uk)
 *                    Leonardo Bottolo (l.bottolo@imperial.ac.uk)
 *                    David Hastie (d.hastie@imperial.ac.uk)
 *      2014
 * Designed and restructured by Loizos Markides (lm1011@imperial.ac.uk)
 * HESS-OO is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * HESS-OO is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with HESS-OO.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "AdaptiveMHHESS.h"
#include "GlobalVariablesHESS.h"
#include "../MCMC/MCMC.h"

double AdaptiveMHHESS::g_prop = 0.0;
double AdaptiveMHHESS::cum_diff = 0.0;
bool AdaptiveMHHESS::run_test = false;
bool AdaptiveMHHESS::single_g_changed = false;

AdaptiveMHHESS::AdaptiveMHHESS() {
    G_tilda_accept=0;
    G_tilda_accept_ins=0;
    G_tilda_n_sweep=0;
    G_tilda_n_sweep_ins=0;
}

AdaptiveMHHESS::~AdaptiveMHHESS() {
    // TODO Auto-generated destructor stub
}


void AdaptiveMHHESS::execute(std::vector<Chain>& chainsVector,
			     gsl_matrix* mat_Y,
			     double &g,
			     double k_prior,
			     unsigned int sweep,
			     std::vector <unsigned int > &chain_idx,
			     std::vector <unsigned int > &n_Models_visited,
			     gsl_rng *RandomNumberGenerator)
{
    // The adaptive G for hess function. Because in HESS, when we have a single g
    // the cumulative difference of the proposed g is calculated for all chains and
    // for all responses, we set the cum_diff and g_prop variables to be static

    double alpha_g;
    double logPG;
    double logPG_Prop;
    unsigned int n_chains=chainsVector.size();

    if(! Settings.singleG || !run_test)
    {
	store_log_cond_post.clear();
	store_log_marg.clear();

	if (! Settings.singleG || g_prop == 0.0)
	{
	    double norm_mean;
	    double norm_sd;
	    double sample_tmp;

	    norm_mean=log(g);
	    norm_sd=exp(ls);

	    sample_tmp=norm_mean +  gsl_ran_gaussian( RandomNumberGenerator, norm_sd );
	    g_prop=exp(sample_tmp);
	    cum_diff = 0.0;
	}

	for(unsigned int current_chain=0;current_chain<n_chains;current_chain++)
	{
	    unsigned int pos_current_chain=chain_idx[current_chain];
	    double current_log_cond_post=chainsVector[pos_current_chain].getLogCondPostForSweep(sweep);
	    double current_log_marg=chainsVector[pos_current_chain].getLogMarginalForSweep(sweep);

	    chainsVector[pos_current_chain].calculateScore(g_prop,mat_Y,k_prior);

	    double proposed_log_cond_post=chainsVector[pos_current_chain].getLogCondPostForSweep(sweep);
	    double proposed_log_marg=chainsVector[pos_current_chain].getLogMarginalForSweep(sweep);

	    //revert
	    chainsVector[pos_current_chain].setLogMarginalForSweep(current_log_marg,sweep);
	    chainsVector[pos_current_chain].setLogCondPostForSweep(current_log_cond_post,sweep);

	    n_Models_visited[sweep]++;

	    cum_diff+=(proposed_log_marg-current_log_marg) /
		chainsVector[pos_current_chain].getCurrentTemperature();

	    store_log_marg.push_back(proposed_log_marg);
	    store_log_cond_post.push_back(proposed_log_cond_post);

	}//end of for chains

	if (Settings.moveLog)
	    log_.nb_sweep++;
    }

    if(! Settings.singleG || run_test)
    {
	logPG=Score::invGammaPdf(g,Prior::alpha,Prior::beta);
	logPG_Prop=Score::invGammaPdf(g_prop,Prior::alpha,Prior::beta);
	cum_diff=cum_diff+logPG_Prop-logPG+log(g_prop)-log(g);
	alpha_g=std::min(1.0,exp(cum_diff));

	if(!std::isnan(alpha_g))
	{
	    double rand_test = gsl_rng_uniform(RandomNumberGenerator);
	    if(rand_test<alpha_g && g_prop>0.0)
	    {
		//Accept move
		single_g_changed = true;
		g=g_prop;
		for(unsigned int chain=0;chain<n_chains;chain++)
		{
		    unsigned int pos_chain=chain_idx[chain];
		    chainsVector[pos_chain].setLogCondPostForSweep(store_log_cond_post[chain],sweep);
		    chainsVector[pos_chain].setLogMarginalForSweep(store_log_marg[chain],sweep);
		}
		G_tilda_accept++;
		G_tilda_accept_ins++;
	    }
	}
	else
	{
	    //"alpha_g is NaN"
	}
	if (Settings.moveLog)
	    log_.sample_history.push_back(g);

	G_tilda_n_sweep++;
	G_tilda_n_sweep_ins++;

	////////////////////////////////////////////////////
	//  Adaptation: every My_g_AdMH.n_batch sweeps
	////////////////////////////////////////////////////
	if(sweep%n_batch==0)
	{
	    updateLS(sweep);
	}
    }
}
