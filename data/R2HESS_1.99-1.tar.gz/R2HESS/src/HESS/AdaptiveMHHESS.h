/* This file is part of HESS-OO.
 *      Copyright (c) Habib Saadi (h.saadi@imperial.ac.uk)
 *                    Marc Chadeau-Hyam (m.chadeau@imperial.ac.uk)
 *                    Leonardo Bottolo (l.bottolo@imperial.ac.uk)
 *                    David Hastie (d.hastie@imperial.ac.uk)
 *      2014
 * Designed and restructured by Loizos Markides (lm1011@imperial.ac.uk)
 * HESS-OO is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * HESS-OO is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with HESS-OO.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef ADAPTIVEMHHESS_H_
#define ADAPTIVEMHHESS_H_
#include <gsl/gsl_errno.h>
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_odeiv.h>
#include <gsl/gsl_rng.h>
#include <gsl/gsl_randist.h>
#include "../GlobalMoves/AdaptiveMH.h"

class AdaptiveMHHESS: public AdaptiveMH {
public:
    AdaptiveMHHESS();
    virtual ~AdaptiveMHHESS();
    virtual void execute(std::vector<Chain>& chainsVector,
			 gsl_matrix* mat_Y,
			 double &g,
			 double k_prior,
			 unsigned int sweep,
			 std::vector <unsigned int > &chain_idx,
			 std::vector <unsigned int > &n_Models_visited,
			 gsl_rng *RandomNumberGenerator);
    static double g_prop;
    static double cum_diff;
    static bool run_test;
    static bool single_g_changed;
};

#endif /* ADAPTIVEMHHESS_H_ */
