/* This file is part of HESS-OO.
 *      Copyright (c) Habib Saadi (h.saadi@imperial.ac.uk)
 *                    Marc Chadeau-Hyam (m.chadeau@imperial.ac.uk)
 *                    Leonardo Bottolo (l.bottolo@imperial.ac.uk)
 *                    David Hastie (d.hastie@imperial.ac.uk)
 *      2014
 * Designed and restructured by Loizos Markides (lm1011@imperial.ac.uk)
 * HESS-OO is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * HESS-OO is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with HESS-OO.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "MCMCHESS.h"
#include "AdaptiveMHHESS.h"
#define DEBUG 0

double MCMCHESS::a_om_k_=0.0;
double MCMCHESS::b_om_k_=0.0;

using std::vector;

MCMCHESS::MCMCHESS() {
    //setting adaptive MH to our current applicable class
    delete adaptivemh_;
    adaptivemh_ = new AdaptiveMHHESS();
}

MCMCHESS::~MCMCHESS() {
    //delete Omega_k_AdMH;
    for (unsigned int c=0;c<n_chains_;c++)
    {
    	delete Omega_k_AdMH_[c];
    }

    //History_Omega_.clear();
    //Average_Omega_k_j_.clear();
    //Count_Visits_Gamma_kj_.clear();
}

// Ugly hack. The vector of MCMCHESS objects must be resized at runtime. Calling resize()
// requires a copy constructor to exist. But MCMC objects can't (easily) be copied due
// to containing pointers to data and objects. As long as we resize once, from the initial
// empty vector, the copy constructor will never actually be called, so this code is safe in practice.
MCMCHESS::MCMCHESS(const MCMCHESS& copy) {
    exitWithError("MCMCHESS copy constructor called. This is caused by programmer error, not user error. Sorry.");
}


void MCMCHESS::initializeYTY() {
    // Y^T * Y
    YTY = gsl_matrix_alloc(pY, pY);
    gsl_blas_dgemm(CblasTrans, CblasNoTrans, 1, mat_Y, mat_Y, 0, YTY);

    // pY x pY identity matrix
    gsl_matrix *Il = gsl_matrix_alloc(pY, pY);
    gsl_matrix_set_identity(Il);

    // Hyperparam k has already been calculated from initial regression
    double k = 0;
    for (unsigned i = 0; i < pY; i++)
	k += pow(gsl_vector_get(vect_RMSE_, i), 2);
    k /= pY;
    
    // YTY = kI + YTY
    gsl_matrix_scale(Il, k);
    gsl_matrix_add(YTY, Il);
}




// WARNING WARNING WARNING 
// This algorithm is very slow, and relies on both pGam and pY being very small


void MCMCHESS::betaDraw(gsl_rng* rng, vector<gsl_matrix *> betaMean, vector<gsl_matrix*> betaMax, vector<gsl_matrix*> betaMin, vector<gsl_matrix *> betaCount, unsigned k) {

    // TODO: Proper setting of d = 3
    
    unsigned dstar = 3 + Settings.nX;

    unsigned pgam = chain(0).modelSize();
    // Number of tissues = pY

    gsl_matrix *Xgam = gsl_matrix_alloc(Settings.nX, pgam);
    get_X_reduced(chain(0).gammaVars(), Xgam);

    // Step 1: Sigma = IW(..)

    // X^T . Y
    gsl_matrix *XTY = gsl_matrix_alloc(pgam, pY);
    gsl_blas_dgemm(CblasTrans, CblasNoTrans, 1, Xgam, mat_Y, 0, XTY);

    // The standard use of Cholesky to compute (XTX)^-1.XTY assumes
    // vector y, not multivarate Y

    gsl_matrix *XTXinv = gsl_matrix_alloc(pgam, pgam);
    // X^T . X
    gsl_blas_dgemm(CblasTrans, CblasNoTrans, 1, Xgam, Xgam, 0, XTXinv);
    // Use Cholesky to calculate (X^T.X)^-1
    gsl_linalg_cholesky_decomp(XTXinv);
    gsl_linalg_cholesky_invert(XTXinv);

    // Scale by g/(1+g). Do it here because the scaled XTXinv is used in step 2
    gsl_matrix_scale(XTXinv, g_ / (1 + g_));

    // Intermediate product (X^T.X)^-1 . X^T.Y
    gsl_matrix *XTXXTY = gsl_matrix_alloc(pgam, pY);
    gsl_blas_dgemm(CblasNoTrans, CblasNoTrans, 1, XTXinv, XTY, 0, XTXXTY);
    
    // Variance matrix for invWishart
    gsl_matrix *Qstar = gsl_matrix_calloc(pY, pY);
    
    // Qstar = YTX.XTX^-1.XTY
    gsl_blas_dgemm(CblasTrans, CblasNoTrans, 1, XTY, XTXXTY, 0, Qstar);

    // Add kI + YTY
    gsl_matrix_add(Qstar, YTY);
    
    gsl_matrix* sigma = gsl_matrix_alloc(pY, pY);
    invWishartDraw(rng, sigma, dstar, Qstar);

    // Step 2: Beta

    // H = scaled XTX^-1 = XTXinv; sigma = draw

    // Kroneker product
    gsl_matrix *kron = gsl_matrix_calloc(pY*pgam, pY*pgam);

    // i, j indices of H
    for (unsigned int i = 0; i < pgam; i++)
	for (unsigned int j = 0; j < pgam; j++) {
	    // m, n indices of sigma
	    double hval = gsl_matrix_get(XTXinv, i, j);
	    for (unsigned int m = 0; m < pY; m++)
		for (unsigned int n = 0; n < pY; n++) {
		    double sigmaval = gsl_matrix_get(sigma, m, n);

		    // p, q destination indices of Kron
		    unsigned p = i*pY + m;
		    unsigned q = j*pY + n;
		    
		    gsl_matrix_set(kron, p, q, hval * sigmaval);
		}
	}
    
    gsl_vector* mu = gsl_vector_alloc(pY * pgam);
    gsl_vector* betaVec = gsl_vector_alloc(pY * pgam);
    
    //gsl_ran_multivariate_gaussian(rng, mu, kron, betaVec);
    gsl_linalg_cholesky_decomp(kron);
    gsl_vector *z = gsl_vector_alloc(pY*pgam);
    for (unsigned j = 0; j < pY*pgam; j++)
	gsl_vector_set(z, j, gsl_ran_gaussian(rng, 1));
    // Set upper triangular excluding diagonal to 0
    for (unsigned j = 0; j < pY*pgam; j++)
	for (unsigned k = j + 1; k < pY*pgam; k++)
	    gsl_matrix_set(kron, j, k, 0);
    
    // Loop over output
    for (unsigned j = 0; j < pY; j++) {
	double val = 0;
	for (unsigned k = 0; k < pY; k++)
	    val += gsl_matrix_get(kron, j, k) * gsl_vector_get(z, k);
	gsl_vector_set(betaVec, j, val);
    }
	
    //gsl_matrix *HXTY = gsl_matrix_alloc(pY, pgam);
    // TODO: We calculate this as intermediate of Qstar. Reuse.
    //gsl_blas_dgemm(CblasNoTrans, CblasNoTrans, 1, XTXinv, XTY, 0, HXTY);
    
    // Beta = beta + H . XTY = beta + XTXXTY, and store
    for (unsigned i = 0; i < pgam; i++) {
	unsigned snp = chain(0).gammaVars()[i];
	for (unsigned j = 0; j < pY; j++) {
	    double betaVar = gsl_vector_get(betaVec, i*pY+j) + gsl_matrix_get(XTXXTY, i, j);
	    // Output index: row snp, col k (transcript)
	    clog << "setting: row " << snp << " col " << k << endl;
	    gsl_matrix_set(betaMean[j], snp, k, betaVar);
	    gsl_matrix_set(betaCount[j], snp, k, gsl_matrix_get(betaCount[j], snp, k) + 1);
	    if (betaVar > gsl_matrix_get(betaMax[j], snp, k))
		gsl_matrix_set(betaMax[j], snp, k, betaVar);
	    if (betaVar < gsl_matrix_get(betaMin[j], snp, k))
		gsl_matrix_set(betaMin[j], snp, k, betaVar);
	}
    }

    gsl_vector_free(mu);
    gsl_vector_free(betaVec);
    gsl_matrix_free(sigma);
    gsl_matrix_free(kron);
    gsl_matrix_free(Qstar);
    gsl_matrix_free(XTXinv);
    gsl_matrix_free(Xgam);
    gsl_matrix_free(XTXXTY);

}

using std::cout;

void pmat(gsl_matrix* mat) {
    for (int i = 0; i < mat->size1; i++) {
	for (int j = 0; j < mat->size2; j++)
	    clog << gsl_matrix_get(mat, i, j) << " ";
	clog << endl;
    }
}


// Draw is overwritten
void MCMCHESS::invWishartDraw(gsl_rng *rng, gsl_matrix *draw, unsigned v, gsl_matrix *S) {
    // IW ~ invWishart(v, S) == (wishart(v, S^-1)) ^-1

    // Get inverse of scale matrix
    gsl_linalg_cholesky_decomp(S);
    gsl_linalg_cholesky_invert(S);

    // Per Appendix A of Gelman et al, Bayesian Data Analysis, sample from a Wishart
    // by simulating v draws a_i from a k-dimensional multivariate N(0,S) (where k is the 
    // size of the scale matrix S, i.e. pY), and then calculating 
    // W = sum(a_i . a_i^T)

    gsl_matrix_set_zero(draw);

    gsl_vector *mu = gsl_vector_calloc(pY);
    gsl_vector *ai = gsl_vector_alloc(pY);

    gsl_vector *z = gsl_vector_alloc(pY);

    // Manual multivarate as GSL v1 doesn't include it
    // Also means we can calculate the Cholesky once and use it for multiple draws

    // Cholesky of the scale
    gsl_linalg_cholesky_decomp(S);

    for (unsigned i = 0; i < v; i++) {

	// Now the lower triangular part of scale is the matrix L, where L L^T = scale. (The upper triangular is unchanged.)
	// To calculate multivariate:
	// 1. z = (z1, ..., zn) = n independent draws from N(0, 1), n the dimension
	// x = mu + Lz, for x the draw from a multivariate normal

	gsl_vector_set_zero(z);
	
	for (unsigned j = 0; j < pY; j++)
	    gsl_vector_set(z, j, gsl_ran_gaussian(rng, 1));

	// Set upper triangular excluding diagonal to 0
	for (unsigned j = 0; j < pY; j++)
	    for (unsigned k = j + 1; k < pY; k++)
		gsl_matrix_set(S, j, k, 0);

	// Loop over output, which is ai
	for (unsigned j = 0; j < pY; j++) {
	    double val = 0;
	    for (unsigned k = 0; k < pY; k++)
		val += gsl_matrix_get(S, j, k) * gsl_vector_get(z, k);
	    gsl_vector_set(ai, j, val);
	}
	
	//gsl_ran_multivariate_gaussian(rng, mu, scale, ai);

	// draw = draw + ai * ai^T
	for (unsigned int j = 0; j < pY; j++) {
	    for (unsigned int k = 0; k < pY; k++) {
		double val = gsl_matrix_get(draw, j, k) + gsl_vector_get(ai, j) * gsl_vector_get(ai, k);
		gsl_matrix_set(draw, j, k, val);
	    }
	}
    }
    
    // And invert the result
    gsl_linalg_cholesky_decomp(draw);
    gsl_linalg_cholesky_invert(draw);
    
    gsl_vector_free(mu);
    gsl_vector_free(ai);
}



void MCMCHESS::initialize_HESS_Omega(unsigned int nBatch, double optimal, double ls, double omega_kmmin, double omega_kmmax, double omega_delta_n) {

    Omega_k_AdMH_.resize(n_chains_);
    for (unsigned int chain = 0; chain < n_chains_; chain++) {
    	Omega_k_AdMH_[chain] = new AdaptiveMH();
	Omega_k_AdMH_[chain]->n_batch = nBatch;
	Omega_k_AdMH_[chain]->optimal = optimal;
	Omega_k_AdMH_[chain]->ls = ls;
	Omega_k_AdMH_[chain]->M[0] = omega_kmmin;
	Omega_k_AdMH_[chain]->M[1] = omega_kmmax;
	Omega_k_AdMH_[chain]->delta_n = omega_delta_n / (burn_in_ / (double) nBatch);
    }

    Average_Omega_k_j_.resize(MCMC::pX);
    Count_Visits_Gamma_kj_.resize(MCMC::pX);
    for (unsigned int j = 0; j < MCMC::pX; j++) {
        Average_Omega_k_j_[j] = 0;
    	Count_Visits_Gamma_kj_[j] = 0;
    }
}

// * * * * * * * * * * *

void MCMCHESS::initialize_g(double g_init) {
    g_ = g_init;
}




void MCMCHESS::newSweep()
{
    //Copy the previous value of the marginal and posterior, as well as the previous models
    sweep_++;
    n_Models_visited_[sweep_]=n_Models_visited_[sweep_-1];
    for(unsigned int chain=0;chain<n_chains_;chain++)
    {
	chainsVector_[chain].newSweep();
    }
}

void MCMCHESS::initialize_k_prior() {
    if (pY > 1) {
	Prior::updateKwithRMSE(vect_RMSE_);
	k_prior_ = Prior::k;
    } else
	k_prior_=1e-3;
}



void MCMCHESS::update_average_omega(unsigned int idx,double new_omega,double coeff1,double coeff2)
{
    Average_Omega_k_j_[idx] = coeff1*Average_Omega_k_j_[idx]+coeff2*new_omega;
}

double MCMCHESS::get_chain_temperature(unsigned int chain_position)
{
    return chainsVector_[chain_idx_[chain_position]].getCurrentTemperature();
}

void MCMCHESS::get_gamma_vector_of_chain(std::vector < bool >* gam, unsigned int chain_position)
{
    chainsVector_[chain_idx_[chain_position]].getGammaVector(gam);
}

void MCMCHESS::addChain(std::vector<bool> &vect_gam)
{
    //Overloaded function that ensures that the Chain objects in HESS are of the correct type.
    ChainHESS newChain(vect_gam);
    newChain.initialize(n_sweeps_,chainsVector_.size(),resumeSweep_,nConfounders_);
    newChain.yIndex = yIndex;
    newChain.setScorePY(pY);
    chainsVector_.push_back(newChain);
}

void  MCMCHESS::Sample_Omega_k(std::vector < std::vector < double > > &Rho_PerCol,
			       std::vector < std::vector < double > > &Omega_PerLine,
			       unsigned int Response,
			       gsl_rng* RandomNumberGenerator)
{

    double Curr_Omega_k;
    double Prop_Omega_k;
    double norm_mean;
    double norm_sd;
    double sample_tmp;
    double Alpha_Omega_k;
    std::vector<double> * Rho_V;

    for (unsigned int c=0;c<n_chains_;c++)
    {
    	unsigned int Chain = c;//chain_idx_[c];

    	if (DEBUG)
        {clog << "Chain " << Chain << " and Response " << Response << endl;}

    	// 1) For each chain and reponse, propose an omega. If violates conditions, reject it
    	Curr_Omega_k=Omega_PerLine[Chain][Response];
        Rho_V=&(Rho_PerCol[Chain]);

        norm_mean=Logistic_Trans(Curr_Omega_k);

        norm_sd=exp(Omega_k_AdMH_[Chain]->ls);
        sample_tmp= norm_mean +  gsl_ran_gaussian(RandomNumberGenerator, norm_sd );

        Prop_Omega_k=Logistic_Trans_Inv(sample_tmp);

        double Max_Omega=0;
        for (unsigned int j=0;j<MCMC::pX;j++)
        {
	    Max_Omega=std::max(Max_Omega,Prop_Omega_k * (*Rho_V)[j]);
        }

        bool Failed=false;
        if (Max_Omega>1)
        {
	    //Reject
	    Failed=true;
        }

        if (DEBUG)
        {
	    clog << "Failed=" << Failed << endl;
	    clog << "Max_Omega=" << Max_Omega << endl;
	    clog << "Prop_Omega_k=" << Prop_Omega_k << endl;
        }

        if (Failed==false)
        {
	    // 2) Compute the acceptance probability
	    double Log_P_Prop_Ok=Log_Pr_Omega_k(Prop_Omega_k,c,Response);
	    double Log_P_Curr_Ok=Log_Pr_Omega_k(Curr_Omega_k,c,Response);

	    Alpha_Omega_k=exp(Log_P_Prop_Ok-Log_P_Curr_Ok);
	    Alpha_Omega_k=std::min((double) 1,Alpha_Omega_k);

	    // 3) Accept / Reject
	    double U = 1;
	    U = gsl_rng_uniform(RandomNumberGenerator);

	    if (U>Alpha_Omega_k)
	    {
		Failed=true;
	    }
        }

        // 4) Update
        if (DEBUG)
        {clog << "Alpha_Omega_k=" << Alpha_Omega_k << "   Prop_Omega_k="
	      << Prop_Omega_k << endl;}

        if (Failed==false)
        {
	    Omega_PerLine[Chain][Response]=Prop_Omega_k;
	    Omega_k_AdMH_[Chain]->G_tilda_accept++;
	    Omega_k_AdMH_[Chain]->G_tilda_accept_ins++;

	    if (DEBUG) {clog << "Move accepted, New Omega=" << Omega_PerLine[Chain][Response] << endl;}
        }
        else
        {
	    if (DEBUG){clog << "Move refused, New Omega=" << Omega_PerLine[Chain][Response] << endl;}
        }

	Omega_k_AdMH_[Chain]->G_tilda_n_sweep++;
	Omega_k_AdMH_[Chain]->G_tilda_n_sweep_ins++;

        // 5) Adapt

	unsigned int n_batch = Omega_k_AdMH_[Chain]->n_batch;
	if (sweep_%n_batch==0)
	{
	    Omega_k_AdMH_[Chain]->updateLS(sweep_);
	    if (Settings.outFlags.ls)
		Settings.out.lsOmega << Omega_k_AdMH_[Chain]->ls << " ";
	}
    }
}

double MCMCHESS::Logistic_Trans(double Omega)
{
    double Epsilon=pow(10.0,-10.0);

    double Cut_Omega=Omega;
    Cut_Omega=std::max(Cut_Omega,Epsilon);
    Cut_Omega=std::min(Cut_Omega,1-Epsilon);

    double norm_mean=log(Cut_Omega/(1-Cut_Omega));

    return norm_mean;
}

double MCMCHESS::Logistic_Trans_Inv(double sample_tmp)
{
    double Epsilon=pow(10.0,-10.0);

    double Omega=exp(sample_tmp)/(1+exp(sample_tmp));

    double Cut_Omega=Omega;
    Cut_Omega=std::max(Cut_Omega,Epsilon);
    Cut_Omega=std::min(Cut_Omega,1-Epsilon);

    return Cut_Omega;
}


double MCMCHESS::Log_Pr_Omega_k(double x,
				unsigned int chain,
				unsigned int Response)
{

    if (x>1 || x<0)
    {
        clog << "Error in Log_Pr_Omega_k, x outside range [0,1]" << endl;
        exit(-1);
    }

    Chain &chainObj = get_chain(chain);

    //double Temp=get_chain_temperature(chain);
    double Temp = chainObj.getCurrentTemperature();

    //vector<double> * Rho_V=&(get_chain(chain).score_->Rho_V_);
    std::vector<double> * Rho_V=&(chainObj.score_->Rho_V_);

    unsigned int pX=Rho_V->size();

    double Log_P_Gam=0;
    for (unsigned int j=0;j<pX;j++)
    {
        //if (get_chain(chain).gammas_[j]==1)
	if (chainObj.gammas_[j] == 1)
        {
            Log_P_Gam=Log_P_Gam + log(x * (*Rho_V)[j]);
        }
        else
        {
            Log_P_Gam=Log_P_Gam + log(1-x * (*Rho_V)[j]);
        }

    }
    Log_P_Gam=Log_P_Gam/Temp;

    double Log_J=log(x*(1-x));

    double Log_P_Omega_k=(a_om_k_-1)*log(x)+(b_om_k_-1)*log(1-x)-gsl_sf_lnbeta(a_om_k_,b_om_k_);

    double Res=Log_P_Gam+(Log_P_Omega_k+Log_J)/Temp;

    return Res;
}
