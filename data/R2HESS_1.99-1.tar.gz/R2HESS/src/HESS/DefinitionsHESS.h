/* This file is part of HESS-OO.
 *      Copyright (c) Habib Saadi (h.saadi@imperial.ac.uk)
 *                    Marc Chadeau-Hyam (m.chadeau@imperial.ac.uk)
 *                    Leonardo Bottolo (l.bottolo@imperial.ac.uk)
 *                    David Hastie (d.hastie@imperial.ac.uk)
 *      2014
 * Designed and restructured by Loizos Markides (lm1011@imperial.ac.uk)
 * HESS-OO is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * HESS-OO is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with HESS-OO.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef DEFINITIONSHESS_H_
#define DEFINITIONSHESS_H_

#include <iostream>

// Flags are initialised in GlobalVariablesHESS.cpp
struct HESSFlags
{
    bool Single_g;		// true
    bool fixInit_omega_k;	// false
    bool fixInit_rho_j;		// false
    bool Pr_g_a_flag;		// false
    bool Pr_g_b_flag;		// false
    bool a_om_k_Flag;		// false
    bool b_om_k_Flag;		// false
    bool c_rh_j_Flag;		// false
    bool d_rh_j_Flag;		// false
    bool gamSampleFlag;		// true
    bool OmegaKSampleFlag;	// true
    bool RhoJSampleFlag;	// true
    bool HESS_do_Postproc;	// true
    bool HESS_slow_Postproc;	// false
    bool Memory_Limited;	// false
    bool Include_Single_Models; // true
    bool Adaptive_Scanning;	// true
};

struct HESSOutputFileStreams
{
    std::ofstream Output_File_Av_Rho_j;
    std::ofstream Output_File_Av_Omega_k;
    std::fstream Output_File_History_Rho;
    std::fstream Output_File_History_Omega;
    std::ofstream Output_File_Av_Omega;
    std::ofstream Output_File_History_g;
    std::ofstream Output_File_Counts_Gamma_kj;
    std::ofstream Output_File_Initial_Gamma;
    
    std::ofstream Output_File_Rho_ls;
    std::ofstream Output_File_Omega_ls;
    std::ofstream Output_File_modelSize;
    std::ofstream Output_File_activeY;

    std::ofstream Output_File_TP_Rho_j;
    std::ofstream Output_File_TP_Rho_j_inter;
    std::ofstream Output_File_Best_Models_Marg;
    std::ofstream Output_File_Prob_Best_Models_Marg;
    std::ofstream Output_File_Marg_Prob_Incl;
    std::ofstream Output_File_Models_Prob;
    std::ofstream Output_File_Simple_MPI;
    std::ofstream Output_File_Batch_Weights;
};

struct HESSInputFileNames
{
    std::string filename_init_omega_k;
    std::string filename_init_rho_j;
};

struct TimingHESS{
    clock_t Loop_Start_Time;
    clock_t PostProc_Start_Time;
};

#endif /* DEFINITIONSHESS_H_ */
