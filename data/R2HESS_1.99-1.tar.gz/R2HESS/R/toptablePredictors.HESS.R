r2hess.toptablePredictors <- function(config, threshold=0.5){
    
  NTOTAL <- config$nSweep - config$burn.in

  File_Matrix_Marg_Prob_Incl <- paste(config$output.dir,"Gamma_Counts_kj.txt",sep="");
  Matrix_Marg_Prob_Incl <- read.delim(File_Matrix_Marg_Prob_Incl,header=F,sep="",skip=1);
  Matrix_Marg_Prob_Incl <- Matrix_Marg_Prob_Incl/NTOTAL

    X.labels <- config$X.labels
    
    # Exclude confounders
    if (config$nConfounders > 0) {
        Matrix_Marg_Prob_Incl <- Matrix_Marg_Prob_Incl[, -(1:config$nConfounders)]
        X.labels <- X.labels[-(1:config$nConfounders)]
    }
    
  print(paste("dim MPPI = ",dim(Matrix_Marg_Prob_Incl)))

    
  ###############################################################
  # summaries P(Gamma_kj=1) per predictor

  #### sum and max for each marker
  #Matrix_Marg_Prob_Incl_sum <- apply(Matrix_Marg_Prob_Incl,2,sum)
  #Matrix_Marg_Prob_Incl_max <- apply(Matrix_Marg_Prob_Incl,2,max)

#### number MPPI pre predictor above threshold
    
  Matrix_Marg_Prob_Incl_abovethresh <- apply(Matrix_Marg_Prob_Incl>=threshold,2,sum)

    rows<- which(Matrix_Marg_Prob_Incl_abovethresh > 0)
    
  #### get which responses have MPPI above threshold (first gets indices, then lappy to get the Y labels)
  Matrix_Marg_Prob_Incl_which_ind <- apply(Matrix_Marg_Prob_Incl>=threshold,2,which)
  Matrix_Marg_Prob_Incl_which_Ys <- lapply(Matrix_Marg_Prob_Incl_which_ind, FUN=function(ind,vect){vect[ind]} ,config$Y.labels)
  
  #print(head(Matrix_Marg_Prob_Incl_which_ind))
  #print(tail(Matrix_Marg_Prob_Incl_which_ind))
  #print(head(Matrix_Marg_Prob_Incl_which_Ys))
  #print(tail(Matrix_Marg_Prob_Incl_which_Ys))


#  predictors.toptable <- data.frame(Predictor=x$label.X,MPPI_sum=Matrix_Marg_Prob_Incl_sum,
#	MPPI_max=Matrix_Marg_Prob_Incl_max,
#	MPPI_thresh=Matrix_Marg_Prob_Incl_abovethresh,
#	Responses=as.character(Matrix_Marg_Prob_Incl_which_Ys))

  predictors.toptable <- data.frame(Predictor=X.labels[rows],	
	MPPI_thresh=Matrix_Marg_Prob_Incl_abovethresh[rows],
	Responses=as.character(Matrix_Marg_Prob_Incl_which_Ys)[rows])

  print(paste("MPPI threshold = ",threshold))
  #print(head(predictors.toptable))

  return(list(toptable=predictors.toptable,list.responses=Matrix_Marg_Prob_Incl_which_Ys[rows]))
  
}









toptablePredictors.HESS <- function(x,thresh=0.5){
    
  NTOTAL <- x$nsweep - x$burn.in

  File_Matrix_Marg_Prob_Incl <- paste(x$path.output,"/",x$root.file.output,"_Counts_Gamma_kj.txt",sep="");
  Matrix_Marg_Prob_Incl <- read.delim(File_Matrix_Marg_Prob_Incl,header=F,sep="");
  Matrix_Marg_Prob_Incl <- Matrix_Marg_Prob_Incl/NTOTAL
  print(paste("dim MPPI = ",dim(Matrix_Marg_Prob_Incl)))


  ###############################################################
  # summaries P(Gamma_kj=1) per predictor

  #### sum and max for each marker
  #Matrix_Marg_Prob_Incl_sum <- apply(Matrix_Marg_Prob_Incl,2,sum)
  #Matrix_Marg_Prob_Incl_max <- apply(Matrix_Marg_Prob_Incl,2,max)

  #### number MPPI pre predictor above threshold
  Matrix_Marg_Prob_Incl_abovethresh <- apply(Matrix_Marg_Prob_Incl>=thresh,2,sum)

  #### get which responses have MPPI above threshold (first gets indices, then lappy to get the Y labels)
  Matrix_Marg_Prob_Incl_which_ind <- apply(Matrix_Marg_Prob_Incl>=thresh,2,which)
  Matrix_Marg_Prob_Incl_which_Ys <- lapply(Matrix_Marg_Prob_Incl_which_ind, FUN=function(ind,vect){vect[ind]} ,x$label.Y)
  
  #print(head(Matrix_Marg_Prob_Incl_which_ind))
  #print(tail(Matrix_Marg_Prob_Incl_which_ind))
  #print(head(Matrix_Marg_Prob_Incl_which_Ys))
  #print(tail(Matrix_Marg_Prob_Incl_which_Ys))


#  predictors.toptable <- data.frame(Predictor=x$label.X,MPPI_sum=Matrix_Marg_Prob_Incl_sum,
#	MPPI_max=Matrix_Marg_Prob_Incl_max,
#	MPPI_thresh=Matrix_Marg_Prob_Incl_abovethresh,
#	Responses=as.character(Matrix_Marg_Prob_Incl_which_Ys))

  predictors.toptable <- data.frame(Predictor=x$label.X,	
	MPPI_thresh=Matrix_Marg_Prob_Incl_abovethresh,
	Responses=as.character(Matrix_Marg_Prob_Incl_which_Ys))

  print(paste("MPPI threshold = ",thresh))
  print(head(predictors.toptable))

  return(list(toptable=predictors.toptable,list.responses=Matrix_Marg_Prob_Incl_which_Ys))
  
}

