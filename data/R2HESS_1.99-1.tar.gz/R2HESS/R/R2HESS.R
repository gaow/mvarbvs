r2hess.makeConfig <- function(Xdat, Ydat, output.dir, nSweep = 22000, burn.in = 2000, nChain = 3, r=1) {
    config <- list()

    # Add trailing / if required    
    lastChar <- substr(output.dir, nchar(output.dir), nchar(output.dir))
    if (lastChar != "/")
        output.dir <- paste0(output.dir, "/")

    # Create directory if required
    if (! dir.exists(output.dir))
        dir.create(output.dir)
    
    config$output.dir <- output.dir
    config$config.file <- paste0(output.dir, "config.txt")
    config$log.file <- paste0(output.dir, "log.txt")
    config$X.file <- paste0(output.dir, "X.txt")
    config$Y.file <- paste0(output.dir, "Y.txt")

    # Write data to file                        
    r2hess.writeX(Xdat, config$X.file)
    config$X.labels <- colnames(Xdat)
    r2hess.writeY(Ydat, config$Y.file, r=1)
    config$Y.labels <- colnames(Ydat)
                            
    config$nSweep <- nSweep
    config$burn.in <- burn.in
    config$nChain <- nChain
    config$nConfounders <- 0
                            
    config$Egam <- 2
    config$Sgam <- 2
    #config$maxPGamma <- 0
    config$maxPGammaFactor <- 7

    config$gibbsNbatch <- 1000

    #config$verbose <- FALSE    
    #config$seed <- -1
    
    #config$pMutation <- 0.5
    #config$pSel <- 0.5
    #config$pCsrv <- 0.375
    #config$pDR <- 0.5
    #config$regNpEnter <- 0.01
    #config$regrNpRemove <- 0.01

    config$activeY <- 0.25
    
    #config$adaptiveSelection <- FALSE
    #config$adaptiveWeightsFn <- "avgR2"
    #config$adaptBatchSize <- 50
    #config$adaptC <- 100

    config$gammaCountInterval <- 100

    #config$gammaUpdateMove <- FALSE
    #config$gammaUpdateMoveProb <- 0.75
    #config$gammaUpdateSwap <- 0.25
    #config$gammaUpdateAdd <- 0.5
    #config$gammaUpdateRandGeometric <- 0.3
    #config$gammaUpdateGeometricInvProb <- 25

    config$out.activeY <- FALSE
    #config$out.adaptBatchWeights <- FALSE
    config$out.avMatrixOmega <- TRUE
    #config$out.BestModels <- FALSE
    #config$out.BestModelsProbs <- FALSE
    #config$out.CbAccept <- FALSE
    #config$out.FsmhAccept <- FALSE
    config$out.gammaCounts <- TRUE
    #config$out.GammaProp <- FALSE
    config$out.historyG <- TRUE
    config$out.historyOmega <- TRUE
    config$out.historyRho <- TRUE
    config$out.initGamma <- FALSE
    #config$out.Ls <- FALSE
    config$out.modelsFull <- FALSE
    config$out.modelPostProb <- FALSE
    config$out.modelSizes <- TRUE
    #config$out.MpiComplex <- FALSE
    config$out.mpiSimple <- TRUE
    #config$out.mpiUnique <- FALSE
    #config$out.mtBeta <- FALSE
    config$out.rSquare <- FALSE
    config$out.sGamma <- FALSE
    config$out.tailProbs <- TRUE

    class(config)
    
    config
}


r2hess.writeX <- function(data, filename) {
    write(nrow(data), filename)
    write(ncol(data), filename, append=T)
    write.table(data, filename, append=T, sep=" ", row.names=F, col.names=F, na="0")
}

r2hess.writeY <- function(data, filename, r=1) {
    write(nrow(data), filename)
    write(ncol(data), filename, append=T)
    q <- ncol(data) / r
    if (q != round(q)) stop ("r does not evenly divide number of columns")
    write(paste(rep(r, q), collapse=" "), filename, append=T)
    write.table(data, filename, append=T, sep=" ", row.names=F, col.names=F)
}

# Append and paste
ap <- function(file, ...) {
    write(paste0(...), file, append=T)
}

r2hess.writeConfigFile <- function(config) {
    f <- config$config.file
    c <- config
    
    write("# R2HESS Configuration File", f)
    write("# -------------------------", f, append=T) 
    ap(f, "# Created: ", date())
    ap(f, "")
    
    ap(f, "model=1")
    ap(f, "X=", c$X.file)
    ap(f, "Y=", c$Y.file)
    ap(f, "out=", c$output.dir)
    ap(f, "log=", c$log.file, "\n")

    ap(f, "nsweep=", c$nSweep)
    ap(f, "burn_in=", c$burn.in)
    #ap(f, "seed=", c$seed)
    ap(f, "n_chain=", c$nChain, "\n")
    ap(f, "nConfounders=", c$nConfounders)

    ap(f, "Egam=", c$Egam)
    ap(f, "Sgam=", c$Sgam)
    ap(f, "max-pgamma-factor=", c$maxPGammaFactor)

    ap(f, "gibbs-nbatch=", c$gibbsNbatch)

    ap(f, "active-y=", c$activeY)
    ap(f, "gamma-count-interval=", c$gammaCountInterval)

    ap(f, "out-activeY=", c$out.activeY)
    ap(f, "out-av-matrix-omega=", c$out.avMatrixOmega)
    ap(f, "out-gamma-counts=", c$out.gammaCounts)
    ap(f, "out-history-g=", c$out.historyG)
    ap(f, "out-history-omega=", c$out.historyOmega)
    ap(f, "out-history-rho=", c$out.historyRho)
    ap(f, "out-init-gamma=", c$out.initGamma)
    ap(f, "out-models-full=", c$out.modelsFull)
    ap(f, "out-model-post-prob=", c$out.modelPostProb)
    ap(f, "out-mpi=", c$out.mpiSimple)
    ap(f, "out-rsquare=", c$out.rSquare)
    ap(f, "out-sgamma=", c$out.sGamma)
    ap(f, "out-tail-probs=", c$out.tailProbs)
}


r2hess.run <- function(config) {

    r2hess.writeConfigFile(config)

    save(file=paste0(config$output.dir, "config.Rda"), config)
    
    pack.root <- system.file(package = "R2HESS")
    ESS.directory <- file.path(pack.root, "bin", .Platform$r_arch)

    r2hess.exe <- ifelse(.Platform$OS.type == "unix", "mthess", "mthess.exe")

    command <- paste0(ESS.directory, r2hess.exe, " -config ", config$config.file)

    if (.Platform$OS.type == "unix") {
        system(command)
    } else if (.Platform$OS.type == "windows") {
        shell(command)
    }

##########################################################################


#    res <- list(dataY = newdataY, dataX = newdataX, path.input = path.input,
#                path.output = path.output, path.par=path.par, history = history, time = time, file.par =file.par,file.log=file.log,
#                root.file.output = root.file.output, nsweep = nsweep,
#                top = top, label.X = label.X,
#                label.Y = label.Y, p = p, q = q0, n=n, ntissues = ntissues, nb.chain = nb.chain,
#                burn.in = burn.in,Egam=Egam,Sgam=Sgam,command=command,seed=seed,HESSmodel=HESSmodel)
#    class(res) <- "HESS"
#    return(res)

    
}


R2HESS <-
    function(dataY,dataX,path.input,path.output,path.par,file.par,file.log=NULL,nsweep,burn.in,Egam,Sgam,
             root.file.output,time=TRUE,top=100,history=TRUE,label.X=NULL,label.Y=NULL,nb.chain,seed=NULL)
{

    ##   for (i in c(1:length(.libPaths()))) {
    ##     if ( file.exists(paste(.libPaths()[i],"R2HESS",sep="/")) )
    ##       which.lib <- i
    ##   }
                                        # Setup file paths
    pack.root <- system.file(package = "R2HESS")
    ESS.directory <- file.path(pack.root, "bin", .Platform$r_arch)
    
    print(ESS.directory)
    
    if(burn.in>nsweep) stop("the number of burnin should be lower than the number of sweep (nsweep)")
    
    
### X data
    if(is.data.frame(dataX)){
        X <- dataX
        p <- dim(X)[2]
        n <- dim(X)[1]
        newdataX <- "data-X-C-CODE.txt"
        name.X <- file.path(path.expand(path.input),newdataX)
        cat(n,"\n",p,"\n",file=name.X,sep="")
        write(t(X), ncolumns=p,append = TRUE,file=name.X,sep="\t")
    }else{
        info <- readLines(file.path(path.expand(path.input),dataX),n=2)
        n <- as.integer(info[1])
        p <- as.integer(info[2])
        newdataX <- dataX
    }

### Y data
    if(is.character(dataY)) {
        info <- readLines(file.path(path.expand(path.input),dataY),n=2)
        ny <- as.integer(info[1])
        npheno <- as.integer(info[2])
        tissueline <- scan(file.path(path.expand(path.input),dataY),skip=2,nlines=1)
                                        #as.vector(info[3])
        print(tissueline)
        ntissues <- max(tissueline)
        q0 <- npheno/ntissues
        print(paste0("ny = ",ny," q0 = ",q0," ntissues = ",ntissues))
        if(n!=ny) stop("the two data set (predictors and phenotype) are not compatible regarding the number of subject")
        Y <- read.table(file.path(path.expand(path.input),dataY),skip=3)
        print(dim(Y))
        if(ny!=dim(Y)[1]) stop("check format of Y data file: first 3 rows should be dimension info")
        if((q0*ntissues)!=dim(Y)[2]) stop("check format of Y data file: first 3 rows should be dimension info")
        if(length(tissueline)!=q0) stop("third row of the txt file should be rep(ntissues,npheno)")
        newdataY <- dataY
    } else if(is.data.frame(dataY)) {
        ntissues <- 1
        Y <- dataY
        ny <- dim(Y)[1]
        q0 <- dim(Y)[2]
        print(paste0("ny = ",ny," q0 = ",q0," ntissues = ",ntissues))
        if(n!=ny) stop("the two data set (predictors and phenotype) are not compatible regarding the number of subject")
        label.Y <- colnames(Y)
        tissueline <- rep(c(as.character(ntissues)," "),q0)  
### write data in txt file for C++ code
        newdataY <- paste("data-Y-C-CODE.txt",sep="")
        name.Y <- file.path(path.expand(path.input),newdataY)
        cat(ny,"\n",q0,"\n",tissueline,"\n",file=name.Y,sep="")
        write(t(Y), ncolumns=q0,append = TRUE,file=name.Y,sep="\t")
    } else if(is.list(dataY)) {
        ntissues <- length(dataY)
        ny <- dim(dataY[[1]])[1]
        q0 <- dim(dataY[[1]])[2]
        print(paste0("ny = ",ny," q0 = ",q0," ntissues = ",ntissues))
        if(n!=ny) stop("the two data set (predictors and phenotype) are not compatible regarding the number of subject")
        label.Y <- colnames(dataY[[1]])
        tissueline <- rep(c(as.character(ntissues)," "),q0)  
### write data in txt file for C++ code
        newdataY <- paste("data-Y-C-CODE.txt",sep="")
        name.Y <- file.path(path.expand(path.input),newdataY)
        cat(ny,"\n",q0*ntissues,"\n",tissueline,"\n",file=name.Y,sep="")
        Y <- matrix(0,nrow=ny,ncol= ntissues*q0)
        for(itissue in 1:ntissues){
                                        #print(paste0("dim Y = ",dim(Y)))
            index <- seq(itissue,itissue+(q0-1)*ntissues,by=ntissues)
                                        #print(index)
                                        #print(dim(dataY[[itissue]]))
                                        #print(dim(Y[,index]))
            Y[,index] <- as.matrix(dataY[[itissue]])   
        }
        write(t(Y), ncolumns=q0*ntissues,append = TRUE,file=name.Y,sep="\t")
    }

    if(is.null(label.X))  label.X <- paste("X",1:p,sep=".")
    if(is.null(label.Y))  label.Y <- paste("Y",1:q0,sep=".")
                                        #if(is.null(colnames(Y))) colnames(Y) <- label.Y

    if(ntissues==1){
        print("Single-tissues HESS")
        HESSmodel <- "singleHESS"
    }
    else{
        print("Multi-tissue HESS")
        HESSmodel <- "multiHESS"
    }


                                        # CONFOUNDERS: CURRENTLY NOT USING IN HESS
                                        # if(!is.null(conf)){
                                        # if(is.data.frame(conf)){
                                        #   Z <- conf
                                        #   k <- dim(Z)[2]
                                        #   n <- dim(Z)[1]
                                        #   newdataZ <- "data-Z-C-CODE.txt"
                                        #   name.Z <- file.path(path.expand(path.input),newdataZ)
                                        #   cat(n,"\n",k,"\n",file=name.Z,sep="")
                                        #   write(t(Z), ncolumns=k,append = TRUE,file=name.Z,sep="\t")
                                        #   }else{
                                        #   info.Z <- readLines(file.path(path.expand(path.input),conf),n=2)
                                        #   n <- as.integer(info.Z[1])
                                        #   k <- as.integer(info.Z[2])
                                        #   Z <- read.table(file.path(path.expand(path.input),conf),skip=2)
                                        #   }
                                        # Z <- as.matrix(Z)
                                        # beta <- (solve(t(Z)%*%Z)%*%t(Z))%*%as.matrix(Y)
                                        # residu <- as.matrix(Y)-Z%*%beta
                                        # newdataY <- paste("residu-",newdataY,sep="")
                                        # name.conf <- file.path(path.expand(path.input),newdataY)
                                        # cat(n,"\n",q,"\n",file=name.conf,sep="")
                                        # write(t(residu), ncolumns=q,append = TRUE,file=name.conf,sep="\t")
                                        # #conf <- k
                                        # }



    if(time==TRUE) time1 <- " -time " else time1 <- NULL
    top1 <- paste(" -top ",top,sep="")
    burn.in1 <- paste(" -burn_in ",burn.in,sep="")
    if(history==TRUE) history1 <- " -history " else history1 <- NULL

                                        #if(cuda==TRUE) cuda1 <- " -cuda " else cuda1 <- NULL

                                        #ESS.directory <- path.expand(ESS.directory)

    path.input <- path.expand(path.input)
    path.output <- path.expand(path.output)
    path.par <- path.expand(path.par)
    if(is.null(file.log)) {file.log <- root.file.output
        log1 <- NULL} else{log1 <- " -log "}

    if(!is.null(seed)) {seed.opt <- paste(" -seed ",seed,sep="")} else{seed.opt <- NULL}


    guess.executable <- ifelse(.Platform$OS.type == "unix", "GUESS", "GUESS.exe")

    command <- paste(ESS.directory, guess.executable, ' -model 1 -X "',file.path(path.input,newdataX),
                     '" -Y "',file.path(path.input,newdataY), 
                     '" -par "',file.path(path.par,file.par),
                     '" -nsweep ',nsweep,burn.in1, ' -out_full "',
                     file.path(path.output,root.file.output),'" ',
                     top1,time1,history1,' -Egam ',Egam,' -Sgam ',Sgam,
                     ' -n_chain ',nb.chain,seed.opt,log1,' > "', 
                     file.path(path.output,file.log),'_log"',sep='')




    write(command,file=file.path(path.output, paste(root.file.output,"command-C.txt",sep="-")))
    print(command)

    if (.Platform$OS.type == "unix") {
        system(command)
    } else if (.Platform$OS.type == "windows") {
        shell(command)
    }

##########################################################################


    res <- list(dataY = newdataY, dataX = newdataX, path.input = path.input,
                path.output = path.output, path.par=path.par, history = history, time = time, file.par =file.par,file.log=file.log,
                root.file.output = root.file.output, nsweep = nsweep,
                top = top, label.X = label.X,
                label.Y = label.Y, p = p, q = q0, n=n, ntissues = ntissues, nb.chain = nb.chain,
                burn.in = burn.in,Egam=Egam,Sgam=Sgam,command=command,seed=seed,HESSmodel=HESSmodel)
    class(res) <- "HESS"
    return(res)
}



