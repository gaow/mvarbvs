print.HESS <- function(x,...){
if (!inherits(x, "HESS")) stop("use only with \"HESS\" objects")

cat(" \n")
cat("Multiple Sparse Bayesian Regression model (MSBR)", "\n")
cat("fitted by GPU-based Evolutionary Stochastic Search algorithm (ESS)", "\n")

cat(" \n")
cat("Statistical Model:",x$HESSmodel ,"\n")
cat(" \n")

cat("  Dataset:","\n")
cat(paste("     Number of observations:", x$n),"\n")
cat(" \n")

cat(paste("     Dataset Y:", x$dataY),"\n")
cat(paste("     No. of classes (r):", x$ntissues),"\n")
cat(paste("     No. of phenotypes (q):", x$q),"\n")

if(!is.null(x$label.Y)){
cat(paste("     Names of the phenotypes:"),"\n")
cat(paste("  ",paste(head(x$label.Y),collapse=" ")),"\n")
cat(" \n")
}

cat(paste("     Dataset X:", x$dataX),"\n")
cat(paste("     No. of predictors (p):", x$p),"\n")

if(!is.null(x$label.X)){
cat(paste("     Names of the predictors:"),"\n")
cat(paste("  ",paste(head(x$label.X),collapse=" ")),"\n")
cat(" \n")
}

cat(" \n")
cat(" \n")
cat("Parameters for HESS algorithm:", "\n")
cat(paste("     The a priori average model size:", x$Egam),"\n")
cat(paste("     The 'a priori' standard deviation of the model size:", x$Sgam),"\n")
cat(paste("     Number of sweeps for MCMC:", x$nsweep),"\n")
cat(paste("     Number of sweeps to discarded:", x$burn.in),"\n")
cat(paste("     Number of chains:",x$nb.chain),"\n")
cat(" \n")
if (!is.null(x$path.init)) {
  cat("MCMC start for the first run with the variable specified in:","\n")
  cat(paste(x$path.init,x$file.init,sep=""),"\n")}

cat("Path for the folder containing the output:","\n")
cat(paste("  ",x$path.output),"\n")
cat("The Name of the files containing results of MCMC start with:","\n")
cat(paste("  ",x$root.file.output),"\n")
cat("Path for the folder containing the dataset:","\n")
cat(paste("  ",x$path.input),"\n")
cat("Path for the xml-formatted file containing the main parameter for MCMC: ","\n")
cat(paste("   ",x$path.par,x$file.par,sep=""),"\n")
cat(" \n")
#cat(paste("Option history: ",x$history),"\n")
#cat(paste("Option time: ",x$time),"\n")
cat(" \n")


}






