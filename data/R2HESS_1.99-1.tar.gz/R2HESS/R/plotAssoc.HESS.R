r2hess.plotAssoc <- function(config, threshold=0.5) {

    NTOTAL <- config$nSweep - config$burn.in
    
    File_Matrix_Marg_Prob_Incl <- paste(config$output.dir, "Gamma_Counts_kj.txt",sep="")
    Matrix_Marg_Prob_Incl <- read.delim(File_Matrix_Marg_Prob_Incl,header=F,sep="",skip=1);
    Matrix_Marg_Prob_Incl <- Matrix_Marg_Prob_Incl/NTOTAL
    print(paste("dim MPPI = ",dim(Matrix_Marg_Prob_Incl)))

    # Exclude confounders
    if (config$nConfounders > 0) {
        Matrix_Marg_Prob_Incl <- Matrix_Marg_Prob_Incl[, -(1:config$nConfounders)]
    }
    
    pdf(file=paste(config$output.dir, "Plot_Heatmap_MPPI.pdf",sep=""),width=14,height=7);
    
    image(1:dim(Matrix_Marg_Prob_Incl)[2],1:dim(Matrix_Marg_Prob_Incl)[1],
          -t(as.matrix(Matrix_Marg_Prob_Incl)),
        main="Marginal Probability of inclusion",
        ylab="Response",xlab="Predictor");
    
    invisible(dev.off())

    # Plot summaries P(Gamma_kj=1) per predictor

    #### sum and max for each marker
    Matrix_Marg_Prob_Incl_sum <- apply(Matrix_Marg_Prob_Incl,2,sum)
    Matrix_Marg_Prob_Incl_max <- apply(Matrix_Marg_Prob_Incl,2,max)

    #### number MPPI pre predictor above threshold
    Matrix_Marg_Prob_Incl_abovethresh <- apply(Matrix_Marg_Prob_Incl>=threshold,2,sum)
    
        #print(paste("range max(MPPI) = ",range(Matrix_Marg_Prob_Incl_max)))

    pdf(file=paste(config$output.dir, "Plot_Summaries_MPPI_per_predictor.pdf",sep=""),width=14,height=7);
  
    par(mfrow=c(2,1))
    plot(Matrix_Marg_Prob_Incl_sum,xlab="Predictor",ylab="Sum(MPPI)",main="Sum of MPPI per predictor")
    plot(Matrix_Marg_Prob_Incl_max,xlab="Predictor",ylab="Max(MPPI)",main="Maximum MPPI per predictor")

    plot(Matrix_Marg_Prob_Incl_abovethresh,xlab="Predictor",ylab="No. MPPI above threshold",
	main=paste0("Number MPPI per predictor above ",threshold))

    invisible(dev.off())
    
}

plotAssoc.HESS <- function(x,PDF=TRUE,PDF_PATH=NULL,thresh=0.5){
    
  if(is.null(PDF_PATH)) PDF_PATH <- x$path.output


  ###############################################################
  # Plot heatmap P(Gamma_kj=1)

  NTOTAL <- x$nsweep - x$burn.in

  File_Matrix_Marg_Prob_Incl <- paste(x$path.output,"/",x$root.file.output,"_Counts_Gamma_kj.txt",sep="");
  Matrix_Marg_Prob_Incl <- read.delim(File_Matrix_Marg_Prob_Incl,header=F,sep="");
  Matrix_Marg_Prob_Incl <- Matrix_Marg_Prob_Incl/NTOTAL
  print(paste("dim MPPI = ",dim(Matrix_Marg_Prob_Incl)))

  if (PDF==1) pdf(file=paste(PDF_PATH,"/",x$root.file.output,"_Plot_Heatmap_MPPI.pdf",sep=""),width=14,height=7);
  
   image(1:dim(Matrix_Marg_Prob_Incl)[2],1:dim(Matrix_Marg_Prob_Incl)[1],
        -t(as.matrix(Matrix_Marg_Prob_Incl)),
        main=paste(x$root.file.output,": Marginal Probability of inclusion"),
        ylab="Response",xlab="Predictor");

  if (PDF==1) dev.off()


  ###############################################################
  # Plot summaries P(Gamma_kj=1) per predictor

  #### sum and max for each marker
  Matrix_Marg_Prob_Incl_sum <- apply(Matrix_Marg_Prob_Incl,2,sum)
  Matrix_Marg_Prob_Incl_max <- apply(Matrix_Marg_Prob_Incl,2,max)

  #### number MPPI pre predictor above threshold
  Matrix_Marg_Prob_Incl_abovethresh <- apply(Matrix_Marg_Prob_Incl>=thresh,2,sum)


  print(paste("range max(MPPI) = ",range(Matrix_Marg_Prob_Incl_max)))

  if (PDF==1) pdf(file=paste(PDF_PATH,"/",x$root.file.output,"_Plot_Summaries_MPPI_per_predictor.pdf",sep=""),width=14,height=7);
  
    par(mfrow=c(2,1))
    plot(Matrix_Marg_Prob_Incl_sum,xlab="Predictor",ylab="Sum(MPPI)",main="Sum of MPPI per predictor")
    plot(Matrix_Marg_Prob_Incl_max,xlab="Predictor",ylab="Max(MPPI)",main="Maximum MPPI per predictor")

    plot(Matrix_Marg_Prob_Incl_abovethresh,xlab="Predictor",ylab="No. MPPI above threshold",
	main=paste0("Number MPPI per predictor above ",thresh))


  if (PDF==1) dev.off()


  
}

