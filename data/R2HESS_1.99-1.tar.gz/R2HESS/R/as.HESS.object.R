as.HESS.object <-
function(dataY,dataX,path.input,path.output,path.par,file.par,file.log=NULL,nsweep,burn.in,Egam,Sgam,
root.file.output,time=TRUE,top=100,history=TRUE,label.X=NULL,label.Y=NULL,nb.chain,seed=NULL)
{

### X data
if(is.data.frame(dataX)){
  X <- dataX
  p <- dim(X)[2]
  n <- dim(X)[1]
  newdataX <- "data-X-C-CODE.txt"
  }else{
  info <- readLines(file.path(path.expand(path.input),dataX),n=2)
  n <- as.integer(info[1])
  p <- as.integer(info[2])
  newdataX <- dataX
  }

### Y data
if(is.character(dataY)) {
  info <- readLines(file.path(path.expand(path.input),dataY),n=2)
  ny <- as.integer(info[1])
  npheno <- as.integer(info[2])
  tissueline <- scan(file.path(path.expand(path.input),dataY),skip=2,nlines=1)
  #as.vector(info[3])
  print(tissueline)
  ntissues <- max(tissueline)
  q0 <- npheno/ntissues
  print(paste0("ny = ",ny," q0 = ",q0," ntissues = ",ntissues))
  if(n!=ny) stop("the two data set (predictors and phenotype) are not compatible regarding the number of subject")
  Y <- read.table(file.path(path.expand(path.input),dataY),skip=3)
  print(dim(Y))
  if(ny!=dim(Y)[1]) stop("check format of Y data file: first 3 rows should be dimension info")
  if((q0*ntissues)!=dim(Y)[2]) stop("check format of Y data file: first 3 rows should be dimension info")
  if(length(tissueline)!=q0) stop("third row of the txt file should be rep(ntissues,npheno)")
  newdataY <- dataY
} else if(is.data.frame(dataY)) {
  ntissues <- 1
  Y <- dataY
  ny <- dim(Y)[1]
  q0 <- dim(Y)[2]
  print(paste0("ny = ",ny," q0 = ",q0," ntissues = ",ntissues))
  if(n!=ny) stop("the two data set (predictors and phenotype) are not compatible regarding the number of subject")
  label.Y <- colnames(Y)
  tissueline <- rep(c(as.character(ntissues)," "),q0)  
  ### write data in txt file for C++ code
  newdataY <- paste("data-Y-C-CODE.txt",sep="")
} else if(is.list(dataY)) {
  ntissues <- length(dataY)
  ny <- dim(dataY[[1]])[1]
  q0 <- dim(dataY[[1]])[2]
  print(paste0("ny = ",ny," q0 = ",q0," ntissues = ",ntissues))
  if(n!=ny) stop("the two data set (predictors and phenotype) are not compatible regarding the number of subject")
  label.Y <- colnames(dataY[[1]])
  tissueline <- rep(c(as.character(ntissues)," "),q0)  
  ### write data in txt file for C++ code
  newdataY <- paste("data-Y-C-CODE.txt",sep="")
}

if(is.null(label.X))  label.X <- paste("X",1:p,sep=".")
if(is.null(label.Y))  label.Y <- paste("Y",1:q0,sep=".")
#if(is.null(colnames(Y))) colnames(Y) <- label.Y

if(ntissues==1){
  print("Single-tissues HESS")
  HESSmodel <- "singleHESS"
}
else{
  print("Multi-tissue HESS")
  HESSmodel <- "multiHESS"
}


# CONFOUNDERS: CURRENTLY NOT USING IN HESS
# if(!is.null(conf)){
# if(is.data.frame(conf)){
#   Z <- conf
#   k <- dim(Z)[2]
#   n <- dim(Z)[1]
#   newdataZ <- "data-Z-C-CODE.txt"
#   name.Z <- file.path(path.expand(path.input),newdataZ)
#   cat(n,"\n",k,"\n",file=name.Z,sep="")
#   write(t(Z), ncolumns=k,append = TRUE,file=name.Z,sep="\t")
#   }else{
#   info.Z <- readLines(file.path(path.expand(path.input),conf),n=2)
#   n <- as.integer(info.Z[1])
#   k <- as.integer(info.Z[2])
#   Z <- read.table(file.path(path.expand(path.input),conf),skip=2)
#   }
# Z <- as.matrix(Z)
# beta <- (solve(t(Z)%*%Z)%*%t(Z))%*%as.matrix(Y)
# residu <- as.matrix(Y)-Z%*%beta
# newdataY <- paste("residu-",newdataY,sep="")
# name.conf <- file.path(path.expand(path.input),newdataY)
# cat(n,"\n",q,"\n",file=name.conf,sep="")
# write(t(residu), ncolumns=q,append = TRUE,file=name.conf,sep="\t")
# #conf <- k
# }


path.input <- path.expand(path.input)
path.output <- path.expand(path.output)
path.par <- path.expand(path.par)
if(is.null(file.log)) {file.log <- root.file.output
                       log1 <- NULL} else{log1 <- " -log "}

##########################################################################


res <- list(dataY = newdataY, dataX = newdataX, path.input = path.input,
        path.output = path.output, path.par=path.par, history = history, time = time, file.par =file.par,file.log=file.log,
        root.file.output = root.file.output, nsweep = nsweep,
        top = top, label.X = label.X,
        label.Y = label.Y, p = p, q = q0, n=n, ntissues = ntissues, nb.chain = nb.chain,
        burn.in = burn.in,Egam=Egam,Sgam=Sgam,command=NULL,seed=seed,HESSmodel=HESSmodel)
class(res) <- "HESS"
return(res)
}



