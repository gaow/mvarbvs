r2hess.plotParams <- function(config) {

  # 1) Plot E(Omega_k)
    File_Av_Omega_k <- paste(config$output.dir, "Av_Omega_k.txt",sep="");
    Average_Omega_k <- read.delim(File_Av_Omega_k,header=F,sep="");
    #print(paste("dim Av omega = ",dim(Average_Omega_k)))
  
    pdf(file=paste(config$output.dir,"Plot_Av_Omega_k.pdf",sep=""),width=14,height=7);

    plot(as.matrix(Average_Omega_k),ylim=c(0,1.5*max(Average_Omega_k)),
         main="Average of Omega_k",ylab="omega_k",xlab="Response");

    invisible(dev.off())

  # 2) Plot E(Rho_j)
    File_Av_Rho_j <- paste(config$output.dir,"Av_Rho_j.txt",sep="");
    Average_Rho_j <- read.delim(File_Av_Rho_j,header=F,sep="");
    #print(paste("dim av rho = ",dim(Average_Rho_j)))

    # Exclude confounders
    if (config$nConfounders > 0) {
        Average_Rho_j <- Average_Rho_j[-(1:config$nConfounders),]
    }
    
    pdf(file=paste(config$output.dir,"Plot_Av_Rho_j.pdf",sep=""),width=14,height=7);
    
    plot(as.matrix(Average_Rho_j),main="Average of Rho_j",
         ylab="rho_j",xlab="Predictor",cex=.5);
    
    invisible(dev.off())


    # 3) Plot tail probabilities
    File_Tail_Prob_Rho_j <- paste(config$output.dir,"Tail_Prob_Rho_j.txt",sep="");
    Tail_Prob_Rho_j <- read.delim(File_Tail_Prob_Rho_j,header=F,sep="",skip=1);
    print(paste("dim tailprob rho = ",dim(Tail_Prob_Rho_j)))
    
    ##Sel_Plot=which(Tail_Prob_Rho_j>=Thresh_Decl);

    # Exclude confounders
    if (config$nConfounders > 0) {
        Tail_Prob_Rho_j <- Tail_Prob_Rho_j[-(1:config$nConfounders),]
    }
    
    pdf(file=paste(config$output.dir,"Plot_Tail_Prob_Rho_j.pdf",sep=""),width=14,height=7);
    
    plot(as.matrix(Tail_Prob_Rho_j),cex=.5,main="Probability that Rho_j>1",
    ylab="Tail Prob rho",xlab="Predictor");

    invisible(dev.off())


  # 5) Plot E(Omega_kj)

    File_Av_Matrix_Omega_kj <- paste(config$output.dir,"Av_Matrix_Omega_kj.txt",sep="");
    Av_Matrix_Omega_kj <- read.delim(File_Av_Matrix_Omega_kj,header=F,sep="",skip=1);
    print(paste("dim av omega_kj = ",dim(Av_Matrix_Omega_kj)))

    # Exclude confounders
    if (config$nConfounders > 0) {
        Av_Matrix_Omega_kj <- Av_Matrix_Omega_kj[, -(1:config$nConfounders)]
    }
    
    pdf(file=paste(config$output.dir,"Plot_Av_Omega_kj.pdf",sep=""),width=14,height=7);
    
    image(1:dim(Av_Matrix_Omega_kj)[2],1:dim(Av_Matrix_Omega_kj)[1],
        -t(as.matrix(Av_Matrix_Omega_kj)),
        main="Average of Omega_kj",
        ylab="Response",xlab="Predictor");

    invisible(dev.off())
}

plotParams.HESS <- function(x,PDF=TRUE,PDF_PATH=NULL){
  
  if(is.null(PDF_PATH)) PDF_PATH <- x$path.output

  ###############################################################
  # 1) Plot E(Omega_k)
  File_Av_Omega_k <- paste(x$path.output,"/",x$root.file.output,"_Av_Omega_k.txt",sep="");
  Average_Omega_k <- read.delim(File_Av_Omega_k,header=F,sep="");
  print(paste("dim Av omega = ",dim(Average_Omega_k)))
  
  if (PDF==1) pdf(file=paste(PDF_PATH,"/",x$root.file.output,"_Plot_Av_Omega_k.pdf",sep=""),width=14,height=7);

    plot(as.matrix(Average_Omega_k),ylim=c(0,1.5*max(Average_Omega_k)),
         main=paste(x$root.file.output,": Average of Omega_k"),ylab="omega_k",xlab="Response");

  if (PDF==1) dev.off()
  
  
  ###############################################################
  # 2) Plot E(Rho_j)
  File_Av_Rho_j <- paste(x$path.output,"/",x$root.file.output,"_Av_Rho_j.txt",sep="");
  Average_Rho_j <- read.delim(File_Av_Rho_j,header=F,sep="");
  print(paste("dim av rho = ",dim(Average_Rho_j)))

  if (PDF==1) pdf(file=paste(PDF_PATH,"/",x$root.file.output,"_Plot_Av_Rho_j.pdf",sep=""),width=14,height=7);

    plot(as.matrix(Average_Rho_j),main=paste(x$root.file.output,": Average of Rho_j"),
	ylab="rho_j",xlab="Predictor",cex=.5);

  if (PDF==1)  dev.off()
  
  
  ###############################################################
  # 3) Plot tail probabilities
  File_Tail_Prob_Rho_j <- paste(x$path.output,"/",x$root.file.output,"_Tail_Prob_Rho_j.txt",sep="");
  Tail_Prob_Rho_j <- read.delim(File_Tail_Prob_Rho_j,header=F,sep="");
  print(paste("dim tailprob rho = ",dim(Tail_Prob_Rho_j)))

  ##Sel_Plot=which(Tail_Prob_Rho_j>=Thresh_Decl);
  
  if (PDF==1) pdf(file=paste(PDF_PATH,"/",x$root.file.output,"_Plot_Tail_Prob_Rho_j.pdf",sep=""),width=14,height=7);

    plot(as.matrix(Tail_Prob_Rho_j),cex=.5,main=paste(x$root.file.output,": Probability that Rho_j>1"),
	ylab="Tail Prob rho",xlab="Predictor");

  if (PDF==1)  dev.off()
  
  
  ###############################################################
  # 5) Plot E(Omega_kj)
  File_Av_Matrix_Omega_kj <- paste(x$path.output,"/",x$root.file.output,"_Av_Matrix_Omega_kj.txt",sep="");
  Av_Matrix_Omega_kj <- read.delim(File_Av_Matrix_Omega_kj,header=F,sep="");
  print(paste("dim av omega_kj = ",dim(Av_Matrix_Omega_kj)))

  if (PDF==1) pdf(file=paste(PDF_PATH,"/",x$root.file.output,"_Plot_Av_Omega_kj.pdf",sep=""),width=14,height=7);

    image(1:dim(Av_Matrix_Omega_kj)[2],1:dim(Av_Matrix_Omega_kj)[1],
        -t(as.matrix(Av_Matrix_Omega_kj)),
        main=paste(x$root.file.output,": Average of Omega_kj"),
        ylab="Response",xlab="Predictor");

  if (PDF==1)  dev.off()
  
  #heatmap(as.matrix(Av_Matrix_Omega_kj[,Sel_Plot]),
  #        Colv=NA);
  
  # Look at layout, dendrogram
    
}

