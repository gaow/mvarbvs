r2hess.checkConvergence <- function(config) {

    # 1) Plot history of g
    
    File_History_g <- paste0(config$output.dir, "History_g.txt")
    History_g <- read.delim(File_History_g, header=F, sep="")

    pdf(file=paste0(config$output.dir, "Plot_History_g.pdf"), width=14, height=7)
    plot(as.matrix(History_g), cex=.5, main="History of g", ylab="", xlab="iteration")
    plot(as.matrix(History_g)[-c(1:config$burn.in)], cex=.5,
       main=paste("History of g excluding burn-in of", config$burn.in),
       ylab="", xlab="iteration")

    invisible(dev.off())

    # 2) Plot history of Omega_k

    File_History_Omega_k <- paste0(config$output.dir, "History_Omega_k.txt", sep="")
    History_Omega_k <- read.delim(File_History_Omega_k ,header=F, sep="")
  
    #History_Omega_k <- t(History_Omega_k)
    print(paste("dim omega = ",dim(History_Omega_k)))
  
    pdf(file=paste0(config$output.dir, "Plot_History_Omega_k.pdf"), width=14, height=7)

    par(mfrow=c(2,1))
    for(i in 1:(dim(History_Omega_k)[2])) {
        plot(as.matrix(History_Omega_k)[,i], cex=.5, 
             main=paste("History of Omega", i), ylab="", xlab="iteration")
        plot(as.matrix(History_Omega_k)[-c(1:config$burn.in),i], cex=.5,
             main=paste("History of Omega",i,"excluding burn-in of ",config$burn.in), ylab="", xlab="iteration")
    }

    invisible(dev.off())


    # 3) Plot scatter plot for convergence of history of Omega_k
  
    pdf(file=paste0(config$output.dir, "Plot_Scatter_History_Omega_k.pdf"),
	width=7,height=7);

    NTOT <- dim(History_Omega_k)[1]
    NBURN <- config$burn.in
    
    #print(paste("Ntotal =",NTOT))
    mat1 <- as.matrix(History_Omega_k)[c( (NBURN+1):((NTOT+NBURN)/2) ),]
    mat2 <- as.matrix(History_Omega_k)[c( (1+(NTOT+NBURN)/2):NTOT ),]
    #print(dim(mat1))
    #print(dim(mat2))

    mean1 <- apply(mat1,MARGIN=2,FUN=mean)
    mean2 <- apply(mat2,MARGIN=2,FUN=mean)
    plot(mean1,mean2,cex=.5,
       main=paste("Scatterplot History of Omega_k excluding burn-in of ",config$burn_in),
       ylab="mean in second half of chain",xlab="mean in first half of chain")
    abline(0,1)

    invisible(dev.off())


    # 4) Plot scatter plot for convergence of history of Rho_j
  
    File_History_Rho_j <- paste0(config$output.dir, "History_Rho_j.txt");
    History_Rho_j <- read.delim(File_History_Rho_j,header=F,sep="");
    
    print(paste("dim rho = ",dim(History_Rho_j)))
  
    pdf(file=paste0(config$output.dir, "Plot_Scatter_History_Rho_j.pdf"),
	width=14,height=7);

    NTOT <- dim(History_Rho_j)[1]
    #print(paste("Ntotal =",NTOT))
    mat1 <- as.matrix(History_Rho_j)[c( (NBURN+1):((NTOT+NBURN)/2) ),]
    mat2 <- as.matrix(History_Rho_j)[c( (1+(NTOT+NBURN)/2):NTOT ),]
    #print(dim(mat1))
    #print(dim(mat2))

    mean1 <- apply(mat1,MARGIN=2,FUN=mean)
    mean2 <- apply(mat2,MARGIN=2,FUN=mean)

    par(mfrow=c(1,2))
    plot(mean1,mean2,cex=.5,
       main=paste("Scatterplot History of Rho_j excluding burn-in of ",config$burn.in),
       ylab="mean in second half of chain",xlab="mean in first half of chain")
    abline(0,1)
    plot(mean1,mean2,cex=.5,log="xy",
       main=paste("Log scale Scatterplot History of Rho_j excluding burn-in of ",config$burn.in),
       ylab="mean in second half of chain",xlab="mean in first half of chain")
  abline(0,1)
  
    invisible(dev.off())
   
}


checkConvergence.HESS <- function(x,PDF=TRUE,PDF_PATH=NULL){

  if(is.null(PDF_PATH)) PDF_PATH <- x$path.output

  NBURN <- x$burn.in + 1
  
  ###############################################################
  # 1) Plot history of g

  File_History_g <- paste(x$path.output,"/",x$root.file.output,"_History_g.txt",sep="");
  History_g <- read.delim(File_History_g,header=F,sep="");
  print(paste("dim g = ",dim(History_g)))
    
  if (PDF==1) pdf(file=paste(PDF_PATH,"/",x$root.file.output,"_Plot_History_g.pdf",sep=""),
	width=14,height=7);

    plot(as.matrix(History_g),cex=.5,
       main=paste(x$root.file.output,": History of g"),ylab="",xlab="iteration");
    plot(as.matrix(History_g)[-c(1:NBURN)],cex=.5,
       main=paste(x$root.file.output,": History of g excluding burn-in of ",x$burn.in),
       ylab="",xlab="iteration");

  if (PDF==1) dev.off()

  
  ###############################################################
  # 2) Plot history of Omega_k

  File_History_Omega_k <- paste(x$path.output,"/",x$root.file.output,"_History_Omega_k.txt",sep="");
  History_Omega_k <- read.delim(File_History_Omega_k,header=F,sep="");
  
  ## NB Loizos has transposed the matrix output, so here transpose it back
  History_Omega_k <- t(History_Omega_k)
  print(paste("dim omega = ",dim(History_Omega_k)))
  
  if (PDF==1) pdf(file=paste(PDF_PATH,"/",x$root.file.output,"_Plot_History_Omega_k.pdf",sep=""),
	width=14,height=7);

    par(mfrow=c(2,1))
    for(i in 1:(dim(History_Omega_k)[2]) ){

      plot(as.matrix(History_Omega_k)[,i],cex=.5,
       main=paste(x$root.file.output,": History of Omega",i),ylab="",xlab="iteration");
      plot(as.matrix(History_Omega_k)[-c(1:NBURN),i],cex=.5,
       main=paste(x$root.file.output,": History of Omega",i,"excluding burn-in of ",x$burn.in),
       ylab="",xlab="iteration");
    }

  if (PDF==1) dev.off()
  
  ###############################################################
  # 3) Plot scatter plot for convergence of history of Omega_k
  
  if (PDF==1) pdf(file=paste(PDF_PATH,"/",x$root.file.output,"_Plot_Scatter_History_Omega_k.pdf",sep=""),
	width=7,height=7);

    NTOT <- dim(History_Omega_k)[1]
    print(paste("Ntotal =",NTOT))
    mat1 <- as.matrix(History_Omega_k)[c( (NBURN+1):((NTOT+NBURN)/2) ),]
    mat2 <- as.matrix(History_Omega_k)[c( (1+(NTOT+NBURN)/2):NTOT ),]
    print(dim(mat1))
    print(dim(mat2))

    mean1 <- apply(mat1,MARGIN=2,FUN=mean)
    mean2 <- apply(mat2,MARGIN=2,FUN=mean)
    plot(mean1,mean2,cex=.5,
       main=paste(x$root.file.output,": Scatterplot History of Omega_k excluding burn-in of ",x$burn.in),
       ylab="mean in second half of chain",xlab="mean in first half of chain")
    abline(0,1)

  if (PDF==1) dev.off()

  ###############################################################
  # 4) Plot scatter plot for convergence of history of Rho_j
  
  File_History_Rho_j <- paste(x$path.output,"/",x$root.file.output,"_History_Rho_j.txt",sep="");
  History_Rho_j <- read.delim(File_History_Rho_j,header=F,sep="");
  print(paste("dim rho = ",dim(History_Rho_j)))
  
  if (PDF==1) pdf(file=paste(PDF_PATH,"/",x$root.file.output,"_Plot_Scatter_History_Rho_j.pdf",sep=""),
	width=14,height=7);

    NTOT <- dim(History_Rho_j)[1]
    print(paste("Ntotal =",NTOT))
    mat1 <- as.matrix(History_Rho_j)[c( (NBURN+1):((NTOT+NBURN)/2) ),]
    mat2 <- as.matrix(History_Rho_j)[c( (1+(NTOT+NBURN)/2):NTOT ),]
    print(dim(mat1))
    print(dim(mat2))

    mean1 <- apply(mat1,MARGIN=2,FUN=mean)
    mean2 <- apply(mat2,MARGIN=2,FUN=mean)

    par(mfrow=c(1,2))
    plot(mean1,mean2,cex=.5,
       main=paste(x$root.file.output,": Scatterplot History of Rho_j excluding burn-in of ",x$burn.in),
       ylab="mean in second half of chain",xlab="mean in first half of chain")
    abline(0,1)
  plot(mean1,mean2,cex=.5,log="xy",
       main=paste(x$root.file.output,": Log scale Scatterplot History of Rho_j excluding burn-in of ",x$burn.in),
       ylab="mean in second half of chain",xlab="mean in first half of chain")
  abline(0,1)
  
  if (PDF==1) dev.off()
  
}

