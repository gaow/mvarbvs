r2hess.toptableAssoc <- function(config, minthresh=0.5) {

    # Table of top P(Gamma_kj=1), with estimated bFDR

    ### get MPPI values

    NTOTAL <- config$nSweep - config$burn.in
    
    File_Matrix_Marg_Prob_Incl <- paste(config$output.dir, "Gamma_Counts_kj.txt",sep="");
    Matrix_Marg_Prob_Incl <- read.delim(File_Matrix_Marg_Prob_Incl,header=F,sep="",skip=1);

    X.labels <- config$X.labels
    
    # Exclude confounders
    if (config$nConfounders > 0) {
        Matrix_Marg_Prob_Incl <- Matrix_Marg_Prob_Incl[, -(1:config$nConfounders)]
        X.labels <- X.labels[-(1:config$nConfounders)]
    }
    
    Matrix_Marg_Prob_Incl <- Matrix_Marg_Prob_Incl/NTOTAL
    
    print(paste("dim MPPI = ",dim(Matrix_Marg_Prob_Incl)))
    
### get all MPPI above minthresh into a table, with variable names
    
    index.use <- which(Matrix_Marg_Prob_Incl >= minthresh, arr.ind=TRUE)
    X.use <- X.labels[index.use[,2]]
    Y.use <- config$Y.labels[index.use[,1]]
    MPPI.toptable <- data.frame(MPPI=Matrix_Marg_Prob_Incl[index.use],Y=Y.use,X=X.use,bFDR=rep(-1,length(X.use)))
    ind.sort <- rev(order(MPPI.toptable$MPPI))
    MPPI.toptable <- MPPI.toptable[ind.sort,]

                                        #print(head(MPPI.toptable))
    print(dim(MPPI.toptable))
    
    ### get bFDR for all MPPI values in the top table
    
  #dummy <- table(MPPI.toptable$MPPI)
  #print(dummy)
  #print(names(dummy))

    thresholds <- unique(MPPI.toptable$MPPI)
  #print(paste("thresh = ",thresholds))

    bFDR <- rep(-1,length(thresholds))  
    for(i in 1:length(thresholds)){
        Declare_signal <- MPPI.toptable$MPPI >= thresholds[i]
        bFDR[i] <- mean(Declare_signal * (1.0-MPPI.toptable$MPPI))
    #print(Declare_signal)
    #print(bFDR[i])
        ind.table <- MPPI.toptable$MPPI==thresholds[i]
        MPPI.toptable$bFDR[ind.table] <- bFDR[i]
    }

  #print(paste("bFDR estimate = ",bFDR))
  #print(tail(MPPI.toptable))

    bFDRtable <- cbind(thresholds,bFDR)
    print(head(bFDRtable))

  ###############################################################
  # plot estimated bFDR v. thresholds

    pdf(file=paste0(config$output.dir, "Plot_bFDR_estimate.pdf"),width=14,height=7);
  
    plot(thresholds,bFDR,xlab="Threshold on posterior probability",ylab="bFDR Estimate",type="b",
         main="Estimate bFDR v. MPPI threshold")
    
    invisible(dev.off())
    
    row.names(MPPI.toptable) <- NULL
    return(MPPI.toptable)

}


toptableAssoc.HESS <- function(x,PDF=TRUE,PDF_PATH=NULL,minthresh=0.5){
    
  ###############################################################
  # Table of top P(Gamma_kj=1), with estimated bFDR

  ### get MPPI values

  NTOTAL <- x$nsweep - x$burn.in

  File_Matrix_Marg_Prob_Incl <- paste(x$path.output,"/",x$root.file.output,"_Counts_Gamma_kj.txt",sep="");
  Matrix_Marg_Prob_Incl <- read.delim(File_Matrix_Marg_Prob_Incl,header=F,sep="");
  Matrix_Marg_Prob_Incl <- Matrix_Marg_Prob_Incl/NTOTAL

  print(paste("dim MPPI = ",dim(Matrix_Marg_Prob_Incl)))

  ### get all MPPI above minthresh into a table, with variable names

  index.use <- which(Matrix_Marg_Prob_Incl >= minthresh, arr.ind=TRUE)
  X.use <- x$label.X[index.use[,2]]
  Y.use <- x$label.Y[index.use[,1]]
  MPPI.toptable <- data.frame(MPPI=Matrix_Marg_Prob_Incl[index.use],Y=Y.use,X=X.use,bFDR=rep(-1,length(X.use)))
  ind.sort <- rev(order(MPPI.toptable$MPPI))
  MPPI.toptable <- MPPI.toptable[ind.sort,]

  #print(head(MPPI.toptable))
  print(dim(MPPI.toptable))

  ### get bFDR for all MPPI values in the top table

  #dummy <- table(MPPI.toptable$MPPI)
  #print(dummy)
  #print(names(dummy))

  thresholds <- unique(MPPI.toptable$MPPI)
  #print(paste("thresh = ",thresholds))

  bFDR <- rep(-1,length(thresholds))  
  for(i in 1:length(thresholds)){
    Declare_signal <- MPPI.toptable$MPPI >= thresholds[i]
    bFDR[i] <- mean(Declare_signal * (1.0-MPPI.toptable$MPPI))
    #print(Declare_signal)
    #print(bFDR[i])
    ind.table <- MPPI.toptable$MPPI==thresholds[i]
    MPPI.toptable$bFDR[ind.table] <- bFDR[i]
  }

  #print(paste("bFDR estimate = ",bFDR))
  #print(tail(MPPI.toptable))

  bFDRtable <- cbind(thresholds,bFDR)
  print(head(bFDRtable))

  ###############################################################
  # plot estimated bFDR v. thresholds

  if (PDF==1) pdf(file=paste(PDF_PATH,"/",x$root.file.output,"_Plot_bFDR_estimate.pdf",sep=""),width=14,height=7);
  
  plot(thresholds,bFDR,xlab="Threshold on posterior probability",ylab="bFDR Estimate",type="b",
	main="Estimate bFDR v. MPPI threshold")

  if (PDF==1) dev.off()

  row.names(MPPI.toptable) <- NULL
  return(MPPI.toptable)

}

